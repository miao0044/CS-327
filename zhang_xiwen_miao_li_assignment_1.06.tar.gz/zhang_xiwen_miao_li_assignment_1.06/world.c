#include <stdlib.h>
#include <math.h>
#include "dungeon.h"
#include "binaryheap.h"

/* (attempt to) place a room within a given dungeon */
int place_room(Dungeon * dungeon) {
	int x = (rand() % (dungeon->w-1)) +1;
	int y = (rand() % (dungeon->h-1)) +1;
	Room new_room;
	new_room.br = initPos();
	new_room.tl = initPos();
	new_room.ctr = initPos();
	/*
	set top right to rng number; might be worth making a more detailed placer with a lower
		fail rate
	*/
	setPosX(new_room.tl, x);
	setPosY(new_room.tl, y);
	/* for RNG, maybe do a rando room width/height and re-set .br */

	HW: ;

	int we = (rand() % 4) + 4; /* width, expanded, up to 4 more */
	int he = (rand() % 4) + 3; /* height, expanded, up to 4 more */

	if(we == he) {
		/* if we have a square, re-generate */
		goto HW;
	}

	new_room.h = he;
	new_room.w = we;

	setPosX(new_room.br, x + new_room.w-1);
	setPosY(new_room.br, y + new_room.h-1);

	/* check for rooms loaded into the dungeon buffer already */
	int i;
	int j;
	int placed = -1;
	int passed = 0;
	for(i = y; i < dungeon->h-1 && i < y+he; i++) {
		for(j = x; j < dungeon->w-1 && j < x+we; j++) {
			if(dungeon->p[i][j].c != '.') {
				passed++;
			}
		}
	}

	/* return a failure if not all cells within the "Room" passed */
	if(passed < we*he) {
		return placed; /* should be -1 */
	}

	/* return a failure if part of the room is out of bounds */
	if(getPosX(new_room.br) >= dungeon->w || getPosY(new_room.br) >= dungeon->h) {
		return placed;
	}


	/* check for surrounding rooms */

	/* top row */
	for(i = getPosX(new_room.tl)-1; i < getPosX(new_room.br)+2 && getPosX(new_room.tl)-1 >= 0 && getPosX(new_room.br)+1 < dungeon->w && getPosY(new_room.tl)-1 >= 0; i++) {
		if((dungeon->p[getPosY(new_room.tl)-1][i]).c == '.') {
			return placed;
		}
	}

	/* bottom row */
	for(i = getPosX(new_room.tl)-1; i < getPosX(new_room.br)+2 && getPosX(new_room.tl)-1 >= 0 && getPosX(new_room.br)+1 < dungeon->w && getPosY(new_room.br)+1 < dungeon->h; i++) {
		if((dungeon->p[getPosY(new_room.br)+1][i]).c == '.') {
			return placed;
		}
	}

	/* left side */
	for(i = getPosY(new_room.tl); i < getPosY(new_room.br)+1 && getPosY(new_room.br)+1 < dungeon->h && getPosX(new_room.tl)-1 >= 0; i++) {
		if((dungeon->p[i][getPosX(new_room.tl)-1]).c == '.') {
			return placed;
		}
	}

	/* right side */
	for(i = getPosY(new_room.tl); i < getPosY(new_room.br)+1 && getPosY(new_room.br)+1 < dungeon->h && getPosX(new_room.br)+1 < dungeon->w; i++) {
		if((dungeon->p[i][getPosX(new_room.br)+1]).c == '.') {
			return placed;
		}
	}


	/* successful placement */
	placed = 0;

	/* fill the room into the dungeon buffer and add to room array */
	for(i = y; i < y+he; i++) {
		for(j = x; j < x+we; j++) {
			dungeon->p[i][j].c = '.';
			dungeon->d[i][j].h = 0;
		}
	}


	if(dungeon->nr < dungeon->mr) {
		dungeon->nr++;
		new_room.id = dungeon->nr-1; /* reflects position in the array */
		setPosX(new_room.ctr, (new_room.w)/2 + getPosX(new_room.tl));
		setPosY(new_room.ctr, (new_room.h)/2 + getPosY(new_room.tl));
		/* printf("%d: (%d, %d)\n", new_room.id, new_room.ctr.x, new_room.ctr.y); */
		dungeon->r[dungeon->nr-1] = new_room;
	} else {
		return -1;
	}


	return placed;
}

/* assistant function for gen_corridors() to check if all rooms are connected */
int all_connected(int * cnxns, Dungeon * dungeon) {
	int i;

	for(i = 0; i < dungeon->nr; i++) {
		if(cnxns[i] != 1 || dungeon->r[i].c != TRUE) {
			return FALSE;
		}
	}

	return TRUE;
}

/* generates and marks corridors */
void gen_corridors(Dungeon * dungeon) {
	int i;
	int connected[dungeon->nr];
	for(i = 0; i < dungeon->nr; i++) {
		connected[i] = 0;
	}
	//memset(connected, 0, dungeon->nr * sizeof(int));
	double dists[dungeon->nr];
	for(i = 0; i < dungeon->nr; i++) {
		dists[i] = 0;
	}
	//memset(dists, 0.0, dungeon->nr * sizeof(double));
	int max_paths = dungeon->nr * 3;
	Path paths[max_paths]; /* max paths is 3 * number of rooms */
	int path_cnt = 0;
	int	room_pos = 0; /* current room in use */

	for(i = 0; i < dungeon->nr; i++) {
		dists[i] = -1; /* infinite at -1 */
	}
	dists[0] = 0;

	/* ensure all rooms are disconnected */
	for(i = 0; i < dungeon->nr; i++) {
		dungeon->r[i].c = FALSE;
	}

	/* primary loop, goal is to connect all rooms; 0 means true */
	while(all_connected(connected, dungeon) == FALSE && path_cnt < max_paths) {
		int i;
		double d;
		Path new_path;

		/* populate dists from the current position */
		for(i = 0; i < dungeon->nr; i++) {
			/* calculate distance */
			d =  sqrt(pow(getPosX(dungeon->r[i].ctr) - getPosX(dungeon->r[room_pos].ctr), 2) + pow(getPosY(dungeon->r[i].ctr) - getPosY(dungeon->r[room_pos].ctr), 2));
			dists[i] = d;
		}

		/* find the room to path to ;; if not connected already and the distance is shorter and isn't our current position */

		int next = -1;
		for(i = 0; i < dungeon->nr; i++) {
			if(connected[i] != 1 && next == -1 && room_pos != i) {
				next = i;
			} else if(connected[i] != 1 && dists[i] < dists[next] && room_pos != i) {
				next = i;
			}
		}

		/** this would - in the future - be the point of adding extraneous paths **/
		if(next != -1) {
			dungeon->r[room_pos].c = TRUE;
			dungeon->r[next].c = TRUE;
			connected[room_pos] = 1;
			new_path.prev = room_pos;
			new_path.next = next;
			paths[path_cnt] = new_path;
			room_pos = next;
			path_cnt++;
		} else {
			break;
		}

	}

	/* populate the dungeon grid (draw the paths using x/y chasing/pathing) */

	/* draw dungeon paths in the dungeon grid; start at room 0 as per above */

	for(i = 0; i < path_cnt; i++) {
		int x = getPosX(dungeon->r[paths[i].prev].ctr);
		int y = getPosY(dungeon->r[paths[i].prev].ctr);

		/*printf("%d: (%d, %d)\n", i, x, y);*/

		while(x != getPosX(dungeon->r[paths[i].next].ctr) || y != getPosY(dungeon->r[paths[i].next].ctr)) {
			int dirx = 0; /* -1 for left, 1 for right */
			int diry = 0; /* -1 for down, 1 for up */

			if(x < getPosX(dungeon->r[paths[i].next].ctr)) {
				dirx = 1;
			} else if(x > getPosX(dungeon->r[paths[i].next].ctr)) {
				dirx = -1;
			}

			if(y < getPosY(dungeon->r[paths[i].next].ctr)) {
				diry = 1;
			} else if(y > getPosY(dungeon->r[paths[i].next].ctr)) {
				diry = -1;
			}

			dungeon->d[y][x].p = 1;
			/* don't place corridors in rooms */
			if(dungeon->d[y][x].c != '.') {
				dungeon->d[y][x].c = '#';
				dungeon->d[y][x].h = 0;
			}

			if(dirx == -1) {
				x--;
			} else if(dirx == 1) {
				x++;
			} else if(diry == -1) {
				y--;
			} else if(diry == 1) {
				y++;
			}
		}

	}

}

/* generate a blank dungeon */
void gen_dungeon(Dungeon * dungeon) {
	/*** top 3 (0, 1, 2) are reserved for the pseudo-HUD ***/
	int i, j;

	/* set all slots to spaces originally */
	for(i = 0; i < dungeon->h; i++) {
		for(j = 0; j < dungeon->w; j++) {
			(dungeon->d[i][j]).c = ' ';	/* all basic rooms are spaces */
			int h = (rand() % 254) + 1;
			(dungeon->d[i][j]).h = h;
		}
	}

	/* immut-ify the outside rim */
	for(i = 0; i < dungeon->w; i++) {
		(dungeon->d[0][i]).h = 255;
	}
	for(i = 0; i < dungeon->w; i++) {
		(dungeon->d[dungeon->h-1][i]).h = 255;
	}
	for(i = 0; i < dungeon->h; i++) {
		(dungeon->d[i][0]).h = 255;
	}
	for(i = 0; i < dungeon->h; i++) {
		(dungeon->d[i][dungeon->w-1]).h = 255;
	}

	/* make p equal to d */
	for(i = 0; i < dungeon->h; i++) {
		for(j = 0; j < dungeon->w; j++) {
			dungeon->p[i][j] = dungeon->d[i][j];
		}
	}

	/* populate the rooms */
	int cnt = 0;
	int tst = 0;
	for(i = 0; dungeon->nr < dungeon->mr && cnt < 2000; i++) {
		tst = place_room(dungeon);
		if(tst < 0) {
			cnt++;
		}
	}

	/* set the stairs */
	int x;
	int y;

	int r_id = rand() % dungeon->nr;
	x = (rand() % dungeon->r[r_id].w) + getPosX(dungeon->r[r_id].tl);
	y = (rand() % dungeon->r[r_id].h) + getPosY(dungeon->r[r_id].tl);

	//lol
	dungeon->sd = initPos();
	dungeon->su = initPos();

	setPosX(dungeon->sd, x);
	setPosY(dungeon->sd, y);

	SD: ;
	r_id = rand() % dungeon->nr;
	x = (rand() % dungeon->r[r_id].w) + getPosX(dungeon->r[r_id].tl);
	y = (rand() % dungeon->r[r_id].h) + getPosY(dungeon->r[r_id].tl);
	setPosX(dungeon->su, x);
	setPosY(dungeon->su, y);

	if(getPosX(dungeon->su) == getPosX(dungeon->sd) && getPosY(dungeon->su) == getPosY(dungeon->sd))
		goto SD;

}

/* initializes the dungeon structure */
Dungeon init_dungeon(int h, int w, int mr) {
	Dungeon new_dungeon;
	new_dungeon.h	= h;
	new_dungeon.w	= w;
	new_dungeon.mr	= mr;
	new_dungeon.nr	= 0;
	new_dungeon.ns	= 0;
	new_dungeon.ms	= w*h; /* max sprites would be 1 per dungeon slot */
	new_dungeon.t	= 0;
	new_dungeon.go	= FALSE;

	/* dungeon buffer allocation+0'ing */
	new_dungeon.d = calloc(new_dungeon.h, sizeof(Tile *));

	int i;
	for(i = 0; i < new_dungeon.h; i++) {
		new_dungeon.d[i] = calloc(new_dungeon.w, sizeof(Tile));
	}

	/* dungeon visual buffer allocation+0'ing */
	new_dungeon.p = calloc(new_dungeon.h, sizeof(Tile *));

	for(i = 0; i < new_dungeon.h; i++) {
		new_dungeon.p[i] = calloc(new_dungeon.w, sizeof(Tile));
	}

	/* rooms allocation+0'ing */
	new_dungeon.r = calloc(new_dungeon.mr, sizeof(Room));

	/* sprites allocation */
	new_dungeon.ss = calloc(new_dungeon.ms, sizeof(Sprite *) + 1);

	/* djikstra-based cost map allocation */
	new_dungeon.cst = calloc(w*h, sizeof(int *));
	for(i = 0; i < new_dungeon.h; i++) {
		new_dungeon.cst[i] = calloc(new_dungeon.w, sizeof(int));
	}

	/* djikstra-based cost map allocation */
	new_dungeon.csnt = calloc(w*h, sizeof(int *));
	for(i = 0; i < new_dungeon.h; i++) {
		new_dungeon.csnt[i] = calloc(new_dungeon.w, sizeof(int));
	}

	return new_dungeon;
}
/* check if we can move to a location (objectively) */
Bool test_loc(Dungeon * dungeon, int x, int y, Sprite *s) {
	if(x > 0 && x < dungeon->w-1 && y > 0 && y < dungeon->h-1) {
		int hard = dungeon->d[y][x].h;
		if(dungeon->d[y][x].h < 255) {
			if(getSpriteSTu(s) == FALSE && hard > 0)
				return FALSE;
			return TRUE;
		}
	}
	return FALSE;
}

/* checks if a given sprite shares a room with the PC */
void with_pc(Dungeon * dungeon, Sprite * s, Bool *in) {
	int pc_rid	= -1;
	int s_rid	= -1;
	// Sprite *pc = &(dungeon->ss[dungeon->pc]);
	Sprite *pc = thisASprite(dungeon->ss, dungeon->pc);

	int i;
	for(i = 0; i < dungeon->nr; i++) {
		if(getSpritePX(s) <= getPosX(dungeon->r[i].br) && getSpritePY(s) <= getPosY(dungeon->r[i].br) && getSpritePX(s) >= getPosX(dungeon->r[i].tl) && getSpritePY(s) >= getPosY(dungeon->r[i].tl)) {
			s_rid = i;
		}
		if(getSpritePX(pc) <= getPosX(dungeon->r[i].br) && getSpritePY(pc) <= getPosY(dungeon->r[i].br) && getSpritePX(pc) >= getPosX(dungeon->r[i].tl) && getSpritePY(pc) >= getPosY(dungeon->r[i].tl)) {
			pc_rid = i;
		}
	}
	if(pc_rid > 0 && s_rid > 0 && pc_rid == s_rid)
		*in = TRUE;
}

void gen_move_sprite(Dungeon * dungeon, int sn) {
	//make ss[sn] when possible
	// int sx = dungeon->ss[sn].p.x;
	// int sy = dungeon->ss[sn].p.y;
	int sx = getSpriteAPX(dungeon->ss, sn);
	int sy = getSpriteAPY(dungeon->ss, sn);
	int xs[8] = {-1,0,1,1,1,0,-1,-1};
	int ys[8] = {-1,-1,-1,0,1,1,1,0};

	//Sprite *s = &(dungeon->ss[sn]);
	Sprite *s = thisASprite(dungeon->ss, sn);

	/* increment the turn */
	//dungeon->ss[sn].t += (100 / s->s.s);
	setSpriteAT(dungeon->ss, sn, getSpriteAT(dungeon->ss, sn) + (100 / getSpriteSS(s)));

	Position * new = NULL;
	new = initPos();
	setPosX(new, -1);
	setPosY(new, -1);

	dungeon->d[getSpritePY(s)][getSpritePX(s)].h -= 85;
	if(dungeon->d[getSpritePY(s)][getSpritePX(s)].h < 0)
		dungeon->d[getSpritePY(s)][getSpritePX(s)].h = 0;

	// make sure we're alive
	if(getSpriteA(s) == TRUE) {
		int i;
		int j;
		int eb = rand() % 2; /* we have a 50% chance to behave erratically */
		for(i = 0; i < 8; i++) {
			int px = sx + xs[i];
			int py = sy + ys[i];

			if(px >= 0 && px < dungeon->w && py >= 0 && py < dungeon->h) {
				/* drunken PC movement as per assignment 1.04 */

				/* check erratic behaviour */
				if(getSpriteSEb(s) == FALSE || (getSpriteSEb(s) == TRUE && eb)) {
					/** check if intelligent / telepathic **/
					//new.x = sx;
					//new.y = sy;
					if(getSpriteSTe(s) == FALSE) {
						/* see if you're in the same room */
						Bool in_room = FALSE;
						with_pc(dungeon, s, &in_room);
						if(in_room == TRUE) {
							//cache PC location
							//s->pc = dungeon->ss[dungeon->pc].p;
							setSpritePcX(s, getSpriteAPX(dungeon->ss, dungeon->pc));
							setSpritePcY(s, getSpriteAPY(dungeon->ss, dungeon->pc));

							IN: ;
							if(getSpriteSIn(s) == TRUE) {
								/* we are intelligent and can see our mark (tele or otherwise) */
								int k;
								int lowest = 0;
								Bool set = FALSE;
								if(getSpriteSTu(s)) {
									//tunneling
									for(k = 0; k < 8; k++) {
										if(xs[k]+sx >= 0 && xs[k]+sx < dungeon->w && ys[k]+sy >= 0 && ys[k]+sy < dungeon->h) {
											if(dungeon->d[ys[k]+sy][xs[k]+sx].h < 255 && dungeon->cst[ys[k]+sy][xs[k]+sx] < dungeon->cst[ys[lowest]+sy][xs[lowest]+sx] && test_loc(dungeon, xs[k]+sx, ys[k]+sy, s) == TRUE && test_loc(dungeon, xs[lowest]+sx, ys[lowest]+sy, s) == TRUE) {
												lowest = k;
												set = TRUE;
											}
										}
									}
								} else {
									//non-tunneling
									for(k = 0; k < 8; k++) {
										px = xs[k]+sx;
										py = ys[k]+sy;
										if(px >= 0 && px < dungeon->w && py >= 0 && py < dungeon->h) {
											if(dungeon->d[py][px].h == 0 && dungeon->csnt[py][px] <= dungeon->csnt[ys[lowest]+sy][xs[lowest]+sx]) {
												lowest = k;
												set = TRUE;
											}
										}
									}
										/*
										for(k = 0; k < 8; k++) {
											if(xs[k]+sx >= 0 && xs[k]+sx < dungeon->w && ys[k]+sy >= 0 && ys[k]+sy < dungeon->h) {
												if(dungeon->d[ys[k]+sy][xs[k]+sx].h < 255 && dungeon->csnt[ys[k]+sy][xs[k]+sx] < dungeon->csnt[ys[lowest]+sy][xs[lowest]+sx] && test_loc(dungeon, xs[k]+sx, ys[k]+sy, s) == TRUE && test_loc(dungeon, xs[lowest]+sx, ys[lowest]+sy, s) == TRUE) {
													lowest = k;
													set = TRUE;
												}
											}
										}
										*/
								}
								if(set == TRUE) {
									setPosX(new, xs[lowest] + sx);
									setPosY(new, ys[lowest] + sy);
									break;
								} else {
									setPosX(new, sx);
									setPosY(new, sy);
									break;
								}

									/*
									if(test_loc(dungeon, px, py, s) == TRUE) {
										//if we can move to the point
										if(getSpriteSTu(s)) {
											//tunneling
											if(new.x > 0 && new.y > 0 && new.x != sx && new.y != sy) {
												if(dungeon->cst[py][px] < dungeon->cst[new.y][new.x]) {
													new.x = px;
													new.y = py;
												}
											} else {
												new.x = px;
												new.y = py;
											}
										} else {
											//non-tunneling
											if(new.x > 0 && new.y > 0 && new.x != sx && new.y != sy) {
												if(dungeon->csnt[py][px] < dungeon->csnt[new.y][new.x]) {
													new.x = px;
													new.y = py;
												}
											} else {
												new.x = px;
												new.y = py;
											}
										}
									}
									*/
							} else {
								//if not intelligent
								if(getSpritePcX(s) < sx)
									px = sx - 1;
								if(getSpritePcX(s) > sx)
									px = sx + 1;
								if(getSpritePcY(s) < sy)
									py = sy - 1;
								if(getSpritePcY(s) > sy)
									py = sy + 1;

								if(test_loc(dungeon, px, py, s) == TRUE) {
									setPosX(new, px);
									setPosY(new, py);

									break;
								}
							}
						} else {
							//not in the same room and not telepathic
							//randomize
							goto PCEB;
						}
					} else {
						//we know where the PC is
						//s->pc = dungeon->ss[dungeon->pc].p;
						setSpritePcX(s, getSpriteAPX(dungeon->ss, dungeon->pc));
						setSpritePcY(s, getSpriteAPY(dungeon->ss, dungeon->pc));
						/**
						intelligence test still applies
						we just treat it as if we're always in the room " "
						**/
						goto IN;
					}

					//printf("%c in room? %d\n",s->c , in_room);
				} else {
					/* we are erratically behaving */
					PCEB: ;
					j = 0;
					EB: ;
					int c = rand() % 9;
					px = xs[c] + sx;
					py = ys[c] + sy;
					/* try to find a place to go up to n times */
					if(test_loc(dungeon, px, py, s) == FALSE && j < 8) {
						j++;
						goto EB;
					}
					if(test_loc(dungeon, px, py, s) == TRUE) {
						/* if the location is okay, commit it*/
						setPosX(new, px);
						setPosY(new, py);
					}

					break;
				}
			}
		}
	}

	/* safety net */
	if(getPosX(new) < 0)
		setPosX(new, sx);
	if(getPosY(new) < 0)
		setPosY(new, sy);

	//dungeon->ss[sn].to.x = new.x;
	//dungeon->ss[sn].to.y = new.y;
	setSpriteAToX(dungeon->ss, sn, getPosX(new));
	setSpriteAToY(dungeon->ss, sn, getPosY(new));

	if(getPosX(new) == getSpriteAPX(dungeon->ss, dungeon->pc) && getPosY(new) == getSpriteAPY(dungeon->ss, dungeon->pc))
		dungeon->go = TRUE;

	/* check if we have to kill another sprite */
	int i;
	for(i = 0; i < dungeon->ns; i++) {
		if(i != sn) {
			if((getSpriteAToX(dungeon->ss, i)  == getSpriteAToX(dungeon->ss, sn)) && (getSpriteAToY(dungeon->ss, i) == getSpriteAToY(dungeon->ss, sn)) && getSpriteAA(dungeon->ss, sn) == TRUE)
				setSpriteAA(dungeon->ss, i, FALSE);
			/*
			else if(dungeon->ss[i].p.x == dungeon->ss[sn].p.x && dungeon->ss[i].p.y == dungeon->ss[sn].p.y && dungeon->ss[i].a == TRUE)
				dungeon->ss[sn].a = FALSE;
			*/
		}
	}
}

/* parse and apply a movement */
void parse_move(Dungeon * dungeon, int sn) {
	//dungeon->ss[sn].p.x = dungeon->ss[sn].to.x;
	//dungeon->ss[sn].p.y = dungeon->ss[sn].to.y;
	setSpriteAPX(dungeon->ss, sn, getSpriteAToX(dungeon->ss, sn));
	setSpriteAPY(dungeon->ss, sn, getSpriteAToY(dungeon->ss, sn));
}

/* add a sprite to the dungeon */
void add_sprite(Dungeon * dungeon, Sprite * s) {
	if(dungeon->ns < dungeon->ms) {
		dungeon->ns++;
	} else {
		goto END;
	}

	if(getSpriteC(s) == '@') {
		dungeon->pc = dungeon->ns - 1;
    }

	//dungeon->ss[dungeon->ns - 1] = s;
	copyASprite(dungeon->ss, dungeon->ns -1, s);

	END: ;
}

/*
generate a sprite, because in-line structs are icky
if r(oom) = 1 then x and y will be ignored and should be passed as -1 as such (normally meaning random)
*/
Sprite * gen_sprite(Dungeon * dungeon, char c, int x, int y, int r) {
	Sprite * s = initSprite();

	setSpriteC(s, c);
	setSpriteA(s, TRUE);

    /* set stats */
    if(getSpriteC(s) == '@') {
		/* fully re-hash and re-write PC setup ;; might need to add a new standalone variable which would s u c k */
        PC * p = initPC(dungeon);

		return (Sprite *) p;
	} else {
        /* if not the pc a value 5-20 */
        setSpriteSS(s, (rand() % 16) + 5);
        /* generate stats */
        setSpriteSIn(s, rand() % 2);
        setSpriteSTe(s, rand() % 2);
        setSpriteSTu(s, rand() % 2);
        setSpriteSEb(s, rand() % 2);

        /* set character as per assignment 4 */
        if(getSpriteSIn(s) == FALSE && getSpriteSTe(s) == FALSE && getSpriteSTu(s) == FALSE && getSpriteSEb(s) == FALSE)
            setSpriteC(s, '0');
        else if(getSpriteSIn(s) == FALSE && getSpriteSTe(s) == FALSE && getSpriteSTu(s) == FALSE && getSpriteSEb(s) == TRUE)
            setSpriteC(s, '1');
        else if(getSpriteSIn(s) == FALSE && getSpriteSTe(s) == FALSE && getSpriteSTu(s) == TRUE && getSpriteSEb(s) == FALSE)
            setSpriteC(s, '2');
        else if(getSpriteSIn(s) == FALSE && getSpriteSTe(s) == FALSE && getSpriteSTu(s) == TRUE && getSpriteSEb(s) == TRUE)
            setSpriteC(s, '3');
        else if(getSpriteSIn(s) == FALSE && getSpriteSTe(s) == TRUE && getSpriteSTu(s) == FALSE && getSpriteSEb(s) == FALSE)
            setSpriteC(s, '4');
        else if(getSpriteSIn(s) == FALSE && getSpriteSTe(s) == TRUE && getSpriteSTu(s) == FALSE && getSpriteSEb(s) == TRUE)
            setSpriteC(s, '5');
        else if(getSpriteSIn(s) == FALSE && getSpriteSTe(s) == TRUE && getSpriteSTu(s) == TRUE && getSpriteSEb(s) == FALSE)
            setSpriteC(s, '6');
        else if(getSpriteSIn(s) == FALSE && getSpriteSTe(s) == TRUE && getSpriteSTu(s) == TRUE && getSpriteSEb(s) == TRUE)
            setSpriteC(s, '7');
        else if(getSpriteSIn(s) == TRUE && getSpriteSTe(s) == FALSE && getSpriteSTu(s) == FALSE && getSpriteSEb(s) == FALSE)
            setSpriteC(s, '8');
        else if(getSpriteSIn(s) == TRUE && getSpriteSTe(s) == FALSE && getSpriteSTu(s) == FALSE && getSpriteSEb(s) == TRUE)
            setSpriteC(s, '9');
        else if(getSpriteSIn(s) == TRUE && getSpriteSTe(s) == FALSE && getSpriteSTu(s) == TRUE && getSpriteSEb(s) == FALSE)
            setSpriteC(s, 'a');
        else if(getSpriteSIn(s) == TRUE && getSpriteSTe(s) == FALSE && getSpriteSTu(s) == TRUE && getSpriteSEb(s) == TRUE)
            setSpriteC(s, 'b');
        else if(getSpriteSIn(s) == TRUE && getSpriteSTe(s) == TRUE && getSpriteSTu(s) == FALSE && getSpriteSEb(s) == FALSE)
            setSpriteC(s, 'c');
        else if(getSpriteSIn(s) == TRUE && getSpriteSTe(s) == TRUE && getSpriteSTu(s) == FALSE && getSpriteSEb(s) == TRUE)
            setSpriteC(s, 'd');
        else if(getSpriteSIn(s) == TRUE && getSpriteSTe(s) == TRUE && getSpriteSTu(s) == TRUE && getSpriteSEb(s) == FALSE)
            setSpriteC(s, 'e');
        else if(getSpriteSIn(s) == TRUE && getSpriteSTe(s) == TRUE && getSpriteSTu(s) == TRUE && getSpriteSEb(s) == TRUE)
            setSpriteC(s, 'f');
    }

    /* put the tunneling monsters anywhere */
    if(getSpriteSTu(s) == TRUE) {
		int t = 0;
		PRT: ;
        /* randomize location anywhere in the dungeon */
        if(x < 0 || x > dungeon->w) {
            x = (rand() % (dungeon->w-2)) + 1;
        }
        if(y < 0 || y > dungeon->h) {
            y = (rand() % (dungeon->h-2)) + 1;
        }

		if(getSpriteC(s) != '@' && dungeon->nr > 1) {
			setSpritePX(s, x);
		    setSpritePY(s, y);

			Bool w_pc = FALSE;
			with_pc(dungeon, s, &w_pc);
			if(w_pc == TRUE && t < 8) {
				t++;
				goto PRT;
			}
		}
    }

    /* place in a room if 1 or more. implicitly random ;; force in a room even if tunneling */
    if(r > 0 || getSpriteSTu(s) == FALSE) {
		int t = 0;
		PRNT: ;
        int r_id = rand() % dungeon->nr;
        x = (rand() % dungeon->r[r_id].w) + getPosX(dungeon->r[r_id].tl);
        y = (rand() % dungeon->r[r_id].h) + getPosY(dungeon->r[r_id].tl);

		if(getSpriteC(s) != '@' && dungeon->nr > 1) {
			setSpritePX(s, x);
		    setSpritePY(s, y);

			Bool w_pc = FALSE;
			with_pc(dungeon, s, &w_pc);
			if(w_pc == TRUE && t < 8) {
				t++;
				goto PRNT;
			}
		}
    } else {

    }

    setSpritePX(s, x);
    setSpritePY(s, y);
	setSpriteToX(s, x);
	setSpriteToY(s, y);
	//s.t = 100/s.s.s;
	setSpriteT(s, 0);

	return s;
}

/* checks if any monsters other than the player are alive */
Bool check_any_monsters(Dungeon * dungeon) {
	int i;
	for(i = 0; i < dungeon->ns; i++) {
		if(getSpriteAA(dungeon->ss, i) == TRUE && i != 0)
			return TRUE;
	}

	return FALSE;
}

