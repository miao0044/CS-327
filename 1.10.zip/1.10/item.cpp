#include "dungeon.h"
#include <stdlib.h>

ObjectFactory::ObjectFactory(void) {
	id = NULL;
	dn = 0;
}

ObjectFactory::ObjectFactory(int n, ItemTemp * defs) {
	id = defs;
	dn = n;
}

void placeitem(Dungeon * dungeon, Item it) {
	int r_id = rand() % dungeon->nr;
	it.p.x = (rand() % dungeon->r[r_id].w) + getPositionX(dungeon->r[r_id].tl);
	it.p.y = (rand() % dungeon->r[r_id].h) + getPositionY(dungeon->r[r_id].tl);

	if(dungeon->nit < dungeon->ms) {
		dungeon->items[dungeon->nit] = it;
		dungeon->nit++;
	}
}

Item ObjectFactory::GetObj() {
	int n = rand() % dn;
	ItemTemp olditm = id[n];
	Item itm;
	Position p0;
	p0.x = 0;
	p0.y = 0;

	itm.n 	= olditm.n;
	itm.desc = olditm.desc;
	itm.w	= olditm.w->roll();
	itm.spb	= olditm.spb->roll();
	itm.sa	= olditm.sa->roll();
	itm.v	= olditm.v->roll();
	itm.s	= olditm.s;
	itm.rar = olditm.rar;
	itm.art = olditm.art;
	itm.dl	= olditm.dl;
	itm.t	= olditm.t;
	itm.e	= olditm.e;
	itm.c	= olditm.c;
	itm.d	= olditm.d;
	itm.hib	= olditm.hib->roll();
	itm.dob	= olditm.dob->roll();
	itm.deb	= olditm.deb->roll();
	itm.p 	= p0;

	return itm;
}
