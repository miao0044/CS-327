#include "dungeon.h"

Creature * initCreature() {
    return new Creature;
}

Creature * initCreatures(int n) {
    return new Creature[n];
}

void copyCreature(Creature * des, Creature * ori) {
    des->p.x = ori->p.x;
    des->p.y = ori->p.y;
    des->c = ori->c;
    des->s.in = ori->s.in;
    des->s.te = ori->s.te;
    des->s.tu = ori->s.tu;
    des->s.eb = ori->s.eb;
    des->s.uni = ori->s.uni;
    des->s.boss = ori->s.boss;
    des->s.s = ori->s.s;
    des->t = ori->t;
    des->to.x = ori->to.x;
    des->to.y = ori->to.y;
    des->sn = ori->sn;
    des->pc.x = ori->pc.x;
    des->pc.y = ori->pc.y;
    des->a = ori->a;
    des->rar = ori->rar;
    des->dl = ori->dl;
    des->desc = ori->desc;
}

void copyPC(PC * des, PC * ori) {
    des->p.x  =  ori->p.x;
    des->p.y  = ori->p.y ;
    des->c    = ori->c   ;
    des->s.in = ori->s.in;
    des->s.te = ori->s.te;
    des->s.tu = ori->s.tu;
    des->s.eb = ori->s.eb;
    des->s.pa = ori->s.pa;
    des->s.s  = ori->s.s ;
    des->t    = ori->t   ;
    des->to.x = ori->to.x;
    des->to.y = ori->to.y;
    des->sn   = ori->sn  ;
    des->pc.x = ori->pc.x;
    des->pc.y = ori->pc.y;
    des->a    = ori->a   ;
    des->color= ori->color;

    int i;
    for(i = 0; i < 12; i++) {
    	des->eqs[i]	= ori->eqs[i];
        des->eqsp[i] = ori->eqsp[i];
    }

    for(i = 0; i < 10; i++) {
		des->inv[i]	= ori->inv[i];
		des->invp[i] = ori->invp[i];
    }

}

void copyACreature(Creature * des, int n, Creature * ori) {
    (des[n]).p.x  =  ori->p.x ;
    (des[n]).p.y  = ori->p.y ;
    (des[n]).c    = ori->c   ;
    (des[n]).s.a	 = ori->s.a;
    (des[n]).s.in = ori->s.in;
    (des[n]).s.te = ori->s.te;
    (des[n]).s.tu = ori->s.tu;
    (des[n]).s.eb = ori->s.eb;
    (des[n]).s.pa = ori->s.pa;
    (des[n]).s.uni = ori->s.uni;
  	(des[n]).s.boss = ori->s.boss;
    (des[n]).s.s  = ori->s.s ;
    (des[n]).t    = ori->t   ;
    (des[n]).rar  = ori->rar ;
    (des[n]).to.x = ori->to.x;
    (des[n]).to.y = ori->to.y;
    (des[n]).sn   = ori->sn  ;
    (des[n]).pc.x = ori->pc.x;
    (des[n]).pc.y = ori->pc.y;
    (des[n]).a    = ori->a   ;
    (des[n]).color= ori->color;
    (des[n]).dl= ori->dl;
    (des[n]).desc= ori->desc;
}

Creature * thisACreature(Creature * arr, int i) {
    return arr[i].thisCreature();
}

Creature * Creature::thisCreature() {
    return this;
}

/***
getter functions
***/

/* singleton */
int getCreaturePX(Creature * s) {
    return s->p.x;
}

int getCreaturePY(Creature * s) {
    return s->p.y;
}

char getCreatureC(Creature * s) {
	return s->c;
}

bool getCreatureSIn(Creature * s) {
    return s->s.in;
}

bool getCreatureSTe(Creature * s) {
    return s->s.te;
}

bool getCreatureSTu(Creature * s) {
    return s->s.tu;
}

bool getCreatureSEb(Creature * s) {
    return s->s.eb;
}

int getCreatureSS(Creature * s) {
    return s->s.s;
}

int getCreatureT(Creature * s) {
    return s->t;
}

int getCreatureToX(Creature * s) {
    return s->to.x;
}

int getCreatureToY(Creature * s) {
    return s->to.y;
}

int getCreatureSn(Creature * s) {
    return s->sn;
}

int getCreaturePcX(Creature * s) {
    return s->pc.x;
}

int getCreaturePcY(Creature * s) {
    return s->pc.y;
}

bool getCreatureA(Creature * s) {
    return s->a;
}

/* array-based */
int getCreatureAPX(Creature * s, int i) {
    return s[i].p.x;
}

int getCreatureAPY(Creature * s, int i) {
    return s[i].p.y;
}

char getCreatureAC(Creature * s, int i) {
    return s[i].c;
}

bool getCreatureASIn(Creature * s, int i) {
    return s[i].c;
}

bool getCreatureASTe(Creature * s, int i) {
    return s[i].s.te;
}

bool getCreatureASTu(Creature * s, int i) {
    return s[i].s.tu;
}

bool getCreatureASEb(Creature * s, int i) {
    return s[i].s.eb;
}

int getCreatureASS(Creature * s, int i) {
    return s[i].s.s;
}

int getCreatureAT(Creature * s, int i) {
    return s[i].t;
}

int getCreatureAToX(Creature * s, int i) {
    return s[i].to.x;
}

int getCreatureAToY(Creature * s, int i) {
    return s[i].to.y;
}

int getCreatureASn(Creature * s, int i) {
    return s[i].sn;
}

int getCreatureAPcX(Creature * s, int i) {
    return s[i].pc.x;
}

int getCreatureAPcY(Creature * s, int i) {
    return s[i].pc.y;
}

bool getCreatureAA(Creature * s, int i) {
    return s[i].a;
}

/***
Setter functions
kill me
***/

/* singleton */
void setCreaturePX(Creature * s, int n) {
    s->p.x = n;
}

void setCreaturePY(Creature * s, int n) {
    s->p.y = n;
}

void setCreatureC(Creature * s, char c) {
	s->c = c;
}

void setCreatureSIn(Creature * s, bool b) {
    s->s.in = b;
}

void setCreatureSTe(Creature * s, bool b) {
    s->s.te = b;
}

void setCreatureSTu(Creature * s, bool b) {
    s->s.tu = b;
}

void setCreatureSEb(Creature * s, bool b) {
    s->s.eb = b;
}

void setCreatureSS(Creature * s, int n) {
    s->s.s = n;
}

void setCreatureT(Creature * s, int n) {
    s->t = n;
}

void setCreatureToX(Creature * s, int n) {
    s->to.x = n;
}

void setCreatureToY(Creature * s, int n) {
    s->to.y = n;
}

void setCreatureSn(Creature * s, int n) {
    s->sn = n;
}

void setCreaturePcX(Creature * s, int n) {
    s->pc.x = n;
}

void setCreaturePcY(Creature * s, int n) {
    s->pc.y = n;
}

void setCreatureA(Creature * s, bool b) {
    s->a = b;
}

/* array-based */
void setCreatureAPX(Creature * s, int i, int n) {
    s[i].p.x = n;
}

void setCreatureAPY(Creature * s, int i, int n) {
    s[i].p.y = n;
}

void setCreatureAC(Creature * s, int i, char c) {
    s[i].c = c;
}

void setCreatureASIn(Creature * s, int i, bool b) {
    s[i].s.in = b;
}

void setCreatureASTe(Creature * s, int i, bool b) {
    s[i].s.te = b;
}

void setCreatureASTu(Creature * s, int i, bool b) {
    s[i].s.tu = b;
}

void setCreatureASEb(Creature * s, int i, bool b) {
    s[i].s.eb = b;
}

void setCreatureASS(Creature * s, int i, int n) {
    s[i].s.s = n;
}

void setCreatureAT(Creature * s, int i, int n) {
    s[i].t = n;
}

void setCreatureAToX(Creature * s, int i, int n) {
    s[i].to.x = n;
}

void setCreatureAToY(Creature * s, int i, int n) {
    s[i].to.y = n;
}

void setCreatureASn(Creature * s, int i, int n) {
    s[i].sn = n;
}

void setCreatureAPcX(Creature * s, int i, int n) {
    s[i].pc.x = n;
}

void setCreatureAPcY(Creature * s, int i, int n) {
    s[i].pc.y = n;
}

void setCreatureAA(Creature * s, int i, bool b) {
    s[i].a = b;
}

/***
Position functions
### These exist because positions are used outside of classes for this project ###
can be safely moved out of create at a later time
***/

int getPositionX(Position * p) {
    return p->x;
}

int getPositionY(Position * p) {
    return p->y;
}

void setPositionX(Position * p, int n) {
    p->x = n;
}

void setPositionY(Position * p, int n) {
    p->y = n;
}

Position * initPosition(void) {
	return new Position;
}
