#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include "dungeon.h"
#include "binaryheap.h"

MonsterFactory::MonsterFactory(void) {
	md = NULL;
	dn = 0;
}

MonsterFactory::MonsterFactory(int n, CreatureTemp * defs) {
	md = defs;
	dn = n;
}

void parse_move(Dungeon * dun, int sn) {

	setCreatureAPX(dun->ss, sn, getCreatureAToX(dun->ss, sn));
	setCreatureAPY(dun->ss, sn, getCreatureAToY(dun->ss, sn));
}

Creature* MonsterFactory::GetMon() {
	int n = rand() % dn;
	CreatureTemp oldmon = md[n];
	Creature * mon = new Creature;
	Position p0;
	p0.x = 0;
	p0.y = 0;
	Position pn1;
	pn1.x = -1;
	pn1.y = -1;

	mon->p = p0;
	mon->c = oldmon.pa;
	mon->s.in = oldmon.s.in;
	mon->s.te = oldmon.s.te;
	mon->s.tu = oldmon.s.tu;
	mon->s.eb = oldmon.s.eb;
	mon->s.pa = oldmon.s.pa;
	mon->s.uni = oldmon.s.uni;
	mon->s.s = oldmon.s.s->roll();
	mon->s.a = oldmon.s.a;
	mon->s.hp = oldmon.s.hp->roll();

	mon->t = 0;
	mon->to = p0;
	mon->sn = -1;
	mon->pc = pn1;
	mon->a = true;
	mon->n = oldmon.n;
	mon->color = oldmon.color;
	mon->desc = oldmon.desc;
	mon->dl = oldmon.dl;
	mon->rar = oldmon.rar;


	return mon;
}

Bool check_boss_alive(Dungeon * dun) {
	int i;
	for(i = 0; i < dun->ns; i++) {
		if(dun->ss[i].s.boss == TRUE && dun->ss[i].a == FALSE)
			return FALSE;
	}
	return TRUE;
}

Bool test_loc(Dungeon * dun, int x, int y, Creature *s) {
	if(x == dun->plyr->p.x && y == dun->plyr->p.y)
		return FALSE;
	int i;
	for(i = 1; i < dun->ns; i++)
	{
		if(dun->ss[i].p.x == x && dun->ss[i].p.y == y && i != s->sn) {
			dun->ss[i].p.x = dun->ss[s->sn].p.x;
			dun->ss[i].p.y = dun->ss[s->sn].p.y;
			return TRUE;
		}
	}

	if(x > 0 && x < dun->w-1 && y > 0 && y < dun->h-1) {
		int hard = dun->d[y][x].h;
		if(dun->d[y][x].h < 255) {
			if(getCreatureSTu(s) == FALSE && hard > 0)
				return FALSE;
			return TRUE;
		}
	}
	return FALSE;
}

void with_pc(Dungeon * dun, Creature * s, Bool *in) {
	int pc_rid	= -1;
	int s_rid	= -1;
	Creature *pc = thisACreature(dun->ss, dun->pc);

	int i;
	for(i = 0; i < dun->nr; i++) {
		if(getCreaturePX(s) <= getPositionX(dun->r[i].br) && getCreaturePY(s) <= getPositionY(dun->r[i].br) && getCreaturePX(s) >= getPositionX(dun->r[i].tl) && getCreaturePY(s) >= getPositionY(dun->r[i].tl)) {
			s_rid = i;
		}
		if(getCreaturePX(pc) <= getPositionX(dun->r[i].br) && getCreaturePY(pc) <= getPositionY(dun->r[i].br) && getCreaturePX(pc) >= getPositionX(dun->r[i].tl) && getCreaturePY(pc) >= getPositionY(dun->r[i].tl)) {
			pc_rid = i;
		}
	}
	if(pc_rid > 0 && s_rid > 0 && pc_rid == s_rid)
		*in = TRUE;
}

void gen_move_creature(Dungeon * dun, int sn) {
	int sx = getCreatureAPX(dun->ss, sn);
	int sy = getCreatureAPY(dun->ss, sn);
	int xs[8] = {-1,0,1,1,1,0,-1,-1};
	int ys[8] = {-1,-1,-1,0,1,1,1,0};
	dun->ss[sn].lp.x = sx;
	dun->ss[sn].lp.y = sy;

	Creature *s = thisACreature(dun->ss, sn);
	setCreatureAT(dun->ss, sn, getCreatureAT(dun->ss, sn) + (100 / getCreatureSS(s)));

	Position * neu = new Position;
	neu = initPosition();
	setPositionX(neu, -1);
	setPositionY(neu, -1);

	dun->d[getCreaturePY(s)][getCreaturePX(s)].h -= 85;
	if(dun->d[getCreaturePY(s)][getCreaturePX(s)].h < 0)
		dun->d[getCreaturePY(s)][getCreaturePX(s)].h = 0;
	if(s->a == TRUE) {
		Bool in_room;
		int i;
		int j;
		int eb = rand() % 2;
		for(i = 0; i < 8; i++) {
			int px = sx + xs[i];
			int py = sy + ys[i];

			if(px >= 0 && px < dun->w && py >= 0 && py < dun->h) {
				if(getCreatureSEb(s) == FALSE || (getCreatureSEb(s) == TRUE && eb)) {
					if(getCreatureSTe(s) == FALSE) {
						in_room = FALSE;
						with_pc(dun, s, &in_room);
						if(in_room == TRUE) {
							setCreaturePcX(s, getCreatureAPX(dun->ss, dun->pc));
							setCreaturePcY(s, getCreatureAPY(dun->ss, dun->pc));

							IN: ;
							in_room = TRUE;
							if(getCreatureSIn(s) == TRUE) {
								int k;
								int lowest = 0;
								Bool set = FALSE;
								if(getCreatureSTu(s)) {
									for(k = 0; k < 8; k++) {
										if(xs[k]+sx >= 0 && xs[k]+sx < dun->w && ys[k]+sy >= 0 && ys[k]+sy < dun->h) {
											if(dun->d[ys[k]+sy][xs[k]+sx].h < 255 && dun->cst[ys[k]+sy][xs[k]+sx] < dun->cst[ys[lowest]+sy][xs[lowest]+sx] && test_loc(dun, xs[k]+sx, ys[k]+sy, s) == TRUE && test_loc(dun, xs[lowest]+sx, ys[lowest]+sy, s) == TRUE) {
												lowest = k;
												set = TRUE;
											}
										}
									}
								} else {
									for(k = 0; k < 8; k++) {
										px = xs[k]+sx;
										py = ys[k]+sy;
										if(px >= 0 && px < dun->w && py >= 0 && py < dun->h) {
											if(dun->d[py][px].h == 0 && dun->csnt[py][px] <= dun->csnt[ys[lowest]+sy][xs[lowest]+sx]) {
												lowest = k;
												set = TRUE;
											}
										}
									}
								}
								if(set == TRUE) {
									setPositionX(neu, xs[lowest] + sx);
									setPositionY(neu, ys[lowest] + sy);
									break;
								} else {
									setPositionX(neu, sx);
									setPositionY(neu, sy);
									break;
								}
							} else {
								if(getCreaturePcX(s) < sx)
									px = sx - 1;
								if(getCreaturePcX(s) > sx)
									px = sx + 1;
								if(getCreaturePcY(s) < sy)
									py = sy - 1;
								if(getCreaturePcY(s) > sy)
									py = sy + 1;

								if(test_loc(dun, px, py, s) == TRUE) {
									setPositionX(neu, px);
									setPositionY(neu, py);

									break;
								}
							}
						} else {
							goto PCEB;
						}
					} else {
						setCreaturePcX(s, getCreatureAPX(dun->ss, dun->pc));
						setCreaturePcY(s, getCreatureAPY(dun->ss, dun->pc));
						goto IN;
					}
				} else {
					PCEB: ;
					j = 0;
					EB: ;
					int c = rand() % 9;
					px = xs[c] + sx;
					py = ys[c] + sy;
					if(test_loc(dun, px, py, s) == FALSE && j < 8) {
						j++;
						goto EB;
					}
					if(test_loc(dun, px, py, s) == TRUE) {
						setPositionX(neu, px);
						setPositionY(neu, py);
					}

					break;
				}
			}
		}
	} else {
		return;
	}

	if(getPositionX(neu) < 0)
		setPositionX(neu, sx);
	if(getPositionY(neu) < 0)
		setPositionY(neu, sy);

	setCreatureAToX(dun->ss, sn, getPositionX(neu));
	setCreatureAToY(dun->ss, sn, getPositionY(neu));

	if(dun->ss[sn].to.x == dun->plyr->p.x && dun->ss[sn].to.y == dun->plyr->p.y) {
		int dam = dun->ss[sn].s.a->roll();
		if(dun->plyr->s.hp - dam <= 0)
			dun->go = true;
		else
			dun->plyr->s.hp -= dam;
	}

}

void add_creature(Dungeon * dun, Creature * s) {
	if(dun->ns < dun->ms) {
		dun->ns++;
	} else {
		goto END;
	}

	if(getCreatureC(s) == '@') {
		dun->pc = dun->ns - 1;
		s->color = WHITE;
    }

	s->sn = dun->ns -1;
	copyACreature(dun->ss, dun->ns -1, s);

	END: ;
}

Creature * gen_creature_fac(Dungeon * dun, char c, int x, int y, int r) {
	Creature* s = new Creature;

	if(c != '@'){
		s = dun->mf->GetMon();
		s->s.a->roll();
		if(r > 0 || s->s.tu == true) {
			int t = 0;
			PRNTT: ;
        	int r_id = rand() % dun->nr;
			x = (rand() % dun->r[r_id].w) + getPositionX(dun->r[r_id].tl);
			y = (rand() % dun->r[r_id].h) + getPositionY(dun->r[r_id].tl);

			if(getCreatureC(s) != '@' && dun->nr > 1) {
				setCreaturePX(s, x);
				setCreaturePY(s, y);

				Bool w_pc = FALSE;
				with_pc(dun, s, &w_pc);
				if(w_pc == TRUE && t < 8) {
					t++;
					goto PRNTT;
				}
			}
		} else {
			if(x < 0 || x > dun->w) {
				x = (rand() % (dun->w-2)) + 1;
        	}
			if(y < 0 || y > dun->h) {
				y = (rand() % (dun->h-2)) + 1;
			}
		}
	} else {
		s = initPC(dun);
	}
	return s;
}
