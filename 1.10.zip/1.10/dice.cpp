#include "dungeon.h"
#include <cstdio>
#include <stdlib.h>
#include <string>
#include <sstream>

// reference: http://stackoverflow.com/questions/5590381/easiest-way-to-convert-int-to-string-in-c#5591169
#define SSTR( x ) static_cast< std::ostringstream & >( \
        ( std::ostringstream() << std::dec << x ) ).str()

int	Dice::roll(void) {
	if(d == 0)
		return b;
	else
		return b + n * ((rand() % d) + 1);
}

std::string Dice::string(void) {
	return SSTR(b) + "+" + SSTR(n) + "d" + SSTR(d);
}

Dice::Dice(int base, int num, int die) {
	b = base;
	n = num;
	d = die;
}

Dice::Dice(void) {
	b = 0;
	n = 0;
	d = 0;
}
