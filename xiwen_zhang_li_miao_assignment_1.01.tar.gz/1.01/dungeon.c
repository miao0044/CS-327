#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <math.h>

#define MAX 10


typedef struct {
  int x;
  int y;
} Position;

typedef struct {
  Position  tl;    // top left
  Position  br;    // bottom right
  int      w;      // width
  int      h;      // height
  int      id;     // room ID
} Room;

typedef struct {
  int roomNum;       // number of rooms
  int hard[80][21];  // hardness
  char map[80][21];  // the symbol of map
  Room room[MAX];    // list of rooms
} Dungeon;


int hash (int a, int b){
  // generate a random int between a and b
  return (a + rand() % (b - a));
}


static void createMap(Dungeon *dun){
  // create an empty map with edges
  int y = 0, x = 0;
  for (y = 0; y < 21; y++){
    for(x = 0; x < 80; x++){
      if(y == 0 || y == 20){
        dun->map[x][y] = '-';
        dun->hard[x][y] = 255;
      }
      else if(x == 0 || x == 79){
        dun->map[x][y] = '|';
        dun->hard[x][y] = 255;
      }
      else{
        dun->map[x][y] = ' ';
        dun->hard[x][y] = hash(1, 254);
      }
    }
  }
}


int checkRoom(int x, int y, int a, int b, Dungeon *dun){
  // check if a room is valid
  int i, j;
  for(i = x; i < x + a; i++) {
    if(dun->hard[i][y - 1] == 0 || dun->hard[i][y + b] == 0)
      return 0;
  }
  for(j = y; j < y + b; j++) {
    if(dun->hard[x - 1][j] == 0 || dun->hard[x + a][j] == 0)
      return 0;
  }
  return 1;
}


static void spawnRoom(Dungeon *dun){
  // spawn rooms in map
  Room r;
  int x, y;
  int max = 10, min = 6;
  dun->roomNum = hash(min, max);
  int x_min = 3, y_min = 4, x_max = 8, y_max = 10;
  int x_size = 0, y_size = 0;
  int actual = 0;
  int pass = 1;
  int i, j;

  while(actual < dun->roomNum){
    x_size = hash(x_min, x_max);
    y_size = hash(y_min, y_max);
    x = hash(1, 19);
    y = hash(1, 78);
    pass = 1;
    if(x_size + x >= 20 || y_size + y >= 79){
      pass = 0;
    }
    else if(!checkRoom(y, x, y_size, x_size, dun)){
      pass = 0;
    }

    if(pass){
      for(i = y; i < y + y_size; i++){
        for(j = x; j < x + x_size; j++){
           dun->map[i][j] = '.';
           dun->hard[i][j] = 0;
        }
      }
      r.tl.x = x;
      r.tl.y = y;
      r.br.x = x + x_size - 1;
      r.br.y = y + y_size - 1;
      r.w = x_size;
      r.h = y_size;
      r.id = actual;
      dun->room[actual] = r;
      actual++;
    }
  }
  printf("Generated %d rooms.\n", dun->roomNum);
}


void print(Dungeon *dun) {
  // print dungeon in terminal
  int x, y;
  for(y = 0; y < 21; y++) {
    for(x = 0; x < 80; x++)
      printf("%c", dun->map[x][y]);
    printf("\n");
  }
}


static void spawnCor(Dungeon *dun) {
  // spawn path to connect all rooms
  int count = 1;
  int x1, y1, x2, y2;

  while(count < dun->roomNum) {
    x1 = (dun->room[count - 1].tl.x + dun->room[count - 1].br.x)/2;
    y1 = (dun->room[count - 1].tl.y + dun->room[count - 1].br.y)/2;
    x2 = (dun->room[count].tl.x + dun->room[count].br.x)/2;
    y2 = (dun->room[count].tl.y + dun->room[count].br.y)/2;

    while(x1 != x2) {
      if(x1 > x2) {
        x1--;
      }
      else if(x1 < x2) {
        x1++;
      }

      if(dun->hard[y1][x1] != 0) {
        dun->map[y1][x1] = '#';
        dun->hard[y1][x1] = 0;
      }
    }

    while(y1 != y2) {
      if(y1 > y2) {
        y1--;
      }
      else if(y1 < y2) {
        y1++;
      }

      if(dun->hard[y1][x1] != 0) {
        dun->map[y1][x1] = '#';
        dun->hard[y1][x1] = 0;
      }
    }
    count++;
  }
}


int main(int argc, char* argv[]){
  srand(time(NULL));
  Dungeon dun;
  createMap(&dun);
  spawnRoom(&dun);
  spawnCor(&dun);
  print(&dun);
}
