#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <math.h>
#include <stdint.h>
#include <endian.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <limits.h>
#include <unistd.h>
#include <ncurses.h>
#include "binaryheap.h"
#include "dungeon.h"

int compareInteger(const void *key, const void *with) {
	return (const int) ((*(Tile_Node *) key).cost - (*(Tile_Node *) with).cost);
}

int compareMove(const void *key, const void *with) {
	Character k = *(Character *) key;
	Character w = *(Character *) with;

	return k.t-w.t;
}

int calculateHardness(int h) {
	int hc = 0;

	if(h >= 0 && h < 85) {
		return 1;
	}
	if(h > 84 && h < 171) {
		return 2;
	}
	if(h > 170 && h < 255) {
		return 3;
	}

	return hc;
}

//dijkstra for tunnelling
void newMapTun(dun * dun) {
	BinaryHeap h;
	Tile_Node t[dun->h][dun->w];

	initializeBinaryHeap(&h, compareInteger, NULL);


	int xs[8] = {-1,0,1,1,1,0,-1,-1};
	int ys[8] = {-1,-1,-1,0,1,1,1,0};

	int i;
	int j;


	for(i = 0; i < dun->h; i++) {
		for(j = 0; j < dun->w; j++) {
			t[i][j].y = i;
			t[i][j].x = j;
			t[i][j].cost = INT_MAX;
			t[i][j].v = 0;
		}
	}

//set player cost to be 0
	int px = dun->carr[dun->pc].p.x;
	int py = dun->carr[dun->pc].p.y;
	t[py][px].cost = 0;
	t[py][px].v = 1;
	deleteBinaryInsert(&h, &t[py][px]);
//calculate primary cost

	BinaryHeapNode	*p;

	while((p = binaryHeapRemoveMin(&h))) {
		int hx = ((Tile_Node *) p)->x;
		int hy = ((Tile_Node *) p)->y;
		int tc = ((Tile_Node *) p)->cost;

		int i;
		for(i = 0; i < 8; i++) {
			int x = hx + xs[i];
			int y = hy + ys[i];
			if(x > 0 && x < dun->w-1 && y > 0 && y < dun->h-1) {
				int hard = dun->t[y][x].h;
				if(hard < 255) {
						int trial_cost = tc + calculateHardness(hard);
						if((t[y][x].cost > trial_cost && t[y][x].v == 1) || t[y][x].v == 0) {
							t[y][x].cost = tc + calculateHardness(hard);
							t[y][x].v = 1;

							deleteBinaryInsert(&h, (void *) &t[y][x]);
						}
				}
			}
		}
	}

//copy heat map to dun
	for(i = 0; i < dun->h; i++) {
		for(j = 0; j < dun->w; j++) {
			dun->cost[i][j] = t[i][j].cost;
		}
	}


//clean heap
	deleteBinaryHeap(&h);
}

//run dijkstra's algorithm to create a map with non-tunnelling cost
void newMapNonTun(dun * dun) {
	BinaryHeap h;
	Tile_Node t[dun->h][dun->w];

	initializeBinaryHeap(&h, compareInteger, NULL);

	int xs[8] = {-1,0,1,1,1,0,-1,-1};
	int ys[8] = {-1,-1,-1,0,1,1,1,0};

	int i;
	int j;

	for(i = 0; i < dun->h; i++) {
		for(j = 0; j < dun->w; j++) {
			t[i][j].y = i;
			t[i][j].x = j;
			t[i][j].cost = INT_MAX;
			t[i][j].v = 0;
		}
	}

//set the character cost to be 0
	int px = dun->carr[dun->pc].p.x;
	int py = dun->carr[dun->pc].p.y;
	t[py][px].cost = 0;
	t[py][px].v = 1;
	deleteBinaryInsert(&h, &t[py][px]);


	BinaryHeapNode	*p;

	while((p = binaryHeapRemoveMin(&h))) {
		int hx = ((Tile_Node *) p)->x;
		int hy = ((Tile_Node *) p)->y;
		int tc = ((Tile_Node *) p)->cost;

		int i;
		for(i = 0; i < 8; i++) {
			int x = hx + xs[i];
			int y = hy + ys[i];
			if(x > 0 && x < dun->w-1 && y > 0 && y < dun->h-1) {
				int hard = dun->t[y][x].h;
				if(hard == 0) {
						int trial_cost = tc + calculateHardness(hard);
						if((t[y][x].cost > trial_cost && t[y][x].v == 1) || t[y][x].v == 0) {
							t[y][x].cost = tc + calculateHardness(hard);
							t[y][x].v = 1;

							deleteBinaryInsert(&h, (void *) &t[y][x]);
						}
				}
			}
		}

	}

//add the heat map to run dungeon
	for(i = 0; i < dun->h; i++) {
		for(j = 0; j < dun->w; j++) {
			dun->csnt[i][j] = t[i][j].cost;
		}
	}


//clean up the heap
	deleteBinaryHeap(&h);
}


/* add a character to the dun */
void addCharacter(dun * dun, Character s) {
	if(dun->ns < dun->ms) {
		dun->ns++;
	} else {
		goto END;
	}

	if(s.c == '@') {
		dun->pc = dun->ns - 1;
	}

	dun->carr[dun->ns - 1] = s;

	END: ;
}

/* generate a character, because in-line structs are icky */
Character spawnCharacter(dun * dun, char c, int x, int y, int r) {
	Character s;

	/* place in a room if 1 or more. implicitly random */
	if(r > 0) {
		int r_id = rand() % dun->roomNum;
		x = (rand() % dun->room[r_id].w) + dun->room[r_id].tl.x;
		y = (rand() % dun->room[r_id].h) + dun->room[r_id].tl.y;
	} else {
		/* randomize location if a valid one is not provided */
		if(x < 0 || x > dun->w) {
			x = (rand() % (dun->w-2)) + 1;
		}
		if(y < 0 || y > dun->h) {
			y = (rand() % (dun->h-2)) + 1;
		}
	}

	s.p.x = x;
	s.p.y = y;
	s.c = c;

	return s;
}

/* reads from a dun file */
void loadDungeon(dun * dun, char * path) {
	FILE * file;
	file = fopen(path, "rb+");
	if(file == NULL) {
		fprintf(stderr, "FILE ERROR: Could not open dun file at %s! loadDungeon()\n", path);
        exit(1);
	}

	/* read the file-type marker */
	fseek(file, 0, SEEK_SET);
	char marker[12];
	fread(marker, 1, 12, file);
	/* read the file version marker */
	fseek(file, 12, SEEK_SET);
	uint32_t fv;
	uint32_t fv_be;
	fread(&fv_be, sizeof(uint32_t), 1, file);
	fv = be32toh(fv_be);
	dun->version = fv;
	/* read the size of file */
	fseek(file, 16, SEEK_SET);
	uint32_t size;
	uint32_t size_be;
	fread(&size_be, sizeof(uint32_t), 1, file);
	size = be32toh(size_be);
	dun->size = size;
	 fseek(file, 20, SEEK_SET);
    int pcx;       //pc position x
    int pcy;       //pc position y
    fread(&pcx, sizeof(uint8_t), 1, file);
	dun->pc = 0;
    dun->carr[0].p.x= (int8_t) pcx;
    fread(&pcy, sizeof(uint8_t), 1, file);
    dun->carr[0].p.y= (int8_t) pcy;
	/* read the hardness values in */
	fseek(file, 22, SEEK_SET);
	int i;
	int j;
	for(i = 0; i < dun->h; i++) {
		for(j = 0; j < dun->w; j++) {
			int h;
			int8_t h_8;
			fread(&h_8, sizeof(int8_t), 1, file);
			h = (int) h_8;
			dun->t[i][j].h = h;
		}
	}
	/* read in rooms in dun */
	fseek(file, 1702, SEEK_SET);

	int rm;                     //number of rooms
    fread(&rm, sizeof(int16_t), 1, file);
    dun->roomNum = (int16_t) rm;
	/* might want to make this just counted in 4's by the loop below, but w/e, math, amirite? */
	int ri = 0;
	int room_count = dun->roomNum;
	dun->room = calloc(room_count, sizeof(Room));
	/* could probably be replaced with a getpos() call for complete-ness */
	fseek(file, 1704, SEEK_SET);
	int pos;
	for(pos = 0; pos < dun->roomNum; pos += 1) {
		int x_8;
		int w_8;
		int y_8;
		int h_8;
		fread(&x_8, sizeof(int8_t), 1, file);
		fread(&w_8, sizeof(int8_t), 1, file);
		fread(&y_8, sizeof(int8_t), 1, file);
		fread(&h_8, sizeof(int8_t), 1, file);

		dun->room[ri].tl.x = (int8_t) x_8;
		dun->room[ri].w = (int8_t) w_8;
		dun->room[ri].tl.y = (int8_t) y_8;
		dun->room[ri].h = (int8_t) h_8;
		dun->room[ri].br.x = ((int8_t) x_8) + dun->room[ri].w-1;
		dun->room[ri].br.y = ((int8_t) y_8) + dun->room[ri].h-1;



		ri++;
	}
    // load number of upstairs
    fseek(file, 1704 + dun->roomNum * 4, SEEK_SET);
    int fun;                         //number of upper stair in file
    fread(&fun, sizeof(int16_t), 1, file);
    dun->un = (int16_t) fun;
    fseek(file, 1706 + dun->roomNum * 4, SEEK_SET);
    int upc;                         //upper stair count
    for (upc = 0; upc < dun->un; upc++) {
     int x, y;
    fread(&x, sizeof(int8_t), 1, file);
    fread(&y, sizeof(int8_t), 1, file);

    dun->upStair[upc].p.x = (int8_t) x;
    dun->upStair[upc].p.y = (int8_t) y;
    dun->upStair[upc].ud = 1;
   }
    fseek(file, 1706 + dun->roomNum * 4 + dun->un * 2, SEEK_SET);
    int fdn;                         //number of down stair in file
    fread(&fdn, sizeof(int16_t), 1, file);
    dun->dn = (int16_t) fdn;
	 fseek(file, 1708 + dun->roomNum * 4 + dun->un * 2, SEEK_SET);
    int dpc;                        //down stair count
    for (dpc = 0; dpc < dun->dn; dpc++) {
    int x, y;
    fread(&x, sizeof(int8_t), 1, file);
    fread(&y, sizeof(int8_t), 1, file);

    dun->downStair[dpc].p.x = (int8_t) x;
    dun->downStair[dpc].p.y = (int8_t) y;
    dun->downStair[dpc].ud = 0;
  }
	/* populate the rooms and corridors if not in rooms */
	/* add rooms to the dun buffer */
	int h;
	for(h = 0; h < dun->roomNum; h++) {
		for(i = dun->room[h].tl.y; i < dun->room[h].br.y+1; i++) {
			for(j = dun->room[h].tl.x; j < dun->room[h].br.x+1; j++) {
				dun->t[i][j].c = '.';
			}
		}
	}

	/* add corridors to the dun buffer */
	for(i = 0; i < dun->h; i++) {
		for(j = 0; j < dun->w; j++) {
			if(dun->t[i][j].c != '.' && dun->t[i][j].h == 0) {
				dun->t[i][j].c = '#';
				dun->t[i][j].p = 1;
			}
		}
	}

	for (upc = 0; upc < dun->un; upc++) {
	  int x = dun->upStair[upc].p.x;
	  int y = dun->upStair[upc].p.y;
	  dun->t[x][y].c = '<';
	}
	for (dpc = 0; dpc < dun->dn; dpc++) {
	  int x = dun->downStair[dpc].p.x;
	  int y = dun->downStair[dpc].p.y;
	  dun->t[x][y].c = '>';
	}


	fclose(file);
}

/* writes the dun file to ~/.rlg327/dun */
void saveDungeon(dun * dun, char * p) {
		// get file location set up
	FILE * f;
	char * home = getenv("HOME");
	char * path;
	path = malloc((strlen(home) + 50) * sizeof(char));
	strcpy(path, home);
	strcat(path, "/.rlg327");
	// if the file is not exist, create one
	mkdir(path, S_IRWXU);

	f = fopen(p, "wb+");
	if(f == NULL) {
		printf("file opening error while saving\n");
    exit(1);
	}
	/* write the file-type marker */
	fseek(f, 0, SEEK_SET);
	char marker[13];
	strcpy(marker, "RLG327-S2021");
	fwrite(marker, sizeof(char), 12, f);
	/* write the file version marker */
	fseek(f, 12, SEEK_SET);
	uint32_t fv = 0;
	uint32_t fv_be = htobe32(fv);
	fwrite(&fv_be, sizeof(uint32_t), 1, f);
	/* write the size of the file ;; unsure how to properly calculate */
	fseek(f, 16, SEEK_SET);
 	uint32_t size = 1693 + (4 * dun->roomNum);
	uint32_t size_be = htobe32(size);
	fwrite(&size_be, sizeof(uint32_t), 1, f);
		// save pc position
    fseek(f, 20, SEEK_SET);
    uint8_t pcx;       //pc position x
    uint8_t pcy;       //pc position y
    pcx = (int8_t)(dun->carr[dun->pc].p.x);
    fwrite(&pcx, sizeof(uint8_t), 1, f);
    pcy = (int8_t)(dun->carr[dun->pc].p.y);
    fread(&pcy, sizeof(uint8_t), 1, f);
	/* row-major dun matrix */
	fseek(f, 22, SEEK_SET);
	int pos = 22;
	int i;
	int j;

	for(i = 0; i < dun->h; i++) {
		for(j = 0; j < dun->w; j++) {
			fseek(f, pos, SEEK_SET);
			int8_t h;
			h = (int8_t)(dun->t[i][j].h);
			fwrite(&h, sizeof(int8_t), 1, f);
			pos++;
		}
	}
    fseek(f, 1702, SEEK_SET);
    int16_t rm;                        //number of rooms
    rm = (int16_t)dun->roomNum;
    fwrite(&rm, sizeof(int16_t), 1, f);
	/* room positions ;; 4 bytes per room */
	fseek(f, 1704, SEEK_SET);
	for(i = 0; i < dun->roomNum; i++) {
		int8_t x = (int8_t) dun->room[i].tl.x;
		int8_t y = (int8_t) dun->room[i].tl.y;
		int8_t w = (int8_t) dun->room[i].w;
		int8_t h = (int8_t) dun->room[i].h;

		fwrite(&x, sizeof(int8_t), 1, f);
		fwrite(&y, sizeof(int8_t), 1, f);
		fwrite(&w, sizeof(int8_t), 1, f);
		fwrite(&h, sizeof(int8_t), 1, f);
	}
  fseek(f, 1704 + dun->roomNum * 4, SEEK_SET);
  int16_t fun;                           //number of upper stair in file
  fun = (int16_t) dun->un;
  fwrite(&fun, sizeof(int16_t), 1, f);
   fseek(f, 1706 + dun->roomNum * 4, SEEK_SET);
  int upc;                             //upper stair count
  for (upc = 0; upc < dun->un; upc++) {
    int8_t x, y;
    x = (int8_t) dun->upStair[upc].p.x;
    y = (int8_t) dun->upStair[upc].p.y;
    fwrite(&x, sizeof(int8_t), 1, f);
    fwrite(&y, sizeof(int8_t), 1, f);
  }
   fseek(f, 1706 + dun->roomNum * 4 + dun->un * 2, SEEK_SET);
   int16_t fdn;                         //number of upper stair in file
   fdn = (int16_t) dun->dn;
   fwrite(&fdn, sizeof(int16_t), 1, f);
  fseek(f, 1708 + dun->roomNum * 4 + dun->un * 2, SEEK_SET);
  int dpc;                         //down stair count
  for (dpc = 0; dpc < dun->dn; dpc++) {
    int8_t x, y;
    x = (int8_t) dun->downStair[dpc].p.x;
    y = (int8_t) dun->downStair[dpc].p.y;
    fwrite(&x, sizeof(int8_t), 1, f);
    fwrite(&y, sizeof(int8_t), 1, f);
  }
	free(path);
	fclose(f);
}

/* monster list view */
void monster_list(dun * dun) {
	clear();

	/* monster view array and population */
	char mons [dun->ns-1][30];
	int i;
	for(i = 1; i < dun->ns; i++) {
		char ns[6];
		char ew[5];

		int hd = dun->carr[0].p.y - dun->carr[i].p.y;
		int wd = dun->carr[0].p.x - dun->carr[i].p.x;

		if(hd > 0)
			strcpy(ns, "north");
		else
			strcpy(ns, "south");

		if(wd > 0)
			strcpy(ew, "west");
		else
			strcpy(ew, "east");

		sprintf(mons[i-1], "%c, %2d %s and %2d %s", dun->carr[i].c, abs(hd), ns, abs(wd), ew);
	}

	/* secondary window */
	WINDOW *w;
	w = newwin(24, 80, 0, 0);
	Bool scroll = FALSE;
	int top = 0;
	int bot;
	if(24 < dun->ns -1) {
		scroll = TRUE;
		bot = 23;
	} else {
		bot = dun->ns -2;
	}

	int j;
	for(;;) {
		/* put the monster view to the screen */
		for(i = top, j = 0; i < dun->ns -1 && i <= bot && j < 24; i++, j++) {
			mvprintw(j, 0, mons[i]);
		}

		/* handle user interaction */
		MLV: ;
		int32_t k;
		k = getch();

		switch(k) {
			case KEY_UP:
				/* scroll up */
				if(scroll == FALSE)
					goto MLV;

				if(top-1 >= 0) {
					top--;
					bot--;
				}
				clear();

				break;
			case KEY_DOWN:
				/* scroll down */
				if(scroll == FALSE)
					goto MLV;

				if(bot+1 < dun->ns-1) {
					bot++;
					top++;
				}
				clear();

				break;
			case 27:
				/* ESC */
				return;
				break;
			default:
				goto MLV;
		}

		wrefresh(w);
	//	printDun(dun, 0, 0);
	}

	delwin(w);
	printDun(dun, 0, 0);
}


/* processes pc movements ;; validity checking is in monsters.c's gen_move_sprite() */
void parse_pc(dun *dun, Bool * run, Bool * regen) {
	GCH: ;
	int32_t k;
  int i;
	k = getch();
	if(k == 'Q') {
		*run = FALSE;
		return;
	}

	switch(k) {
		case 'h':
			H: ;
			dun->carr[dun->pc].to.x = dun->carr[dun->pc].p.x - 1;
			break;
		case '4':
			goto H;
		case 'l':
			L: ;
			dun->carr[dun->pc].to.x = dun->carr[dun->pc].p.x + 1;
			break;
		case '6':
			goto L;
		case 'k':
			K: ;
			dun->carr[dun->pc].to.y = dun->carr[dun->pc].p.y - 1;
			break;
		case '8':
			goto K;
		case 'j':
			J: ;
			dun->carr[dun->pc].to.y = dun->carr[dun->pc].p.y + 1;
			break;
		case '2':
			goto J;
		case 'y':
			Y: ;
			dun->carr[dun->pc].to.y = dun->carr[dun->pc].p.y - 1;
			dun->carr[dun->pc].to.x = dun->carr[dun->pc].p.x - 1;
			break;
		case '7':
			goto Y;
		case 'u':
			U: ;
			dun->carr[dun->pc].to.y = dun->carr[dun->pc].p.y - 1;
			dun->carr[dun->pc].to.x = dun->carr[dun->pc].p.x + 1;
			break;
		case '9':
			goto U;
		case 'n':
			N: ;
			dun->carr[dun->pc].to.y = dun->carr[dun->pc].p.y + 1;
			dun->carr[dun->pc].to.x = dun->carr[dun->pc].p.x + 1;
			break;
		case '3':
			goto N;
		case 'b':
			B: ;
			dun->carr[dun->pc].to.y = dun->carr[dun->pc].p.y + 1;
			dun->carr[dun->pc].to.x = dun->carr[dun->pc].p.x - 1;
			break;
		case '1':
			goto B;
		case '<':
			/* stair up */
      for (i = 0; i < dun->un; i++) {
				printf("%d   %d     %d   %d\n", dun->carr[0].p.x, dun->upStair[i].p.x, dun->carr[0].p.y, dun->upStair[i].p.y);
			  if(dun->carr[0].p.x == dun->upStair[i].p.y && dun->carr[0].p.y == dun->upStair[i].p.x) {
				  *regen = TRUE;
					printf("  %d   %d     %d   %d\n", dun->carr[0].p.x, dun->upStair[i].p.x, dun->carr[0].p.y, dun->upStair[i].p.y);
			    break;
        }
      }
		case '>':
			/* stair down */
      for (i = 0; i < dun->dn; i++) {
				printf("%d   %d     %d   %d\n", dun->carr[0].p.x, dun->downStair[i].p.x, dun->carr[0].p.y, dun->downStair[i].p.y);
			  if(dun->carr[0].p.x == dun->downStair[i].p.y && dun->carr[0].p.y == dun->downStair[i].p.x) {
				  *regen = TRUE;
					printf("  %d   %d     %d   %d\n", dun->carr[0].p.x, dun->downStair[i].p.x, dun->carr[0].p.y, dun->downStair[i].p.y);
			    break;
        }
      }
		case '5':
			break;
		case ' ':
			break;
		case 'm':
			monster_list(dun);
			printDun(dun, 0, 0);
			goto GCH;
		default:
			goto GCH;
	}

    /* movement validity check */
	if(dun->t[dun->carr[dun->pc].to.y][dun->carr[dun->pc].to.x].h > 0) {
		dun->carr[dun->pc].to.x = dun->carr[dun->pc].p.x;
		dun->carr[dun->pc].to.y = dun->carr[dun->pc].p.y;
	} else {
		dun->carr[dun->pc].p.x = dun->carr[dun->pc].to.x;
		dun->carr[dun->pc].p.y = dun->carr[dun->pc].to.y;
	}
	dun->carr[0].t += (100 / dun->carr[0].s.s);

    /* check for killing an NPC */
    int sn = 0;
	for(i = 1; i < dun->ns; i++) {
		if(i != sn) {
			if((dun->carr[i].to.x == dun->carr[sn].to.x) && (dun->carr[i].to.y == dun->carr[sn].to.y) && dun->carr[sn].a == TRUE)
				dun->carr[i].a = FALSE;
        }
    }
}


void argvPos(int argc, char ** argv, int i, int *save, int *load, int *pathc, int *cp, int *nm, int *nnc) {
  if (strcmp(argv[i], "--save") == 0) {
    *save = 1;
  } else if (strcmp(argv[i], "--load") == 0) {
    *load = 1;
  } else if (strcmp(argv[i], "-f") == 0) {
    *pathc = 1;
    *cp = i + 1;
    if (i + 1 > argc - 1) {
      printf("Please enter correct file name\n");
      *pathc = 0;
    }
  } else if(strcmp(argv[i], "--nummon") == 0) {
		*nm = atoi(argv[i+1]);
	} else if(strcmp(argv[i], "--no-ncurses") == 0) {
    *nnc = 1;
  }
}


/* Basic procedural dun generator */
int main(int argc, char * argv[]) {
	/*** process commandline arguments ***/
	int max_args = 8;
	int save = 0;
	int load = 0;
	int pathChange = 0;
  int nnc = FALSE;
	int num_mon = 1;
	int cp = 0;
	if(argc > 2 && argc <= max_args) {
		// save and load
		int i;
		for(i = 1; i < argc; i++) {
			argvPos(argc, argv, i, &save, &load, &pathChange, &cp, &num_mon, &nnc);
		}
	} else if(argc == 2) {
		// save or load
		argvPos(argc, argv, 1, &save, &load, &pathChange, &cp, &num_mon, &nnc);
	} else if(argc > max_args) {
		printf("Max commandline arguments exceed\n");
	}

	// set up seed
  srand(time(NULL));

  // set up file path
	char *home = getenv("HOME");
	char *path = malloc((strlen(home) + 50) * sizeof(char));
	strcpy(path, home);
	strcat(path, "/.rlg327");
	if(pathChange == 0) {
		strcat(path, "/dungeon");
	} else {
		strcat(path, "/");
		strcat(path, argv[cp]);
	}

	Bool regen = FALSE;
	Character p_pc;

	DUNGEN: ;

	dun dun = initDun(21, 80, 12);

	if(load == 0) {
		spawnDun(&dun);
		spawnCorridors(&dun);
		spawnStair(&dun);
	} else {
		loadDungeon(&dun, path);
	}

	Character pc = gen_sprite(&dun, '@', -1, -1, 1);
	add_sprite(&dun, pc);
    int i;
	for(i = 0; i < num_mon; i++) {
		Character m = gen_sprite(&dun,'m' , -1, -1, 1);
		m.sn = i;
	add_sprite(&dun, m);
	}

	newMapNonTun(&dun);
	newMapTun(&dun);

  if(regen == 1) {
		int px = dun.carr[0].p.x;
		int py = dun.carr[0].p.y;
		dun.carr[0] = p_pc;
		dun.carr[0].p.x = px;
		dun.carr[0].p.y = py;
		dun.carr[0].to.x = px;
		dun.carr[0].to.y = py;
	}

	for(i = 0; i < dun.ns; i++) {
		gen_move_sprite(&dun, i);
	}

  if(regen == TRUE)
		goto PNC;

  /* ncurses or not ;; this will likely amount to nothing */
  int printer_switch = 0;
  //void (*printer)(dun*, int, int);
  if(nnc == FALSE) {
    printer_switch = 0;
		//printer = &printDun;
		initscr();
		raw();
		noecho();
		curs_set(0);
		set_escdelay(25);
		keypad(stdscr, TRUE);
	} else {
    printer_switch = 1;
		//printer = &printDun_nnc;
	}

  PNC: ;
	regen = FALSE;

  printDun(&dun, 0, 0);
	Bool first = TRUE;
	Bool run = TRUE;
	while(run == TRUE) {

		int l = 0;
		for(i = 0; i < dun.ns; i++) {
			if(dun.carr[i].t < dun.carr[l].t) {
				l = i;
			}
		}

    if(l == dun.pc || first == TRUE) {
			parse_pc(&dun, &run, &regen);
			if(regen == 1) {
				p_pc = dun.carr[0];
				goto DUNFREE;
			}

      newMapNonTun(&dun);
      newMapTun(&dun);

      int sn = 0;
			for(i = 1; i < dun.ns; i++) {
				if(i != sn) {
					if((dun.carr[i].p.x == dun.carr[sn].p.x) && (dun.carr[i].p.y == dun.carr[sn].p.y) && dun.carr[sn].a == TRUE)
						dun.carr[i].a = FALSE;
				}
			}

      printDun(&dun, 0, 0);
    } else {
        parse_move(&dun, l);
  		gen_move_sprite(&dun, l);
    }

    refresh();

		if(dun.go == TRUE || dun.carr[dun.pc].a == FALSE)
			break;

		Bool any = check_any_monsters(&dun);
		if(any == FALSE) {
			printf("Congratulations, you just won the game.\n");
			goto END;
		}
		first = FALSE;
	}

  if (printer_switch == 0) {
    printDun(&dun, 0, 0);
  } else if (printer_switch == 1) {
    printDun_nnc(&dun, 0, 0);
  }
  //printer(&dun, 0, 0);

	END:
    delwin(stdscr);
	endwin();

	if(save == 1) {
		saveDungeon(&dun, path);
	}

  DUNFREE: ;

	/* free our arrays */
	for(i = 0; i < dun.h; i++) {
		free(dun.t[i]);
	}
	free(dun.t);
	for(i = 0; i < dun.h; i++) {
		free(dun.p[i]);
	}
	free(dun.p);
	free(dun.room);
	free(dun.carr);
	for(i = 0; i < dun.h; i++) {
		free(dun.csnt[i]);
	}
	free(dun.csnt);
	for(i = 0; i < dun.h; i++) {
		free(dun.cost[i]);
	}
	free(dun.cost);

  if(regen == TRUE)
		goto DUNGEN;

	free(path);
	return 0;
}
