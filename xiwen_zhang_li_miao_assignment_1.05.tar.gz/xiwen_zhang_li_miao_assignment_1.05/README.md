By: Xiwen Zhang (xiwenz), Li Miao (miao0044)

In this project, a 80x21 dungeon map is generated. The dungeon is surrounded by edges with hardness of 255, and contains 6-10 rooms. 
Added Dijkstra's algorithm to calculate the distance between each tile to player. Prints 3 maps: original map, non-tunneling map, and tunneling map.
Type "./dungeon --nummon xxx" to randomly generate xxx monsters on map with random behaviors.
Users can control the character movements through assigned keys in assignment description. 
