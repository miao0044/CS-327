#ifndef dungeon
#define dungeon
#include "binaryheap.h"

#define MAX 10
#define	TRUE	1
#define	FALSE	0
typedef int bool;

typedef struct {
	int		h;	/* hardness */
	char	c;	/* visual character */
	int		p;	/* mark 1 if path, 0 if not a path (corridors) */
} Tile;

typedef struct {
	int	x; /* x coordinate */
	int	y; /* y coordinate */
} Position;

/* maybe make these pointers? */
typedef struct {
	int prev; /* previous room in the path (using Room.id) */
	int next; /* room the path leads to (using Room.id) */
} Path;

typedef struct {
    bool    in; /* intelligence */
    bool    tel; /* telepathy */
    bool    tun; /* tunneling ability */
    bool    err; /* erratic behaviour */
    int     s;  /* speed ;; pc has 10 ; 5-20 */
} Stats;

typedef struct {
	Position	p;	/* position of the sprite in the dungeon */
	char		c;	/* character to print for the sprite */
  Stats       s;	/* stats for a sprite */
	int			t;	/* turn count */
	Position	to;	/* to move to */
	int			sn;	/* sprite number */
	Position	pc;	/* last known location of the PC */
	bool		a;	/* alive T/F */
} Character;

typedef struct {
	Position	tl;		/* top left coordinate of the room, used as the core point of reference */
	Position	br;		/* bottom right coordinate of the room as per above */
	int			w;		/* width */
	int			h;		/* height */
	int			id;		/* room ID, potentially useful for organization */
	int			p;		/* mark 1 if processed; 0 if not processed (corridors) */
	Position	center;	/* "center" point; very rough, might need improved */
	int			c;		/* if connected or not; 1/0 switch */
} Room;

typedef struct {
  Position p;        // position of stair
  int ud;            // 1 = up; 0 = down
} Stair;

typedef struct {
	Tile 	**	t;		/* dun buffer */
	Tile 	**	p;		/* print buffer */
	int			h;		/* height */
	int			w;		/* width */
	int			roomNum; 	/* number of rooms */
	int			mr;		/* max rooms */
	Room 	*	room;		/* rooms buffer */
	int			version;		/* file version */
	int			size;		/* file size */
	int         un;     // upper stair number
	int		    dn;     // down stair number
	Stair *     upStair;    // upstairs
	Stair *     downStair;  // downstairs
	Character	*	carr;		/* character array */
	int			ns;		/* number of characters */
	int			ms;		/* max number of characters */
	int		**	csnt;
	int		**	cost;	/* costs for djikstra's map */
	int			pc;		/* location of PC in Characters array (.ss) */
	bool    go;
	int     tn;
} dun;

typedef struct {
	int x;
	int y;
	int cost;
	int v;
} Tile_Node;

typedef struct {
	int			sn;	/* sprite number */
	int 		speed;	/* speed of the Sprite */
	int			turn;	/* turn counter */
	Position	to;		/* where we move to */
} Event;

/*** Function prototypes ***/
/* monsters.c */
void add_sprite(dun * dungeon, Character s);
Character gen_sprite(dun * dungeon, char c, int x, int y, int r);
void gen_move_sprite(dun * dungeon, int sn);
void parse_move(dun * dungeon, int sn);
bool check_any_monsters(dun * dungeon);
void map_dungeon_t(dun * dungeon);

#endif
