By: Xiwen Zhang (xiwenz), Li Miao (miao0044)

In this project, a 80x21 dungeon map is generated. 
The dungeon is surrounded by edges with hardness of 255, and contains 6-10 rooms. 
Each room at least has a size of 4x3. 
All rooms were connected by coordinators with hardness of 0.
Random stairs are generated to allow players go up and down. 
The program can load and save dungeon maps in a hidden directory. 

- saveFile (line 61): save generated dungeon map to a hidden '/.rlg327' under the home directory
- loadFile (line 180): load dungeon map from the hidden '/.rlg327' directory under the home directory
- hash (line 332): generate a random int between a and b
- print (line 339): print the dungeon in the terminal
- spawnRoom (line 389): spawn 6-10 rooms on the map
- isConnected (line 465): check if all rooms are connected
- spawnCor (line 476): spawn path to connect all rooms
- blankDun (line 573): spawn an empty dungeon
- initDun (line 612): generate a new dungeon
- spawnStair (line 640): spawn upStairs and downStairs randomly in all rooms and corridors 
- argvPos (line 678): helper function to process cmd argvs for main


