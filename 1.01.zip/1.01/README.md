By: Xiwen Zhang (xiwenz), Li Miao (miao0044)

In this project, a 80x21 dungeon map is generated. The dungeon is surrounded by edges with hardness of 255, and contains 6-10 rooms. Each room at least has a size of 4x3. All rooms were connected by coordinators with hardness of 0.
- hash (line 31): generate a random int between a and b
- drop_center (line 37): drop sand at center
- createMap (line 93): create an 80x21 empty map with edges of hardness 255, and random hardness for tiles inside
- checkRoom (line 59): check if a room is valid
- spawnRoom (line 74): spawn 6-10 rooms on the map
- print (line 121): print dungeon tiles in terminal
- spawnCor (line 132): spawn path to connect all rooms
