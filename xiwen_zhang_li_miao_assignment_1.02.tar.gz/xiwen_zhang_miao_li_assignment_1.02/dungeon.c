#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <math.h>
#include <stdint.h>
#include <endian.h>
#include <sys/stat.h>
#include <sys/types.h>

#define	MAX 10

typedef struct {
  int x;
  int y;
} Position;

typedef struct {
  int h;           // hardness
  char c;          // character for printing
  int p;           // 1 = path, 0 = not path
} Tile;

typedef struct {
  Position  tl;    // top left
  Position  br;    // bottom right
	Position center;    // center point
	int p;           // 1 = processed, 0 = not processed
  int c;           // 1 = connected, 0 = not connected
  int w;           // width
  int h;           // height
  int id;          // room ID
} Room;

typedef struct {
  Position p;        // position of stair
  int ud;            // 1 = up; 0 = down
} Stair;

typedef struct {
	int prev;             // staring room
	int next;             // end room
} Cor;

typedef struct {
	int roomNum;       // number of rooms
	Tile ** t;         // list of tiles
	Tile ** p;         // for printing
	Room *room;        // list of rooms
	Position PC;       // position of character
	int un;            // upper stair number
	int dn;            // down stair number
	Stair *upStair;    // upstairs
	Stair *downStair;  // downstairs
	int version;       // version
	int size;          // file size
} Dungeon;


// save a dungeon game
void saveFile(Dungeon * dun, char * p) {
	// get file location set up
	FILE * f;
	char * home = getenv("HOME");
	char * path;
	path = malloc((strlen(home) + 50) * sizeof(char));
	strcpy(path, home);
	strcat(path, "/.rlg327");
	// if the file is not exist, create one
	mkdir(path, S_IRWXU);

	f = fopen(p, "wb+");
	if(f == NULL) {
		printf("file opening error while saving\n");
    exit(1);
	}

	// save file-type marker
	fseek(f, 0, SEEK_SET);
	char marker[13];
	strcpy(marker, "RLG327-S2021");
	fwrite(marker, sizeof(char), 12, f);

	// save file version
	fseek(f, 12, SEEK_SET);
	uint32_t fv = 0;
	uint32_t fvo = htobe32(fv);
	fwrite(&fvo, sizeof(uint32_t), 1, f);

	// save file size
	fseek(f, 16, SEEK_SET);
 	uint32_t fs = 1693 + (4 * dun->roomNum);
	uint32_t fso = htobe32(fs);
	fwrite(&fso, sizeof(uint32_t), 1, f);

	// save pc position
  fseek(f, 20, SEEK_SET);
  uint8_t pcx;       //pc position x
  uint8_t pcy;       //pc position y
  pcx = (int8_t)(dun->PC.x);
  fwrite(&pcx, sizeof(uint8_t), 1, f);
  pcy = (int8_t)(dun->PC.y);
  fread(&pcy, sizeof(uint8_t), 1, f);

	// save the hardness values
	fseek(f, 22, SEEK_SET);
	int mrk = 22;
	int i;
	int j;
	for(i = 0; i < 21; i++) {
		for(j = 0; j < 80; j++) {
			fseek(f, mrk, SEEK_SET);
			int8_t h;
			h = (int8_t)(dun->t[i][j].h);
			fwrite(&h, sizeof(int8_t), 1, f);
			mrk++;
		}
	}

	// save number of rooms
  fseek(f, 1702, SEEK_SET);
  int16_t rm;                        //number of rooms
  rm = (int16_t)dun->roomNum;
  fwrite(&rm, sizeof(int16_t), 1, f);

	// save rooms in dungeon
	fseek(f, 1704, SEEK_SET);
	for(i = 0; i < dun->roomNum; i++) {
		int8_t x = (int8_t) dun->room[i].tl.x;
		int8_t y = (int8_t) dun->room[i].tl.y;
		int8_t w = (int8_t) dun->room[i].w;
		int8_t h = (int8_t) dun->room[i].h;

		fwrite(&x, sizeof(int8_t), 1, f);
		fwrite(&y, sizeof(int8_t), 1, f);
		fwrite(&w, sizeof(int8_t), 1, f);
		fwrite(&h, sizeof(int8_t), 1, f);
	}

	// save number of upstairs
  fseek(f, 1704 + dun->roomNum * 4, SEEK_SET);
  int16_t fun;                           //number of upper stair in file
  fun = (int16_t) dun->un;
  fwrite(&fun, sizeof(int16_t), 1, f);

  // save positions of upper upstairs
  fseek(f, 1706 + dun->roomNum * 4, SEEK_SET);
  int upc;                             //upper stair count
  for (upc = 0; upc < dun->un; upc++) {
    int8_t x, y;
    x = (int8_t) dun->upStair[upc].p.x;
    y = (int8_t) dun->upStair[upc].p.y;
    fwrite(&x, sizeof(int8_t), 1, f);
    fwrite(&y, sizeof(int8_t), 1, f);
  }

  // save number of downstairs
  fseek(f, 1706 + dun->roomNum * 4 + dun->un * 2, SEEK_SET);
  int16_t fdn;                         //number of upper stair in file
  fdn = (int16_t) dun->dn;
  fwrite(&fdn, sizeof(int16_t), 1, f);

  // save positions of down upstairs
  fseek(f, 1708 + dun->roomNum * 4 + dun->un * 2, SEEK_SET);
  int dpc;                         //down stair count
  for (dpc = 0; dpc < dun->dn; dpc++) {
    int8_t x, y;
    x = (int8_t) dun->downStair[dpc].p.x;
    y = (int8_t) dun->downStair[dpc].p.y;
    fwrite(&x, sizeof(int8_t), 1, f);
    fwrite(&y, sizeof(int8_t), 1, f);
  }

	free(path);
	fclose(f);
}


// load a dungeon game
void loadFile(Dungeon * dun, char * p) {
	FILE * f;
	f = fopen(p, "rb+");
	if(f == NULL) {
		printf("file opening error while loading\n");
    exit(1);
	}

	// load file-type marker
	fseek(f, 0, SEEK_SET);
	char marker[12];
	fread(marker, 1, 12, f);

	// load file version
  fseek(f, 12, SEEK_SET);
  uint32_t fv;       //file version
  uint32_t fvo;      //file version original
  fread(&fvo, sizeof(uint32_t), 1, f);
  fv = be32toh(fvo);
  dun->version = fv;

	// load the size of file
  fseek(f, 16, SEEK_SET);
  uint32_t fs;       //file size
  uint32_t fso;      //file size original
  fread(&fso, sizeof(uint32_t), 1, f);
  fs = be32toh(fso);
  dun->size = fs;

	// load the position of PC
  fseek(f, 20, SEEK_SET);
  int pcx;       //pc position x
  int pcy;       //pc position y
  fread(&pcx, sizeof(uint8_t), 1, f);
  dun->PC.x = (int8_t) pcx;
  fread(&pcy, sizeof(uint8_t), 1, f);
  dun->PC.y = (int8_t) pcy;

	// load the hardness values
	fseek(f, 22, SEEK_SET);
	int i, j;
	for (i = 0; i < 21; i++) {
		for (j = 0; j < 80; j++) {
			int h;
			int8_t h_8;
			fread(&h_8, sizeof(int8_t), 1, f);
			h = (int) h_8;
			dun->t[i][j].h = h;
		}
	}

	// load number of rooms
  fseek(f, 1702, SEEK_SET);
  int rm;                     //number of rooms
  fread(&rm, sizeof(int16_t), 1, f);
  dun->roomNum = (int16_t) rm;

	// load rooms in dungeon
	fseek(f, 1704, SEEK_SET);
	int rmc;
	dun->room = calloc(dun->roomNum, sizeof(Room));
	for(rmc = 0; rmc < dun->roomNum; rmc++) {
		int x, y, w, h;
		fread(&x, sizeof(int8_t), 1, f);
		fread(&y, sizeof(int8_t), 1, f);
		fread(&w, sizeof(int8_t), 1, f);
		fread(&h, sizeof(int8_t), 1, f);

		dun->room[rmc].tl.x = (int8_t) x;
		dun->room[rmc].tl.y = (int8_t) y;
		dun->room[rmc].w = (int8_t) w;
		dun->room[rmc].h = (int8_t) h;
		dun->room[rmc].br.x = ((int8_t) x) + dun->room[rmc].w-1;
		dun->room[rmc].br.y = ((int8_t) y) + dun->room[rmc].h-1;
		dun->room[rmc].id = rmc;
	}

	// load number of upstairs
  fseek(f, 1704 + dun->roomNum * 4, SEEK_SET);
  int fun;                         //number of upper stair in file
  fread(&fun, sizeof(int16_t), 1, f);
  dun->un = (int16_t) fun;

  // load positions of upper upstairs
  fseek(f, 1706 + dun->roomNum * 4, SEEK_SET);
  int upc;                         //upper stair count
  for (upc = 0; upc < dun->un; upc++) {
    int x, y;
    fread(&x, sizeof(int8_t), 1, f);
    fread(&y, sizeof(int8_t), 1, f);

    dun->upStair[upc].p.x = (int8_t) x;
    dun->upStair[upc].p.y = (int8_t) y;
    dun->upStair[upc].ud = 1;
  }

  // load number of downstairs
  fseek(f, 1706 + dun->roomNum * 4 + dun->un * 2, SEEK_SET);
  int fdn;                         //number of down stair in file
  fread(&fdn, sizeof(int16_t), 1, f);
  dun->dn = (int16_t) fdn;

  // load positions of down upstairs
  fseek(f, 1708 + dun->roomNum * 4 + dun->un * 2, SEEK_SET);
  int dpc;                        //down stair count
  for (dpc = 0; dpc < dun->dn; dpc++) {
    int x, y;
    fread(&x, sizeof(int8_t), 1, f);
    fread(&y, sizeof(int8_t), 1, f);

    dun->downStair[dpc].p.x = (int8_t) x;
    dun->downStair[dpc].p.y = (int8_t) y;
    dun->downStair[dpc].ud = 0;
  }

	// add rooms to the dungeon map
	int h;
	for(h = 0; h < dun->roomNum; h++) {
		for(i = dun->room[h].tl.y; i < dun->room[h].br.y+1; i++) {
			for(j = dun->room[h].tl.x; j < dun->room[h].br.x+1; j++) {
				dun->t[i][j].c = '.';
			}
		}
	}

	// add corridors to the dungeon map
	for(i = 0; i < 21; i++) {
		for(j = 0; j < 80; j++) {
			if(dun->t[i][j].c != '.' && dun->t[i][j].h == 0) {
				dun->t[i][j].c = '#';
				dun->t[i][j].p = 1;
			}
		}
	}

	// add stairs to the dungeon map
	for (upc = 0; upc < dun->un; upc++) {
	  int x = dun->upStair[upc].p.x;
	  int y = dun->upStair[upc].p.y;
	  dun->t[x][y].c = '<';
	}
	for (dpc = 0; dpc < dun->dn; dpc++) {
	  int x = dun->downStair[dpc].p.x;
	  int y = dun->downStair[dpc].p.y;
	  dun->t[x][y].c = '>';
	}

	fclose(f);
}


// get a random integer between a and b
int hash (int a, int b) {
  // generate a random int between a and b
  return (a + rand() % (b - a));
}


// print the dungeon in terminal
void print(Dungeon * dun) {
	int i, j, k;

  // fill with blank tile
	for(i = 0; i < 21; i++) {
		for(j = 0; j < 80; j++) {
			dun->p[i][j].c = ' ';
		}
	}

	// add corridors
	for(i = 0; i < 21; i++) {
		for(j = 0; j < 80; j++) {
			if(dun->t[i][j].p == 1 || dun->t[i][j].c == '#') {
				dun->p[i][j].c = '#';
			}
		}
	}

	// add rooms
	for(k = 0; k < dun->roomNum; k++) {
		for(i = dun->room[k].tl.y; i < dun->room[k].br.y+1; i++) {
			for(j = dun->room[k].tl.x; j < dun->room[k].br.x+1; j++) {
				dun->p[i][j].c = '.';
			}
		}
	}

  // setting up upstairs
  for(i = 0; i < 21; i++) {
   for(j = 0; j < 80; j++) {
     if(dun->t[i][j].c == '>') {
       dun->p[i][j].c = '>';
     } else if(dun->t[i][j].c == '<'){
         dun->p[i][j].c = '<';
       }
     }
   }

	// setting up print
	for(i = 0; i < 21; i++) {
		for(j = 0; j < 80; j++) {
			printf("%c", (dun->p[i][j]).c);
		}
		printf("\n");
	}
}


// spawn rooms
int spawnRoom(Dungeon *dun) {
	int x = hash(1, 79);
  int y = hash(1, 20);
	Room rm;
	rm.tl.x = x;
	rm.tl.y = y;

	int w = 0;
	int h = 0;
  // rerun if the room is a square
  while(w == h) {
    w = (rand() % 7) + 4;
    h = (rand() % 6) + 3;
  }
	rm.h = h;
	rm.w = w;
	rm.br.x = x + rm.w-1;
	rm.br.y = y + rm.h-1;

	// check if the location is already used by other rooms
	int i, j;
	int pass = 0;
	for(i = y; i < 20 && i < y+h; i++) {
		for(j = x; j < 79 && j < x+w; j++) {
			if(dun->p[i][j].c != '.')
				pass++;
		}
	}
	if(pass < w*h)
		return -1;

	// check if room is out of bound
  if(rm.br.x >= 80 || rm.br.y >= 21)
    return -1;

	// check the edge of the rooms
	for(i = rm.tl.x-1; i < rm.br.x+2 && rm.tl.x-1 >= 0 && rm.br.x+1 < 80 && rm.tl.y-1 >= 0; i++) {
		if((dun->p[rm.tl.y-1][i]).c == '.')
			return -1;
	}
	for(i = rm.tl.x-1; i < rm.br.x+2 && rm.tl.x-1 >= 0 && rm.br.x+1 < 80 && rm.br.y+1 < 21; i++) {
		if((dun->p[rm.br.y+1][i]).c == '.')
			return -1;
	}
	for(i = rm.tl.y; i < rm.br.y+1 && rm.br.y+1 < 21 && rm.tl.x-1 >= 0; i++) {
		if((dun->p[i][rm.tl.x-1]).c == '.')
			return -1;
		}
	for(i = rm.tl.y; i < rm.br.y+1 && rm.br.y+1 < 21 && rm.br.x+1 < 80; i++) {
		if((dun->p[i][rm.br.x+1]).c == '.')
			return -1;
	}

	// store the room
	for(i = y; i < y+h; i++) {
		for(j = x; j < x+w; j++) {
			dun->p[i][j].c = '.';
			dun->t[i][j].h = 0;
		}
	}

	// sign each room with id
	if(dun->roomNum < MAX) {
		dun->roomNum++;
		rm.id = dun->roomNum-1;
		rm.center.x = (rm.w) / 2 + rm.tl.x;
		rm.center.y = (rm.h) / 2 + rm.tl.y;
		dun->room[dun->roomNum-1] = rm;
	} else {
		return -1;
	}
	return 0;
}


// check if all rooms are all_connected
int isConnected(int *count, Dungeon *dun) {
	int i;
	for(i = 0; i < dun->roomNum; i++) {
		if(count[i] != 1 || dun->room[i].c != 1)
			return 0;
	}
	return 1;
}


// generate cooridors
void spawnCor (Dungeon *dun) {
	int i;
	int count[dun->roomNum];
	memset(count, 0, dun->roomNum * sizeof(int));
	double distance[dun->roomNum];
	memset(distance, 0.0, dun->roomNum * sizeof(double));
	int max = dun->roomNum * 3;
	Cor cors[max];
	int corCount = 0;
	int	curRoom = 0;

  // init variables
	for(i = 0; i < dun->roomNum; i++) {
		distance[i] = -1;
	}
	distance[0] = 0;
	for(i = 0; i < dun->roomNum; i++) {
		dun->room[i].c = 0;
	}

  // connect all rooms
	while(isConnected(count, dun) == 0 && corCount < max) {
		int i;
		double d;
		Cor np;

		// import distance
		for(i = 0; i < dun->roomNum; i++) {
			d =  sqrt(pow(dun->room[i].center.x - dun->room[curRoom].center.x, 2) + pow(dun->room[i].center.y - dun->room[curRoom].center.y, 2));
			distance[i] = d;
		}

		int next = -1;
		for(i = 0; i < dun->roomNum; i++) {
			if(count[i] != 1 && next == -1 && curRoom != i) {
				next = i;
			} else if(count[i] != 1 && distance[i] < distance[next] && curRoom != i) {
				next = i;
			}
		}

		if(next != -1) {
			dun->room[curRoom].c = 1;
			dun->room[next].c = 1;
			count[curRoom] = 1;
			np.prev = curRoom;
			np.next = next;
			cors[corCount] = np;
			curRoom = next;
			corCount++;
		} else {
			break;
		}
	}

  // draw corridors path
	for(i = 0; i < corCount; i++) {
		int x = dun->room[cors[i].prev].center.x;
		int y = dun->room[cors[i].prev].center.y;

		while(x != dun->room[cors[i].next].center.x || y != dun->room[cors[i].next].center.y) {
			int hor = 0;
			int ver = 0;

			if(x < dun->room[cors[i].next].center.x) {
				hor = 1;
			} else if(x > dun->room[cors[i].next].center.x) {
				hor = -1;
			}
			if(y < dun->room[cors[i].next].center.y) {
				ver = 1;
			} else if(y > dun->room[cors[i].next].center.y) {
				ver = -1;
			}
			dun->t[y][x].p = 1;

			// check if corridors are in rooms
			if(dun->t[y][x].c != '.') {
				dun->t[y][x].c = '#';
				dun->t[y][x].h = 0;
			}

			if(hor == -1) {
				x--;
			} else if(hor == 1) {
				x++;
			} else if(ver == -1) {
				y--;
			} else if(ver == 1) {
				y++;
			}
		}
	}
}


// spawn an empty dungeon
void blankDun (Dungeon *dun) {
	int i, j;
	// set all tiles to space
	for(i = 0; i < 21; i++) {
		for(j = 0; j < 80; j++) {
			(dun->t[i][j]).c = ' ';
			int h = hash(1, 254);
			(dun->t[i][j]).h = h;
		}
	}

	// set the boundary
	for(i = 0; i < 80; i++)
		(dun->t[0][i]).h = 255;
	for(i = 0; i < 80; i++)
		(dun->t[21-1][i]).h = 255;
	for(i = 0; i < 21; i++)
		(dun->t[i][0]).h = 255;
	for(i = 0; i < 21; i++)
		(dun->t[i][80-1]).h = 255;

	// copy the print buffer from tile buffer
	for(i = 0; i < 21; i++) {
		for(j = 0; j < 80; j++)
			dun->p[i][j] = dun->t[i][j];
	}

	// set up rooms
	int count = 0;
	int swh = 0;
	for(i = 0; dun->roomNum < MAX && count < 2000; i++) {
		swh = spawnRoom(dun);
		if(swh < 0)
			count++;
	}
}


// generate a new dungeon
Dungeon initDun() {
	Dungeon dun;
	dun.roomNum	= 0;

	// allocate tile buffer
	dun.t = malloc(21 * sizeof(Tile *));
	int i;
	for(i = 0; i < 21; i++) {
		dun.t[i] = malloc(80 * sizeof(Tile));
	}

	// allocate print tile buffer
	dun.p = malloc(21 * sizeof(Tile *));
	for(i = 0; i < 21; i++) {
		dun.p[i] = malloc(80 * sizeof(Tile));
	}

	// allocate room buffer
	dun.room = malloc(MAX * sizeof(Room));

  // allocate stair buffer
  dun.upStair = malloc(5 * sizeof(Stair));
  dun.downStair = malloc(5 * sizeof(Stair));

	return dun;
}


void spawnStair(Dungeon *dun){
  int up = hash(1, 5);
  dun->un = up;
  int down = hash(1, 5);
  dun->dn = down;
  int count = 0;
  int x, y;
  while(count < up){
    y = hash(0, 21);
    x = hash(0, 80);
    if(!dun->t[y][x].h){
      if(((dun->t[y][x].c == '#') && (dun->t[y-1][x].c == '#'))||(dun->t[y][x].c != '#')) {
        dun->t[y][x].c = '<';
        dun->upStair[count].p.x = y;
        dun->upStair[count].p.y = x;
        dun->upStair[count].ud = 1;
        count++;
      }
    }
  }
  count = 0;
  while(count < down){
    y = hash(1, 20);
    x = hash(1, 79);
    if((!dun->t[y][x].h) && (dun->t[y][x].c != '<')){
      if(((dun->t[y][x].c == '#')&& (dun->t[y+1][x].c == '#'))||(dun->t[y][x].c != '#')) {
        dun->t[y][x].c = '>';
        dun->downStair[count].p.x = y;
        dun->downStair[count].p.y = x;
        dun->upStair[count].ud = 0;
        count++;
      }
    }
  }
}


// helper function to process cmd argvs for main
void argvPos(int argc, char ** argv, int i, int *save, int *load, int *pathc, int *cp) {
  if (strcmp(argv[i], "--save") == 0) {
    *save = 1;
  } else if (strcmp(argv[i], "--load") == 0) {
    *load = 1;
  } else if (strcmp(argv[i], "-f") == 0) {
    *pathc = 1;
    *cp = i + 1;
    if (i + 1 > argc - 1) {
      printf("Please enter correct file name\n");
      *pathc = 0;
    }
  }
}


int main(int argc, char * argv[]) {
	// determine which functions are used, and process them
	int save = 0;
	int load = 0;
	int pathChange = 0;
	int cp = 0;
	if(argc > 2 && argc <= 5) {
		// save and load
		int i;
		for(i = 1; i < argc; i++) {
			argvPos(argc, argv, i, &save, &load, &pathChange, &cp);
		}
	} else if(argc == 2) {
		// save or load
		argvPos(argc, argv, 1, &save, &load, &pathChange, &cp);
	} else if(argc > 5) {
		printf("Max commandline arguments exceed\n");
	}

	// set up seed
  srand(time(NULL));

  // set up file path
	char *home = getenv("HOME");
	char *path = malloc((strlen(home) + 50) * sizeof(char));
	strcpy(path, home);
	strcat(path, "/.rlg327");
	if(pathChange == 0) {
		strcat(path, "/dungeon");
	} else {
		strcat(path, "/");
		strcat(path, argv[cp]);
	}

	// set up dungeon
	Dungeon dun = initDun();

	if(load == 0) {
		blankDun(&dun);
		spawnCor(&dun);
		spawnStair(&dun);
	} else {
		loadFile(&dun, path);
	}

	print(&dun);

	if(save == 1) {
		saveFile(&dun, path);
	}

	// free memory
	int i;
	for (i = 0; i < 21; i++) {
    free(dun.t[i]);
    free(dun.p[i]);
  }
  free(dun.t);
  free(dun.p);
	free(dun.room);
	free(path);

	return 0;
}
