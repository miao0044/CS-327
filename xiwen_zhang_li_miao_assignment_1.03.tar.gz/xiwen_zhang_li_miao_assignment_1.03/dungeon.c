#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <math.h>
#include <limits.h>
#include <stdint.h>
#include <endian.h>
#include <sys/stat.h>
#include <sys/types.h>
#include "binaryheap.h"

#define	MAX 10

typedef struct {
	int		h;	/* hardness */
	char	c;	/* visual character */
	int		p;	/* mark 1 if path, 0 if not a path (corridors) */
} Tile;

typedef struct {
	int	x; /* x coordinate */
	int	y; /* y coordinate */
} Position;

/* maybe make these pointers? */
typedef struct {
	int prev; /* previous room in the path (using Room.id) */
	int next; /* room the path leads to (using Room.id) */
} Path;

typedef struct {
	Position	p;	/* position of the character in the dun */
	char		c;	/* character to print for the character */
} Character;

typedef struct {
	Position	tl;		/* top left coordinate of the room, used as the core point of reference */
	Position	br;		/* bottom right coordinate of the room as per above */
	int			w;		/* width */
	int			h;		/* height */
	int			id;		/* room ID, potentially useful for organization */
	int			p;		/* mark 1 if processed; 0 if not processed (corridors) */
	Position	center;	/* "center" point; very rough, might need improved */
	int			c;		/* if connected or not; 1/0 switch */
} Room;

typedef struct {
  Position p;        // position of stair
  int ud;            // 1 = up; 0 = down
} Stair;

typedef struct {
	Tile 	**	t;		/* dun buffer */
	Tile 	**	p;		/* print buffer */
	int			h;		/* height */
	int			w;		/* width */
	int			roomNum; 	/* number of rooms */
	int			mr;		/* max rooms */
	Room 	*	room;		/* rooms buffer */
	int			version;		/* file version */
	int			size;		/* file size */
	int         un;     // upper stair number
	int		    dn;     // down stair number
	Stair *     upStair;    // upstairs
	Stair *     downStair;  // downstairs
	Character	*	carr;		/* character array */
	int			ns;		/* number of characters */
	int			ms;		/* max number of characters */
	int		**	csnt;
	int		**	cost;	/* costs for djikstra's map */
	int			pc;		/* location of PC in Characters array (.ss) */
} dun;

typedef struct {
	int x;
	int y;
	int cost;
	int v;
} Tile_Node;



// get a random integer between a and b
int hash (int a, int b) {
  // generate a random int between a and b
  return (a + rand() % (b - a));
}

int compareInteger(const void *key, const void *with) {
	return *(const int *) key - *(const int *) with;
}

int calculateHardness(int h) {
	int hc = 0;

	if(h >= 0 && h < 85) {
		return 1;
	}
	if(h > 84 && h < 171) {
		return 2;
	}
	if(h > 170 && h < 255) {
		return 3;
	}

	return hc;
}

//dijkstra for tunnelling
void newMapTun(dun * dun) {
	BinaryHeap h;
	Tile_Node t[dun->h][dun->w];

	initializeBinaryHeap(&h, compareInteger, NULL);


	int xs[8] = {-1,0,1,1,1,0,-1,-1};
	int ys[8] = {-1,-1,-1,0,1,1,1,0};

	int i;
	int j;


	for(i = 0; i < dun->h; i++) {
		for(j = 0; j < dun->w; j++) {
			t[i][j].y = i;
			t[i][j].x = j;
			t[i][j].cost = INT_MAX;
			t[i][j].v = 0;
		}
	}

//set player cost to be 0
	int px = dun->carr[dun->pc].p.x;
	int py = dun->carr[dun->pc].p.y;
	t[py][px].cost = 0;
	t[py][px].v = 1;
	deleteBinaryInsert(&h, &t[py][px]);
//calculate primary cost

	BinaryHeapNode	*p;

	while((p = binaryHeapRemoveMin(&h))) {
		int hx = ((Tile_Node *) p)->x;
		int hy = ((Tile_Node *) p)->y;
		int tc = ((Tile_Node *) p)->cost;

		int i;
		for(i = 0; i < 8; i++) {
			int x = hx + xs[i];
			int y = hy + ys[i];
			if(x > 0 && x < dun->w-1 && y > 0 && y < dun->h-1) {
				int hard = dun->t[y][x].h;
				if(hard < 255) {
						int trial_cost = tc + calculateHardness(hard);
						if((t[y][x].cost > trial_cost && t[y][x].v == 1) || t[y][x].v == 0) {
							t[y][x].cost = tc + calculateHardness(hard);
							t[y][x].v = 1;

							deleteBinaryInsert(&h, (void *) &t[y][x]);
						}
				}
			}
		}
	}

//copy heat map to dun
	for(i = 0; i < dun->h; i++) {
		for(j = 0; j < dun->w; j++) {
			dun->cost[i][j] = t[i][j].cost;
		}
	}


//clean heap
	deleteBinaryHeap(&h);
}

//run dijkstra's algorithm to create a map with non-tunnelling cost
void newMapNonTun(dun * dun) {
	BinaryHeap h;
	Tile_Node t[dun->h][dun->w];

	initializeBinaryHeap(&h, compareInteger, NULL);

	int xs[8] = {-1,0,1,1,1,0,-1,-1};
	int ys[8] = {-1,-1,-1,0,1,1,1,0};

	int i;
	int j;

	for(i = 0; i < dun->h; i++) {
		for(j = 0; j < dun->w; j++) {
			t[i][j].y = i;
			t[i][j].x = j;
			t[i][j].cost = INT_MAX;
			t[i][j].v = 0;
		}
	}

//set the character cost to be 0
	int px = dun->carr[dun->pc].p.x;
	int py = dun->carr[dun->pc].p.y;
	t[py][px].cost = 0;
	t[py][px].v = 1;
	deleteBinaryInsert(&h, &t[py][px]);


	BinaryHeapNode	*p;

	while((p = binaryHeapRemoveMin(&h))) {
		int hx = ((Tile_Node *) p)->x;
		int hy = ((Tile_Node *) p)->y;
		int tc = ((Tile_Node *) p)->cost;

		int i;
		for(i = 0; i < 8; i++) {
			int x = hx + xs[i];
			int y = hy + ys[i];
			if(x > 0 && x < dun->w-1 && y > 0 && y < dun->h-1) {
				int hard = dun->t[y][x].h;
				if(hard == 0) {
						int trial_cost = tc + calculateHardness(hard);
						if((t[y][x].cost > trial_cost && t[y][x].v == 1) || t[y][x].v == 0) {
							t[y][x].cost = tc + calculateHardness(hard);
							t[y][x].v = 1;

							deleteBinaryInsert(&h, (void *) &t[y][x]);
						}
				}
			}
		}

	}

//add the heat map to run dungeon
	for(i = 0; i < dun->h; i++) {
		for(j = 0; j < dun->w; j++) {
			dun->csnt[i][j] = t[i][j].cost;
		}
	}


//clean up the heap
	deleteBinaryHeap(&h);
}


/* add a character to the dun */
void addCharacter(dun * dun, Character s) {
	if(dun->ns < dun->ms) {
		dun->ns++;
	} else {
		goto END;
	}

	if(s.c == '@') {
		dun->pc = dun->ns - 1;
	}

	dun->carr[dun->ns - 1] = s;

	END: ;
}

/* generate a character, because in-line structs are icky */
Character spawnCharacter(dun * dun, char c, int x, int y, int r) {
	Character s;

	/* place in a room if 1 or more. implicitly random */
	if(r > 0) {
		int r_id = rand() % dun->roomNum;
		x = (rand() % dun->room[r_id].w) + dun->room[r_id].tl.x;
		y = (rand() % dun->room[r_id].h) + dun->room[r_id].tl.y;
	} else {
		/* randomize location if a valid one is not provided */
		if(x < 0 || x > dun->w) {
			x = (rand() % (dun->w-2)) + 1;
		}
		if(y < 0 || y > dun->h) {
			y = (rand() % (dun->h-2)) + 1;
		}
	}

	s.p.x = x;
	s.p.y = y;
	s.c = c;

	return s;
}

/* reads from a dun file */
void loadDungeon(dun * dun, char * path) {
	FILE * file;
	file = fopen(path, "rb+");
	if(file == NULL) {
		fprintf(stderr, "FILE ERROR: Could not open dun file at %s! loadDungeon()\n", path);
        exit(1);
	}

	/* read the file-type marker */
	fseek(file, 0, SEEK_SET);
	char marker[12];
	fread(marker, 1, 12, file);
	/* read the file version marker */
	fseek(file, 12, SEEK_SET);
	uint32_t fv;
	uint32_t fv_be;
	fread(&fv_be, sizeof(uint32_t), 1, file);
	fv = be32toh(fv_be);
	dun->version = fv;
	/* read the size of file */
	fseek(file, 16, SEEK_SET);
	uint32_t size;
	uint32_t size_be;
	fread(&size_be, sizeof(uint32_t), 1, file);
	size = be32toh(size_be);
	dun->size = size;
	 fseek(file, 20, SEEK_SET);
    int pcx;       //pc position x
    int pcy;       //pc position y
    fread(&pcx, sizeof(uint8_t), 1, file);
	dun->pc = 0; 
    dun->carr[0].p.x= (int8_t) pcx;
    fread(&pcy, sizeof(uint8_t), 1, file);
    dun->carr[0].p.y= (int8_t) pcy;
	/* read the hardness values in */
	fseek(file, 22, SEEK_SET);
	int i;
	int j;
	for(i = 0; i < dun->h; i++) {
		for(j = 0; j < dun->w; j++) {
			int h;
			int8_t h_8;
			fread(&h_8, sizeof(int8_t), 1, file);
			h = (int) h_8;
			dun->t[i][j].h = h;
		}
	}
	/* read in rooms in dun */
	fseek(file, 1702, SEEK_SET);

	int rm;                     //number of rooms
    fread(&rm, sizeof(int16_t), 1, file);
    dun->roomNum = (int16_t) rm;
	/* might want to make this just counted in 4's by the loop below, but w/e, math, amirite? */
	int ri = 0;
	int room_count = dun->roomNum;
	dun->room = calloc(room_count, sizeof(Room));
	/* could probably be replaced with a getpos() call for complete-ness */
	fseek(file, 1704, SEEK_SET);
	int pos;
	for(pos = 0; pos < dun->roomNum; pos += 1) {
		int x_8;
		int w_8;
		int y_8;
		int h_8;
		fread(&x_8, sizeof(int8_t), 1, file);
		fread(&w_8, sizeof(int8_t), 1, file);
		fread(&y_8, sizeof(int8_t), 1, file);
		fread(&h_8, sizeof(int8_t), 1, file);

		dun->room[ri].tl.x = (int8_t) x_8;
		dun->room[ri].w = (int8_t) w_8;
		dun->room[ri].tl.y = (int8_t) y_8;
		dun->room[ri].h = (int8_t) h_8;
		dun->room[ri].br.x = ((int8_t) x_8) + dun->room[ri].w-1;
		dun->room[ri].br.y = ((int8_t) y_8) + dun->room[ri].h-1;



		ri++;
	}
    // load number of upstairs
    fseek(file, 1704 + dun->roomNum * 4, SEEK_SET);
    int fun;                         //number of upper stair in file
    fread(&fun, sizeof(int16_t), 1, file);
    dun->un = (int16_t) fun;
    fseek(file, 1706 + dun->roomNum * 4, SEEK_SET);
    int upc;                         //upper stair count
    for (upc = 0; upc < dun->un; upc++) {
     int x, y;
    fread(&x, sizeof(int8_t), 1, file);
    fread(&y, sizeof(int8_t), 1, file);

    dun->upStair[upc].p.x = (int8_t) x;
    dun->upStair[upc].p.y = (int8_t) y;
    dun->upStair[upc].ud = 1;
   }
    fseek(file, 1706 + dun->roomNum * 4 + dun->un * 2, SEEK_SET);
    int fdn;                         //number of down stair in file
    fread(&fdn, sizeof(int16_t), 1, file);
    dun->dn = (int16_t) fdn;
	 fseek(file, 1708 + dun->roomNum * 4 + dun->un * 2, SEEK_SET);
    int dpc;                        //down stair count
    for (dpc = 0; dpc < dun->dn; dpc++) {
    int x, y;
    fread(&x, sizeof(int8_t), 1, file);
    fread(&y, sizeof(int8_t), 1, file);

    dun->downStair[dpc].p.x = (int8_t) x;
    dun->downStair[dpc].p.y = (int8_t) y;
    dun->downStair[dpc].ud = 0;
  }
	/* populate the rooms and corridors if not in rooms */
	/* add rooms to the dun buffer */
	int h;
	for(h = 0; h < dun->roomNum; h++) {
		for(i = dun->room[h].tl.y; i < dun->room[h].br.y+1; i++) {
			for(j = dun->room[h].tl.x; j < dun->room[h].br.x+1; j++) {
				dun->t[i][j].c = '.';
			}
		}
	}

	/* add corridors to the dun buffer */
	for(i = 0; i < dun->h; i++) {
		for(j = 0; j < dun->w; j++) {
			if(dun->t[i][j].c != '.' && dun->t[i][j].h == 0) {
				dun->t[i][j].c = '#';
				dun->t[i][j].p = 1;
			}
		}
	}

	for (upc = 0; upc < dun->un; upc++) {
	  int x = dun->upStair[upc].p.x;
	  int y = dun->upStair[upc].p.y;
	  dun->t[x][y].c = '<';
	}
	for (dpc = 0; dpc < dun->dn; dpc++) {
	  int x = dun->downStair[dpc].p.x;
	  int y = dun->downStair[dpc].p.y;
	  dun->t[x][y].c = '>';
	}


	fclose(file);
}

/* writes the dun file to ~/.rlg327/dun */
void saveDungeon(dun * dun, char * p) {
		// get file location set up
	FILE * f;
	char * home = getenv("HOME");
	char * path;
	path = malloc((strlen(home) + 50) * sizeof(char));
	strcpy(path, home);
	strcat(path, "/.rlg327");
	// if the file is not exist, create one
	mkdir(path, S_IRWXU);
      
	f = fopen(p, "wb+");
	if(f == NULL) {
		printf("file opening error while saving\n");
    exit(1);
	}
	/* write the file-type marker */
	fseek(f, 0, SEEK_SET);
	char marker[13];
	strcpy(marker, "RLG327-S2021");
	fwrite(marker, sizeof(char), 12, f);
	/* write the file version marker */
	fseek(f, 12, SEEK_SET);
	uint32_t fv = 0;
	uint32_t fv_be = htobe32(fv);
	fwrite(&fv_be, sizeof(uint32_t), 1, f);
	/* write the size of the file ;; unsure how to properly calculate */
	fseek(f, 16, SEEK_SET);
 	uint32_t size = 1693 + (4 * dun->roomNum);
	uint32_t size_be = htobe32(size);
	fwrite(&size_be, sizeof(uint32_t), 1, f);
		// save pc position
    fseek(f, 20, SEEK_SET);
    uint8_t pcx;       //pc position x
    uint8_t pcy;       //pc position y
    pcx = (int8_t)(dun->carr[dun->pc].p.x);
    fwrite(&pcx, sizeof(uint8_t), 1, f);
    pcy = (int8_t)(dun->carr[dun->pc].p.y);
    fread(&pcy, sizeof(uint8_t), 1, f);
	/* row-major dun matrix */
	fseek(f, 22, SEEK_SET);
	int pos = 22;
	int i;
	int j;

	for(i = 0; i < dun->h; i++) {
		for(j = 0; j < dun->w; j++) {
			fseek(f, pos, SEEK_SET);
			int8_t h;
			h = (int8_t)(dun->t[i][j].h);
			fwrite(&h, sizeof(int8_t), 1, f);
			pos++;
		}
	}
    fseek(f, 1702, SEEK_SET);
    int16_t rm;                        //number of rooms
    rm = (int16_t)dun->roomNum;
    fwrite(&rm, sizeof(int16_t), 1, f);
	/* room positions ;; 4 bytes per room */
	fseek(f, 1704, SEEK_SET);
	for(i = 0; i < dun->roomNum; i++) {
		int8_t x = (int8_t) dun->room[i].tl.x;
		int8_t y = (int8_t) dun->room[i].tl.y;
		int8_t w = (int8_t) dun->room[i].w;
		int8_t h = (int8_t) dun->room[i].h;

		fwrite(&x, sizeof(int8_t), 1, f);
		fwrite(&y, sizeof(int8_t), 1, f);
		fwrite(&w, sizeof(int8_t), 1, f);
		fwrite(&h, sizeof(int8_t), 1, f);
	}
  fseek(f, 1704 + dun->roomNum * 4, SEEK_SET);
  int16_t fun;                           //number of upper stair in file
  fun = (int16_t) dun->un;
  fwrite(&fun, sizeof(int16_t), 1, f);
   fseek(f, 1706 + dun->roomNum * 4, SEEK_SET);
  int upc;                             //upper stair count
  for (upc = 0; upc < dun->un; upc++) {
    int8_t x, y;
    x = (int8_t) dun->upStair[upc].p.x;
    y = (int8_t) dun->upStair[upc].p.y;
    fwrite(&x, sizeof(int8_t), 1, f);
    fwrite(&y, sizeof(int8_t), 1, f);
  }
   fseek(f, 1706 + dun->roomNum * 4 + dun->un * 2, SEEK_SET);
   int16_t fdn;                         //number of upper stair in file
   fdn = (int16_t) dun->dn;
   fwrite(&fdn, sizeof(int16_t), 1, f);
  fseek(f, 1708 + dun->roomNum * 4 + dun->un * 2, SEEK_SET);
  int dpc;                         //down stair count
  for (dpc = 0; dpc < dun->dn; dpc++) {
    int8_t x, y;
    x = (int8_t) dun->downStair[dpc].p.x;
    y = (int8_t) dun->downStair[dpc].p.y;
    fwrite(&x, sizeof(int8_t), 1, f);
    fwrite(&y, sizeof(int8_t), 1, f);
  }
	free(path);
	fclose(f);
}


/* prints the dun */
void printDun(dun * dun, int nt, int t) {
	int i;
	int j;
	int h;

	for(i = 0; i < dun->h; i++) {
		for(j = 0; j < dun->w; j++) {
			dun->p[i][j].c = ' ';
		}
	}

	/* add corridors to the print buffer */
	for(i = 0; i < dun->h; i++) {
		for(j = 0; j < dun->w; j++) {
			if(dun->t[i][j].p == 1 || dun->t[i][j].c == '#') {
				dun->p[i][j].c = '#';
			}
		}
	}
	/* add rooms to the print buffer */
	for(h = 0; h < dun->roomNum; h++) {
		for(i = dun->room[h].tl.y; i < dun->room[h].br.y+1; i++) {
			for(j = dun->room[h].tl.x; j < dun->room[h].br.x+1; j++) {
				dun->p[i][j].c = '.';
			}
		}
	}
	// setting up upstairs
    for(i = 0; i < dun->h; i++) {
   for(j = 0; j < dun->w; j++) {
     if(dun->t[i][j].c == '>') {
       dun->p[i][j].c = '>';
     } 
	 else if(dun->t[i][j].c == '<'){
         dun->p[i][j].c = '<';
       }
     }
   }
	/* add characters to the print buffer */
	for(i = 0; i < dun->ns; i++) {
		dun->p[dun->carr[i].p.y][dun->carr[i].p.x].c = dun->carr[i].c;
	}

	/* print non-tunnelling dijkstra's */
	if(nt > 0) {
		for(i = 0; i < dun->h; i++) {
			for(j = 0; j < dun->w; j++) {
				if(dun->t[i][j].h == 0) {
					int c = dun->csnt[i][j];
					if(c == 0) {
						dun->p[i][j].c = '@';
					} else {
						dun->p[i][j].c = '0' + c % 10;
					}
				}
			}
		}
	}

	/* print tunnelling dijkstra's */
	if(t > 0) {
		for(i = 0; i < dun->h; i++) {
			for(j = 0; j < dun->w; j++) {
				int c = dun->cost[i][j];
				if(c == 0) {
					dun->p[i][j].c = '@';
				} else {
					dun->p[i][j].c = '0' + c % 10;
				}
			}
		}
	}

	/* print the print buffer */
	for(i = 0; i < dun->h; i++) {
		int j;
		for(j = 0; j < dun->w; j++) {
			printf("%c", (dun->p[i][j]).c);
		}
		printf("\n");
	}
}

/* (attempt to) place a room within a given dun */
int place_room(dun * dun) {
	int x = (rand() % (dun->w-1)) +1;
	int y = (rand() % (dun->h-1)) +1;
	Room new_room;
	/*
	set top right to rng number; might be worth making a more detailed placer with a lower
		fail rate
	*/
	new_room.tl.x = x;
	new_room.tl.y = y;
	/* for RNG, maybe do a rando room width/height and re-set .br */

	HW: ;

	int we = (rand() % 4) + 4; /* width, expanded, up to 4 more */
	int he = (rand() % 4) + 3; /* height, expanded, up to 4 more */

	if(we == he) {
		/* if we have a square, re-generate */
		goto HW;
	}

	new_room.h = he;
	new_room.w = we;

	new_room.br.x = x + new_room.w-1;
	new_room.br.y = y + new_room.h-1;

	/* check for rooms loaded into the dun buffer already */
	int i;
	int j;
	int placed = -1;
	int passed = 0;
	for(i = y; i < dun->h-1 && i < y+he; i++) {
		for(j = x; j < dun->w-1 && j < x+we; j++) {
			if(dun->p[i][j].c != '.') {
				passed++;
			}
		}
	}

	/* return a failure if not all cells within the "Room" passed */
	if(passed < we*he) {
		return placed; /* should be -1 */
	}

	/* return a failure if part of the room is out of bounds */
	if(new_room.br.x >= dun->w || new_room.br.y >= dun->h) {
		return placed;
	}


	/* check for surrounding rooms */

	/* top row */
	for(i = new_room.tl.x-1; i < new_room.br.x+2 && new_room.tl.x-1 >= 0 && new_room.br.x+1 < dun->w && new_room.tl.y-1 >= 0; i++) {
		if((dun->p[new_room.tl.y-1][i]).c == '.') {
			return placed;
		}
	}

	/* bottom row */
	for(i = new_room.tl.x-1; i < new_room.br.x+2 && new_room.tl.x-1 >= 0 && new_room.br.x+1 < dun->w && new_room.br.y+1 < dun->h; i++) {
		if((dun->p[new_room.br.y+1][i]).c == '.') {
			return placed;
		}
	}

	/* left side */
	for(i = new_room.tl.y; i < new_room.br.y+1 && new_room.br.y+1 < dun->h && new_room.tl.x-1 >= 0; i++) {
		if((dun->p[i][new_room.tl.x-1]).c == '.') {
			return placed;
		}
	}

	/* right side */
	for(i = new_room.tl.y; i < new_room.br.y+1 && new_room.br.y+1 < dun->h && new_room.br.x+1 < dun->w; i++) {
		if((dun->p[i][new_room.br.x+1]).c == '.') {
			return placed;
		}
	}


	/* successful placement */
	placed = 0;

	/* fill the room into the dun buffer and add to room array */
	for(i = y; i < y+he; i++) {
		for(j = x; j < x+we; j++) {
			dun->p[i][j].c = '.';
			dun->t[i][j].h = 0;
		}
	}


	if(dun->roomNum < dun->mr) {
		dun->roomNum++;
		new_room.id = dun->roomNum-1; /* reflects position in the array */
		new_room.center.x = (new_room.w)/2 + new_room.tl.x;
		new_room.center.y = (new_room.h)/2 + new_room.tl.y;
		/* printf("%d: (%d, %d)\n", new_room.id, new_room.center.x, new_room.center.y); */
		dun->room[dun->roomNum-1] = new_room;
	} else {
		return -1;
	}


	return placed;
}

/* assistant function for gen_corridors() to check if all rooms are connected */
int all_connected(int * cnxns, dun * dun) {
	int i;

	for(i = 0; i < dun->roomNum; i++) {
		if(cnxns[i] != 1 || dun->room[i].c != 1) {
			return 0;
		}
	}

	return 1;
}

/* generates and marks corridors */
void spawnCorridors(dun * dun) {
	int connected[dun->roomNum];
	memset(connected, 0, dun->roomNum * sizeof(int));
	double dists[dun->roomNum];
	memset(dists, 0.0, dun->roomNum * sizeof(double));
	int max_paths = dun->roomNum * 3;
	Path paths[max_paths]; /* max paths is 3 * number of rooms */
	int path_cnt = 0;
	int	room_pos = 0; /* current room in use */
	int i;

	for(i = 0; i < dun->roomNum; i++) {
		dists[i] = -1; /* infinite at -1 */
	}
	dists[0] = 0;

	/* ensure all rooms are disconnected */
	for(i = 0; i < dun->roomNum; i++) {
		dun->room[i].c = 0;
	}

	/* primary loop, goal is to connect all rooms; 0 means 1 */
	while(all_connected(connected, dun) == 0 && path_cnt < max_paths) {
		int i;
		double d;
		Path new_path;

		/* populate dists from the current position */
		for(i = 0; i < dun->roomNum; i++) {
			/* calculate distance */
			d =  sqrt(pow(dun->room[i].center.x - dun->room[room_pos].center.x, 2) + pow(dun->room[i].center.y - dun->room[room_pos].center.y, 2));
			dists[i] = d;
		}

		/* find the room to path to ;; if not connected already and the distance is shorter and isn't our current position */

		int next = -1;
		for(i = 0; i < dun->roomNum; i++) {
			if(connected[i] != 1 && next == -1 && room_pos != i) {
				next = i;
			} else if(connected[i] != 1 && dists[i] < dists[next] && room_pos != i) {
				next = i;
			}
		}

		/** this would - in the future - be the point of adding extraneous paths **/
		if(next != -1) {
			dun->room[room_pos].c = 1;
			dun->room[next].c = 1;
			connected[room_pos] = 1;
			new_path.prev = room_pos;
			new_path.next = next;
			paths[path_cnt] = new_path;
			room_pos = next;
			path_cnt++;
		} else {
			break;
		}

	}

	/* populate the dun grid (draw the paths using x/y chasing/pathing) */

	/* draw dun paths in the dun grid; start at room 0 as per above */

	for(i = 0; i < path_cnt; i++) {
		int x = dun->room[paths[i].prev].center.x;
		int y = dun->room[paths[i].prev].center.y;

		/*printf("%d: (%d, %d)\n", i, x, y);*/

		while(x != dun->room[paths[i].next].center.x || y != dun->room[paths[i].next].center.y) {
			int dirx = 0; /* -1 for left, 1 for right */
			int diry = 0; /* -1 for down, 1 for up */

			if(x < dun->room[paths[i].next].center.x) {
				dirx = 1;
			} else if(x > dun->room[paths[i].next].center.x) {
				dirx = -1;
			}

			if(y < dun->room[paths[i].next].center.y) {
				diry = 1;
			} else if(y > dun->room[paths[i].next].center.y) {
				diry = -1;
			}

			dun->t[y][x].p = 1;
			/* don't place corridors in rooms */
			if(dun->t[y][x].c != '.') {
				dun->t[y][x].c = '#';
				dun->t[y][x].h = 0;
			}

			if(dirx == -1) {
				x--;
			} else if(dirx == 1) {
				x++;
			} else if(diry == -1) {
				y--;
			} else if(diry == 1) {
				y++;
			}
		}

	}

}

/* spawnerate a blank dun */
void spawnDun(dun * dun) {
	/*** top 3 (0, 1, 2) are reserved for the pseudo-HUD ***/
	int i, j;

	/* set all slots to spaces originally */
	for(i = 0; i < dun->h; i++) {
		for(j = 0; j < dun->w; j++) {
			(dun->t[i][j]).c = ' ';	/* all basic rooms are spaces */
			int h = (rand() % 254) + 1;
			(dun->t[i][j]).h = h;
		}
	}

	/* immut-ify the outside rim */
	for(i = 0; i < dun->w; i++) {
		(dun->t[0][i]).h = 255;
	}
	for(i = 0; i < dun->w; i++) {
		(dun->t[dun->h-1][i]).h = 255;
	}
	for(i = 0; i < dun->h; i++) {
		(dun->t[i][0]).h = 255;
	}
	for(i = 0; i < dun->h; i++) {
		(dun->t[i][dun->w-1]).h = 255;
	}

	/* make p equal to d */
	for(i = 0; i < dun->h; i++) {
		for(j = 0; j < dun->w; j++) {
			dun->p[i][j] = dun->t[i][j];
		}
	}

	/* populate the rooms */
	int cnt = 0;
	int tst = 0;
	for(i = 0; dun->roomNum < dun->mr && cnt < 2000; i++) {
		tst = place_room(dun);
		if(tst < 0) {
			cnt++;
		}
	}


}

void spawnStair(dun *dun){
  int up = hash(1, 5);
  dun->un = up;
  int down = hash(1, 5);
  dun->dn = down;
  int count = 0;
  int x, y;
  while(count < up){
    y = hash(0, 21);
    x = hash(0, 80);
    if(!dun->t[y][x].h){
      if(((dun->t[y][x].c == '#')&& (dun->t[y-1][x].c == '#'))||((dun->t[y][x].c != '#') && (dun->t[y-1][x].c == '.'))) {
        dun->t[y][x].c = '<';
        dun->upStair[count].p.x = y;
        dun->upStair[count].p.y = x;
        dun->upStair[count].ud = 1;
        count++;
      }
    }
  }
  count = 0;
  while(count < down){
    y = hash(1, 20);
    x = hash(1, 79);
    if((!dun->t[y][x].h) && (dun->t[y][x].c != '<')){
      if(((dun->t[y][x].c == '#')&& (dun->t[y+1][x].c == '#'))||((dun->t[y][x].c != '#') && (dun->t[y+1][x].c == '.'))) {
        dun->t[y][x].c = '>';
        dun->downStair[count].p.x = y;
        dun->downStair[count].p.y = x;
        dun->upStair[count].ud = 0;
        count++;
      }
    }
  }
}

/* initializes the dun structure */
dun initDun(int h, int w, int mr) {
	dun new_dun;
	new_dun.h	= h;
	new_dun.w	= w;
	new_dun.mr	= mr;
	new_dun.roomNum	= 0;
	new_dun.ns	= 0;
	new_dun.ms	= w*h; /* max characters would be 1 per dun slot */

	/* dun buffer allocation+0'ing */
	new_dun.t = calloc(new_dun.h, sizeof(Tile *));

	int i;
	for(i = 0; i < new_dun.h; i++) {
		new_dun.t[i] = calloc(new_dun.w, sizeof(Tile));
	}

	/* dun visual buffer allocation+0'ing */
	new_dun.p = calloc(new_dun.h, sizeof(Tile *));

	for(i = 0; i < new_dun.h; i++) {
		new_dun.p[i] = calloc(new_dun.w, sizeof(Tile));
	}

	/* rooms allocation+0'ing */
	new_dun.room = calloc(new_dun.mr, sizeof(Room));
    
    new_dun.upStair = calloc(5 , sizeof(Stair));
    new_dun.downStair = calloc(5 , sizeof(Stair));
	/* characters allocation */
	new_dun.carr = calloc(new_dun.ms, sizeof(Character));

	/* djikstra-based cost map allocation */
	new_dun.cost = calloc(w*h, sizeof(int *));
	for(i = 0; i < new_dun.h; i++) {
		new_dun.cost[i] = calloc(new_dun.w, sizeof(int));
	}

	/* djikstra-based cost map allocation */
	new_dun.csnt = calloc(w*h, sizeof(int *));
	for(i = 0; i < new_dun.h; i++) {
		new_dun.csnt[i] = calloc(new_dun.w, sizeof(int));
	}

	return new_dun;
}

void argvPos(int argc, char ** argv, int i, int *save, int *load, int *pathc, int *cp) {
  if (strcmp(argv[i], "--save") == 0) {
    *save = 1;
  } else if (strcmp(argv[i], "--load") == 0) {
    *load = 1;
  } else if (strcmp(argv[i], "-f") == 0) {
    *pathc = 1;
    *cp = i + 1;
    if (i + 1 > argc - 1) {
      printf("Please enter correct file name\n");
      *pathc = 0;
    }
  }
}


/* Basic procedural dun generator */
int main(int argc, char * argv[]) {
	/*** process commandline arguments ***/
	int save = 0;
	int load = 0;
	int pathChange = 0;
	int cp = 0;
	if(argc > 2 && argc <= 5) {
		// save and load
		int i;
		for(i = 1; i < argc; i++) {
			argvPos(argc, argv, i, &save, &load, &pathChange, &cp);
		}
	} else if(argc == 2) {
		// save or load
		argvPos(argc, argv, 1, &save, &load, &pathChange, &cp);
	} else if(argc > 5) {
		printf("Max commandline arguments exceed\n");
	}

	// set up seed
  srand(time(NULL));

  // set up file path
	char *home = getenv("HOME");
	char *path = malloc((strlen(home) + 50) * sizeof(char));
	strcpy(path, home);
	strcat(path, "/.rlg327");
	if(pathChange == 0) {
		strcat(path, "/dun");
	} else {
		strcat(path, "/");
		strcat(path, argv[cp]);
	}

	dun dun = initDun(21, 80, 12);

	if(load == 0) {
		spawnDun(&dun);
		spawnCorridors(&dun);
		spawnStair(&dun);
	} else {
		loadDungeon(&dun, path);
	}
	/*** dun is fully initiated ***/
	Character pc = spawnCharacter(&dun, '@', -1, -1, 1);
	addCharacter(&dun, pc);
	newMapNonTun(&dun);
	newMapTun(&dun);

	printDun(&dun, 0, 0);
	printDun(&dun, 1, 0);
	printDun(&dun, 0, 1);

	if(save == 1) {
		saveDungeon(&dun, path);
	}

	/* free our arrays */
	int i;
	for(i = 0; i < dun.h; i++) {
		free(dun.t[i]);
	}
	free(dun.t);
	for(i = 0; i < dun.h; i++) {
		free(dun.p[i]);
	}
	free(dun.p);
	free(dun.room);
	free(dun.carr);
	for(i = 0; i < dun.h; i++) {
		free(dun.csnt[i]);
	}
	free(dun.csnt);
	for(i = 0; i < dun.h; i++) {
		free(dun.cost[i]);
	}
	free(dun.cost);
	free(path);
	return 0;
}
