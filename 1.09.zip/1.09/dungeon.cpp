#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <stdint.h>
#include <endian.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <limits.h>
#include <unistd.h>
#include <ncurses.h>
#include "binaryheap.h"
#include "dungeon.h"
#include <iostream>
#include <fstream>
#include <string>
#include <cstring>
#include <math.h>

using namespace std;

int place_room(Dungeon * dun) {
	int x = (rand() % (dun->w-1)) +1;
	int y = (rand() % (dun->h-1)) +1;
	Room new_room;
	new_room.br = initPos();
	new_room.tl = initPos();
	new_room.ctr = initPos();
	/*
	set top right to rng number; might be worth making a more detailed placer with a lower
		fail rate
	*/
	setPosX(new_room.tl, x);
	setPosY(new_room.tl, y);
	/* for RNG, maybe do a rando room width/height and re-set .br */

	HW: ;

	int we = (rand() % 4) + 4; /* width, expanded, up to 4 more */
	int he = (rand() % 4) + 3; /* height, expanded, up to 4 more */

	if(we == he) {
		/* if we have a square, re-generate */
		goto HW;
	}

	new_room.h = he;
	new_room.w = we;

	setPosX(new_room.br, x + new_room.w-1);
	setPosY(new_room.br, y + new_room.h-1);

	/* check for rooms loaded into the dun buffer already */
	int i;
	int j;
	int placed = -1;
	int passed = 0;
	for(i = y; i < dun->h-1 && i < y+he; i++) {
		for(j = x; j < dun->w-1 && j < x+we; j++) {
			if(dun->p[i][j].c != '.') {
				passed++;
			}
		}
	}

	/* return a failure if not all cells within the "Room" passed */
	if(passed < we*he) {
		return placed; /* should be -1 */
	}

	/* return a failure if part of the room is out of bounds */
	if(getPosX(new_room.br) >= dun->w || getPosY(new_room.br) >= dun->h) {
		return placed;
	}


	/* check for surrounding rooms */

	/* top row */
	for(i = getPosX(new_room.tl)-1; i < getPosX(new_room.br)+2 && getPosX(new_room.tl)-1 >= 0 && getPosX(new_room.br)+1 < dun->w && getPosY(new_room.tl)-1 >= 0; i++) {
		if((dun->p[getPosY(new_room.tl)-1][i]).c == '.') {
			return placed;
		}
	}

	/* bottom row */
	for(i = getPosX(new_room.tl)-1; i < getPosX(new_room.br)+2 && getPosX(new_room.tl)-1 >= 0 && getPosX(new_room.br)+1 < dun->w && getPosY(new_room.br)+1 < dun->h; i++) {
		if((dun->p[getPosY(new_room.br)+1][i]).c == '.') {
			return placed;
		}
	}

	/* left side */
	for(i = getPosY(new_room.tl); i < getPosY(new_room.br)+1 && getPosY(new_room.br)+1 < dun->h && getPosX(new_room.tl)-1 >= 0; i++) {
		if((dun->p[i][getPosX(new_room.tl)-1]).c == '.') {
			return placed;
		}
	}

	/* right side */
	for(i = getPosY(new_room.tl); i < getPosY(new_room.br)+1 && getPosY(new_room.br)+1 < dun->h && getPosX(new_room.br)+1 < dun->w; i++) {
		if((dun->p[i][getPosX(new_room.br)+1]).c == '.') {
			return placed;
		}
	}


	/* successful placement */
	placed = 0;

	/* fill the room into the dun buffer and add to room array */
	for(i = y; i < y+he; i++) {
		for(j = x; j < x+we; j++) {
			dun->p[i][j].c = '.';
			dun->d[i][j].h = 0;
		}
	}


	if(dun->nr < dun->mr) {
		dun->nr++;
		new_room.id = dun->nr-1; /* reflects position in the array */
		setPosX(new_room.ctr, (new_room.w)/2 + getPosX(new_room.tl));
		setPosY(new_room.ctr, (new_room.h)/2 + getPosY(new_room.tl));
		/* printf("%d: (%d, %d)\n", new_room.id, new_room.ctr.x, new_room.ctr.y); */
		dun->r[dun->nr-1] = new_room;
	} else {
		return -1;
	}


	return placed;
}

/* assistant function for gen_corridors() to check if all rooms are connected */
int all_connected(int * cnxns, Dungeon * dun) {
	int i;

	for(i = 0; i < dun->nr; i++) {
		if(cnxns[i] != 1 || dun->r[i].c != TRUE) {
			return FALSE;
		}
	}

	return TRUE;
}

/* generates and marks corridors */
void gen_corridors(Dungeon * dun) {
	int i;
	int connected[dun->nr];
	for(i = 0; i < dun->nr; i++) {
		connected[i] = 0;
	}
	//memset(connected, 0, dun->nr * sizeof(int));
	double dists[dun->nr];
	for(i = 0; i < dun->nr; i++) {
		dists[i] = 0;
	}
	//memset(dists, 0.0, dun->nr * sizeof(double));
	int max_paths = dun->nr * 3;
	Path paths[max_paths]; /* max paths is 3 * number of rooms */
	int path_cnt = 0;
	int	room_pos = 0; /* current room in use */

	for(i = 0; i < dun->nr; i++) {
		dists[i] = -1; /* infinite at -1 */
	}
	dists[0] = 0;

	/* ensure all rooms are disconnected */
	for(i = 0; i < dun->nr; i++) {
		dun->r[i].c = FALSE;
	}

	/* primary loop, goal is to connect all rooms; 0 means true */
	while(all_connected(connected, dun) == FALSE && path_cnt < max_paths) {
		int i;
		double d;
		Path new_path;

		/* populate dists from the current position */
		for(i = 0; i < dun->nr; i++) {
			/* calculate distance */
			d =  sqrt(pow(getPosX(dun->r[i].ctr) - getPosX(dun->r[room_pos].ctr), 2) + pow(getPosY(dun->r[i].ctr) - getPosY(dun->r[room_pos].ctr), 2));
			dists[i] = d;
		}

		/* find the room to path to ;; if not connected already and the distance is shorter and isn't our current position */

		int next = -1;
		for(i = 0; i < dun->nr; i++) {
			if(connected[i] != 1 && next == -1 && room_pos != i) {
				next = i;
			} else if(connected[i] != 1 && dists[i] < dists[next] && room_pos != i) {
				next = i;
			}
		}

		/** this would - in the future - be the point of adding extraneous paths **/
		if(next != -1) {
			dun->r[room_pos].c = TRUE;
			dun->r[next].c = TRUE;
			connected[room_pos] = 1;
			new_path.prev = room_pos;
			new_path.next = next;
			paths[path_cnt] = new_path;
			room_pos = next;
			path_cnt++;
		} else {
			break;
		}

	}

	/* populate the dun grid (draw the paths using x/y chasing/pathing) */

	/* draw dun paths in the dun grid; start at room 0 as per above */

	for(i = 0; i < path_cnt; i++) {
		int x = getPosX(dun->r[paths[i].prev].ctr);
		int y = getPosY(dun->r[paths[i].prev].ctr);

		/*printf("%d: (%d, %d)\n", i, x, y);*/

		while(x != getPosX(dun->r[paths[i].next].ctr) || y != getPosY(dun->r[paths[i].next].ctr)) {
			int dirx = 0; /* -1 for left, 1 for right */
			int diry = 0; /* -1 for down, 1 for up */

			if(x < getPosX(dun->r[paths[i].next].ctr)) {
				dirx = 1;
			} else if(x > getPosX(dun->r[paths[i].next].ctr)) {
				dirx = -1;
			}

			if(y < getPosY(dun->r[paths[i].next].ctr)) {
				diry = 1;
			} else if(y > getPosY(dun->r[paths[i].next].ctr)) {
				diry = -1;
			}

			dun->d[y][x].p = 1;
			/* don't place corridors in rooms */
			if(dun->d[y][x].c != '.') {
				dun->d[y][x].c = '#';
				dun->d[y][x].h = 0;
			}

			if(dirx == -1) {
				x--;
			} else if(dirx == 1) {
				x++;
			} else if(diry == -1) {
				y--;
			} else if(diry == 1) {
				y++;
			}
		}

	}

}

/* generate a blank dungeon */
void gen_dun(Dungeon * dun) {
	/*** top 3 (0, 1, 2) are reserved for the pseudo-HUD ***/
	int i, j;

	/* set all slots to spaces originally */
	for(i = 0; i < dun->h; i++) {
		for(j = 0; j < dun->w; j++) {
			(dun->d[i][j]).c = ' ';	/* all basic rooms are spaces */
			int h = (rand() % 254) + 1;
			(dun->d[i][j]).h = h;
		}
	}

	/* immut-ify the outside rim */
	for(i = 0; i < dun->w; i++) {
		(dun->d[0][i]).h = 255;
	}
	for(i = 0; i < dun->w; i++) {
		(dun->d[dun->h-1][i]).h = 255;
	}
	for(i = 0; i < dun->h; i++) {
		(dun->d[i][0]).h = 255;
	}
	for(i = 0; i < dun->h; i++) {
		(dun->d[i][dun->w-1]).h = 255;
	}

	/* make p equal to d */
	for(i = 0; i < dun->h; i++) {
		for(j = 0; j < dun->w; j++) {
			dun->p[i][j] = dun->d[i][j];
		}
	}

	/* populate the rooms */
	int cnt = 0;
	int tst = 0;
	for(i = 0; dun->nr < dun->mr && cnt < 2000; i++) {
		tst = place_room(dun);
		if(tst < 0) {
			cnt++;
		}
	}

	/* set the stairs */
	int x;
	int y;

	int r_id = rand() % dun->nr;
	x = (rand() % dun->r[r_id].w) + getPosX(dun->r[r_id].tl);
	y = (rand() % dun->r[r_id].h) + getPosY(dun->r[r_id].tl);
	
	//lol
	dun->sd = initPos();
	dun->su = initPos();
	
	setPosX(dun->sd, x);
	setPosY(dun->sd, y);
	
	SD: ;
	r_id = rand() % dun->nr;
	x = (rand() % dun->r[r_id].w) + getPosX(dun->r[r_id].tl);
	y = (rand() % dun->r[r_id].h) + getPosY(dun->r[r_id].tl);
	setPosX(dun->su, x);
	setPosY(dun->su, y);
	
	if(getPosX(dun->su) == getPosX(dun->sd) && getPosY(dun->su) == getPosY(dun->sd))
		goto SD;

}

/* initializes the dun structure */
Dungeon init_dun(int h, int w, int mr) {
	Dungeon new_dun;
	new_dun.h	= h;
	new_dun.w	= w;
	new_dun.mr	= mr;
	new_dun.nr	= 0;
	new_dun.ns	= 0;
	new_dun.ms	= w*h; /* max sprites would be 1 per dun slot */
	new_dun.t	= 0;
	new_dun.go	= FALSE;

	/* dun buffer allocation+0'ing */
	new_dun.d = (Tile**)calloc(new_dun.h, sizeof(Tile *));

	int i;
	for(i = 0; i < new_dun.h; i++) {
		new_dun.d[i] = (Tile*)calloc(new_dun.w, sizeof(Tile));
	}

	/* dun visual buffer allocation+0'ing */
	new_dun.p = (Tile**)calloc(new_dun.h, sizeof(Tile *));

	for(i = 0; i < new_dun.h; i++) {
		new_dun.p[i] = (Tile*)calloc(new_dun.w, sizeof(Tile));
	}

	/* rooms allocation+0'ing */
	new_dun.r = (Room*)calloc(new_dun.mr, sizeof(Room));

	/* sprites allocation */
	new_dun.ss = (Sprite*)calloc(new_dun.ms, sizeof(Sprite *));

	/* djikstra-based cost map allocation */
	new_dun.cst = (int**)calloc(w*h, sizeof(int *));
	for(i = 0; i < new_dun.h; i++) {
		new_dun.cst[i] = (int*)calloc(new_dun.w, sizeof(int));
	}

	/* djikstra-based cost map allocation */
	new_dun.csnt = (int**)calloc(w*h, sizeof(int *));
	for(i = 0; i < new_dun.h; i++) {
		new_dun.csnt[i] = (int*)calloc(new_dun.w, sizeof(int));
	}
	
	/* item view map */
	new_dun.items = new Item[new_dun.ms];
	new_dun.nit = 0;

	return new_dun;
}

/* compare two ints used as costs ;; 0 if same, <0 if higher than key; >0 if lower than key */
int compare_int(const void *key, const void *with) {
	//printf("%d\n", *(const int *) key);
	return (const int) ((*(Tile_Node *) key).cost - (*(Tile_Node *) with).cost);
}

/* returns the hardness cost of an int hardness */
int h_calc(int h) {
	int hc = 0;

	if(h >= 0 && h < 85) {
		return 1;
	}
	if(h > 84 && h < 171) {
		return 2;
	}
	if(h > 170 && h < 255) {
		return 3;
	}

	return hc;
}

/* djikstra's take 2; with tunnelling */
void map_dun_t(Dungeon * dun) {
	binheap_t h;
	Tile_Node tiles[dun->h][dun->w];

	binheap_init(&h, compare_int, NULL);

	/* starts from top left */
	int xs[8] = {-1,0,1,1,1,0,-1,-1};
	int ys[8] = {-1,-1,-1,0,1,1,1,0};

	int i;
	int j;

	/* set all indices and insert the default values */
	for(i = 0; i < dun->h; i++) {
		for(j = 0; j < dun->w; j++) {
			tiles[i][j].y = i;
			tiles[i][j].x = j;
			tiles[i][j].cost = INT_MAX;
			tiles[i][j].v = FALSE;
		}
	}

	/* set the player's cost as 0: */
	//int px = dun->ss[dun->pc].p.x;
	//int py = dun->ss[dun->pc].p.y;
	int px = getSpriteAPX(dun->ss, dun->pc);
	int py = getSpriteAPY(dun->ss, dun->pc);

	tiles[py][px].cost = 0;
	tiles[py][px].v = TRUE;
	binheap_insert(&h, &tiles[py][px]);

	/* primary cost calculation logic */

	binheap_node_t	*p;

	while((p = (binheap_node_t*)binheap_remove_min(&h))) {
		int hx = ((Tile_Node *) p)->x;
		int hy = ((Tile_Node *) p)->y;
		int tc = ((Tile_Node *) p)->cost;

		int i;
		for(i = 0; i < 8; i++) {
			int x = hx + xs[i];
			int y = hy + ys[i];
			if(x > 0 && x < dun->w-1 && y > 0 && y < dun->h-1) {
				int hard = dun->d[y][x].h;
				if(hard < 255) {
						int trial_cost = tc + h_calc(hard);
						if((tiles[y][x].cost > trial_cost && tiles[y][x].v == TRUE) || tiles[y][x].v == FALSE) {
							tiles[y][x].cost = tc + h_calc(hard);
							tiles[y][x].v = TRUE;

							binheap_insert(&h, (void *) &tiles[y][x]);
						}
				}
			}
		}
	}

	/* copy the heatmap to the dun */
	for(i = 0; i < dun->h; i++) {
		for(j = 0; j < dun->w; j++) {
			dun->cst[i][j] = tiles[i][j].cost;
		}
	}


	/* clean up the heap */
	binheap_delete(&h);
}

/* djikstra's take 2 */
void map_dun_nont(Dungeon * dun) {
	binheap_t h;
	Tile_Node tiles[dun->h][dun->w];

	binheap_init(&h, compare_int, NULL);

	/* starts from top left */
	int xs[8] = {-1,0,1,1,1,0,-1,-1};
	int ys[8] = {-1,-1,-1,0,1,1,1,0};

	int i;
	int j;

	/* set all indices and insert the default values */
	for(i = 0; i < dun->h; i++) {
		for(j = 0; j < dun->w; j++) {
			tiles[i][j].y = i;
			tiles[i][j].x = j;
			tiles[i][j].cost = INT_MAX;
			tiles[i][j].v = FALSE;
		}
	}

	/* set the player's cost as 0: */
	//int px = dun->ss[dun->pc].p.x;
	//int py = dun->ss[dun->pc].p.y;
	int px = getSpriteAPX(dun->ss, dun->pc);
	int py = getSpriteAPY(dun->ss, dun->pc);

	tiles[py][px].cost = 0;
	tiles[py][px].v = TRUE;
	binheap_insert(&h, &tiles[py][px]);

	/* primary cost calculation logic */

	binheap_node_t	*p;

	while((p = (binheap_node_t*)binheap_remove_min(&h))) {
		int hx = ((Tile_Node *) p)->x;
		int hy = ((Tile_Node *) p)->y;
		int tc = ((Tile_Node *) p)->cost;

		int i;
		for(i = 0; i < 8; i++) {
			int x = hx + xs[i];
			int y = hy + ys[i];
			if(x > 0 && x < dun->w-1 && y > 0 && y < dun->h-1) {
				int hard = dun->d[y][x].h;
				if(hard == 0) {
						int trial_cost = tc + h_calc(hard);
						if((tiles[y][x].cost > trial_cost && tiles[y][x].v == TRUE) || tiles[y][x].v == FALSE) {
							tiles[y][x].cost = tc + h_calc(hard);
							tiles[y][x].v = TRUE;

							binheap_insert(&h, (void *) &tiles[y][x]);
						}
				}
			}
		}

	}

	/* copy the heatmap to the dun */
	for(i = 0; i < dun->h; i++) {
		for(j = 0; j < dun->w; j++) {
			dun->csnt[i][j] = tiles[i][j].cost;
		}
	}


	/* clean up the heap */
	binheap_delete(&h);
}

/* reads from a dun file */
void read_dun(Dungeon * dun, char * path) {
	FILE * file;
	file = fopen(path, "rb+");
	if(file == NULL) {
		fprintf(stderr, "FILE ERROR: Could not open dungeon file at %s! read_dungeon()\n", path);
        exit(1);
	}

	/* read the file-type marker */
	fseek(file, 0, SEEK_SET);
	char marker[6];
	fread(marker, 1, 6, file);

	/* read the file version marker */
	fseek(file, 6, SEEK_SET);
	uint32_t file_version;
	uint32_t file_version_be;
	fread(&file_version_be, sizeof(uint32_t), 1, file);
	file_version = be32toh(file_version_be);
	dun->v = file_version;

	/* read the size of file */
	fseek(file, 10, SEEK_SET);
	uint32_t size;
	uint32_t size_be;
	fread(&size_be, sizeof(uint32_t), 1, file);
	size = be32toh(size_be);
	dun->s = size;

	/* read the hardness values in */
	fseek(file, 14, SEEK_SET);
	int i;
	int j;
	for(i = 0; i < dun->h; i++) {
		for(j = 0; j < dun->w; j++) {
			int h;
			int8_t h_8;
			fread(&h_8, sizeof(int8_t), 1, file);
			h = (int) h_8;
			dun->d[i][j].h = h;
		}
	}

	/* read in rooms in dungeon */
	fseek(file, 1694, SEEK_SET);
	/* might want to make this just counted in 4's by the loop below, but w/e, math, amirite? */
	int room_i = 0;
	int room_count = (size - 1693) / 4;
	dun->nr = room_count;
	dun->r = (Room*)calloc(room_count, sizeof(Room));
	/* could probably be replaced with a getpos() call for complete-ness */
	int pos;
	for(pos = 1694; pos < (int)size; pos += 4) {
		int x_8;
		int w_8;
		int y_8;
		int h_8;
		fread(&x_8, sizeof(int8_t), 1, file);
		fread(&w_8, sizeof(int8_t), 1, file);
		fread(&y_8, sizeof(int8_t), 1, file);
		fread(&h_8, sizeof(int8_t), 1, file);

		//dun->r[room_i].tl.x = (int8_t) x_8;
		//dun->r[room_i].w = (int8_t) w_8;
		//dun->r[room_i].tl.y = (int8_t) y_8;
		//dun->r[room_i].h = (int8_t) h_8;
		//dun->r[room_i].br.x = ((int8_t) x_8) + dun->r[room_i].w-1;
		//dun->r[room_i].br.y = ((int8_t) y_8) + dun->r[room_i].h-1;
		setPosX(dun->r[room_i].tl, (int8_t) x_8);
		dun->r[room_i].w = (int8_t) w_8;
		setPosY(dun->r[room_i].tl, (int8_t) y_8);
		dun->r[room_i].h = (int8_t) h_8;
		setPosX(dun->r[room_i].br, ((int8_t) x_8) + dun->r[room_i].w-1);
		setPosY(dun->r[room_i].br, ((int8_t) y_8) + dun->r[room_i].h-1);



		room_i++;
	}


	/* populate the rooms and corridors if not in rooms */
	/* add rooms to the dun buffer */
	int h;
	for(h = 0; h < dun->nr; h++) {
		for(i = getPosY(dun->r[h].tl); i < getPosY(dun->r[h].br)+1; i++) {
			for(j = getPosX(dun->r[h].tl); j < getPosX(dun->r[h].br)+1; j++) {
				dun->d[i][j].c = '.';
			}
		}
	}

	/* add corridors to the dun buffer */
	for(i = 0; i < dun->h; i++) {
		for(j = 0; j < dun->w; j++) {
			if(dun->d[i][j].c != '.' && dun->d[i][j].h == 0) {
				dun->d[i][j].c = '#';
				dun->d[i][j].p = 1;
			}
		}
	}


	fclose(file);
}

/* writes the dun file to ~/.rlg327/dun */
void write_dun(Dungeon * dun, char * path) {
	FILE * file;

	/* folder creation logic */
	char * env_home = getenv("HOME");
	char * fdir_path;
	fdir_path = (char*)calloc(strlen(env_home) + 9, sizeof(char));
	strcpy(fdir_path, env_home);
	strcat(fdir_path, "/.rlg327");
	mkdir(fdir_path, S_IRWXU);
	/* mkdir will return -1 when it fails, but it will fail if the file exists so it doesn't especially matter to catch it as no output would be provided */


	file = fopen(path, "wb+");
	if(file == NULL) {
		fprintf(stderr, "FILE ERROR: Could not open dun file at %s! write_dun()\n", path);
        exit(1);
	}

	/* write the file-type marker */
	fseek(file, 0, SEEK_SET);
	char marker[7];
	strcpy(marker, "RLG327");
	fwrite(marker, sizeof(char), 6, file);

	/* write the file version marker */
	fseek(file, 6, SEEK_SET);
	uint32_t file_version = 0;
	uint32_t file_version_be = htobe32(file_version);
	fwrite(&file_version_be, sizeof(uint32_t), 1, file);

	/* write the size of the file ;; unsure how to properly calculate */
	fseek(file, 10, SEEK_SET);
 	uint32_t size = 1693 + (4 * dun->nr);
	uint32_t size_be = htobe32(size);
	fwrite(&size_be, sizeof(uint32_t), 1, file);

	/* row-major dun matrix */
	fseek(file, 14, SEEK_SET);
	int pos = 14;
	int i;
	int j;

	for(i = 0; i < dun->h; i++) {
		for(j = 0; j < dun->w; j++) {
			fseek(file, pos, SEEK_SET);
			int8_t h;
			h = (int8_t)(dun->d[i][j].h);
			fwrite(&h, sizeof(int8_t), 1, file);
			pos++;
		}
	}

	/* room positions ;; 4 bytes per room */
	fseek(file, 1694, SEEK_SET);
	for(i = 0; i < dun->nr; i++) {
		int8_t x = (int8_t) getPosX(dun->r[i].tl);
		int8_t w = (int8_t) dun->r[i].w;
		int8_t y = (int8_t) getPosY(dun->r[i].tl);
		int8_t h = (int8_t) dun->r[i].h;

		fwrite(&x, sizeof(int8_t), 1, file);
		fwrite(&w, sizeof(int8_t), 1, file);
		fwrite(&y, sizeof(int8_t), 1, file);
		fwrite(&h, sizeof(int8_t), 1, file);
	}

	free(fdir_path);
	fclose(file);
}

/* parses commandline arguments */
void test_args(int argc, char ** argv, int here, int * s, int * l, int *p, int *cp, int *nm, int *nnc) {
		if(strcmp(argv[here], "--save") == 0) {
			*s = TRUE;
		} else if(strcmp(argv[here], "--load") == 0) {
			*l = TRUE;
		} else if(strcmp(argv[here], "-f") == 0) {
			*p = TRUE;
			*cp = here+1;
			if(here+1 > argc-1) {
				printf("Invalid filename argument!\n");
				*p = FALSE;
			}
		} else if(strcmp(argv[here], "--nummon") == 0) {
			*nm = atoi(argv[here+1]);
		} else if(strcmp(argv[here], "--no-ncurses") == 0) {
			*nnc = TRUE;
		}
}

void monster_inspect(Dungeon * dun, int x, int y) {
	clear();

	int i;
	for(i = 1; i < dun->ns; i++) {
		if(dun->ss[i].p.x == x && dun->ss[i].p.y == y) {
			int j;
			for(j = 0; j < dun->ss[i].dl; j++) {
				int n = dun->ss[i].desc[j].length();
				char tem[n+1];
				strcpy(tem, dun->ss[i].desc[j].c_str());
				mvprintw(j, 0, "%s", tem);
			}
		}
	}

	/* secondary window */
	WINDOW *w;
	w = newwin(24, 80, 0, 0);
	/* handle user interaction */
	REMI: ;
	int32_t k;
	k = getch();
	refresh();

	switch(k) {
	case 27:
			/* ESC */
			return;
			break;
		default:
			goto REMI;
	}
	clear();
	refresh();
	delwin(w);
	print_dun(dun, 0, 0);
}

/* monster list view */
void monster_list(Dungeon * dun) {
	clear();

	/* monster view array and population */
	char mons [dun->ns-1][30];
	int i;
	for(i = 1; i < dun->ns; i++) {
		char ns[6];
		char ew[5];

		//int hd = dun->ss[0].p.y - dun->ss[i].p.y;
		//int wd = dun->ss[0].p.x - dun->ss[i].p.x;
		int hd = getSpriteAPY(dun->ss, 0) - getSpriteAPY(dun->ss, i);
		int wd = getSpriteAPX(dun->ss, 0) - getSpriteAPX(dun->ss, i);

		if(hd > 0)
			strcpy(ns, "north");
		else
			strcpy(ns, "south");

		if(wd > 0)
			strcpy(ew, "west");
		else
			strcpy(ew, "east");

		if(dun->ss[i].a == true)
			sprintf(mons[i-1], "%c, %2d %s and %2d %s", getSpriteAC(dun->ss, i), abs(hd), ns, abs(wd), ew);
	}

	/* secondary window */
	WINDOW *w;
	w = newwin(24, 80, 0, 0);
	Bool scroll = FALSE;
	int top = 0;
	int bot;
	if(24 < dun->ns -1) {
		scroll = TRUE;
		bot = 23;
	} else {
		bot = dun->ns -2;
	}

	int j;
	for(;;) {
		/* put the monster view to the screen */
		for(i = top, j = 0; i < dun->ns -1 && i <= bot && j < 24; i++, j++) {
			mvprintw(j, 0, mons[i]);
		}

		/* handle user interaction */
		MLV: ;
		int32_t k;
		k = getch();

		switch(k) {
			case KEY_UP:
				/* scroll up */
				if(scroll == FALSE)
					goto MLV;

				if(top-1 >= 0) {
					top--;
					bot--;
				}
				clear();

				break;
			case KEY_DOWN:
				/* scroll down */
				if(scroll == FALSE)
					goto MLV;

				if(bot+1 < dun->ns-1) {
					bot++;
					top++;
				}
				clear();

				break;
			case 27:
				/* ESC */
				return;
				break;
			default:
				goto MLV;
		}

		wrefresh(w);
	}

	delwin(w);
	print_dun(dun, 0, 0);
}

/* inventory list view */
void inventory_list(Dungeon * dun, bool is_equip) {
	clear();

	INV: ;
	int i;
	int l = 10;
	char c = 48;

	if(is_equip) {
		l = 12;
		c = 97;
	}

	char scr [l][70];

	/* inventory view array and population */
	for(i = 0; i < l; i++, c++) {
		/* equip or inv view */
		if(is_equip)
			if(dun->plyr->eqsp[i])
				sprintf(scr[i], "%c: %s", c, dun->plyr->eqs[i].n.c_str());
			else
				sprintf(scr[i], "%c: ", c);
		else
			if(dun->plyr->invp[i])
				sprintf(scr[i], "%c: %s", c, dun->plyr->inv[i].n.c_str());
			else
				sprintf(scr[i], "%c: ", c);
	}

	/* secondary window */
	WINDOW *w;
	w = newwin(24, 80, 0, 0);

	int j;
	for(;;) {
		/* put the inventory view to the screen */
		for(i = 0, j = 0; i < l && j < 24; i++, j++) {
			mvprintw(j, 0, scr[i]);
		}
		refresh();

		/* handle user interaction */
		MLV: ;
		int32_t k;
		int index;
		int to_move;
		k = getch();

		switch(k) {
			case 'w':
			/* wear */
				WR: ;
				//32 long
				mvprintw(15, 0, "Which inventory item to wear?: ");
				refresh();
				k = getch();
				if(k == 27)
					goto EIL;
				mvaddch(15, 32, k);
				refresh();
				if(k < 48 || k > 57)
					goto WR;
				index = k - 48;
				//check if item occupied eqp slot and equippable
				if(dun->plyr->inv[index].t >= NONEQUIP)
					goto INV;

				if(dun->plyr->eqsp[dun->plyr->inv[index].t] == false) {
					dun->plyr->invp[index] = false;
					dun->plyr->eqs[dun->plyr->inv[index].t] = dun->plyr->inv[index];
					dun->plyr->eqsp[dun->plyr->inv[index].t] = true;
				} else {
					Item tmp = dun->plyr->eqs[dun->plyr->inv[index].t];
					dun->plyr->eqs[dun->plyr->inv[index].t] = dun->plyr->inv[index];
					dun->plyr->inv[index] = tmp;
				}
				clear();

				goto INV;
				break;
			case 't':
			/* take off */
				TO: ;
				//incl "to" len is 35 total ;; 23 as of "to"
				mvprintw(15, 0, "Which inventory item to take off?: ");
				refresh();
				k = getch();
				if(k == 27)
					goto EIL;
				mvaddch(15, 36, k);
				refresh();
				if(k < 97 || k > 108)
					goto TO;
				index = k - 97;
				//take them clothes off
				dun->plyr->eqsp[index] = false;
				to_move = -1;
				for(i = 0; i < 10; i++)
				{
					if(dun->plyr->invp[i] == false) {
						to_move = i;
						break;
					}
				}
				if(to_move < 0)
					goto INV;
				dun->plyr->invp[to_move] = true;
				dun->plyr->eqsp[index] = false;
				dun->plyr->inv[to_move] = dun->plyr->eqs[index];
				clear();
				goto INV;

				break;
			case 'd':
			/* drop */
				DP: ;
				//32 long
				mvprintw(15, 0, "Which inventory item to drop?: ");
				refresh();
				k = getch();
				if(k == 27)
					goto EIL;
				mvaddch(15, 32, k);
				refresh();
				if(k < 48 || k > 57)
					goto DP;
				index = k - 48;
				//drop it like it's hot
				dun->plyr->invp[index] = false;
				dun->nit++;
				dun->items[dun->nit-1] = dun->plyr->inv[index];
				dun->items[dun->nit-1].p.x = dun->plyr->p.x;
				dun->items[dun->nit-1].p.y = dun->plyr->p.y;
				clear();
				goto INV;

				break;
			case 'x':
			/* expunge */
				EE: ;
				//36 long
				mvprintw(15, 0, "Which inventory item to expunge?: ");
				refresh();
				k = getch();
				if(k == 27)
					goto EIL;
				mvaddch(15, 36, k);
				refresh();
				if(k < 48 || k > 57)
					goto EE;
				index = k - 48;
				//exterminatus
				dun->plyr->invp[index] = false;
				clear();
				goto INV;

				break;
			case 'I':
			/* inspect */
			//new window and all that
				IT: ;
				//36 long
				mvprintw(15, 0, "Which inventory item to inspect?: ");
				refresh();
				k = getch();
				if(k == 27)
					goto EIL;
				mvaddch(15, 36, k);
				refresh();
				if(k < 48 || k > 57)
					goto IT;
				index = k - 48;
				//look very closely
				clear();
				for(i = 0; i < dun->plyr->inv[index].dl; i++)
				{
					mvprintw(i, 0, dun->plyr->inv[index].desc[i].c_str());
				}
				refresh();
				getch();
				clear();
				goto INV;

				break;
			case 27:
				/* ESC */
				return;
				break;
			default:
				goto MLV;
		}
		clear();
		refresh();
	}
	EIL: ;

	delwin(w);
	print_dun(dun, 0, 0);
}

/* processes pc movements ;; validity checking is in monsters.c's gen_move_sprite() */
void parse_pc(Dungeon * dun, Bool * run, Bool * regen) {
	GCH: ;
	int32_t k;
	int32_t gk;
	int x;
	int y;
	char dir;
	char dist;
	int distance;
	int target = -1;
	int l;

	k = getch();
	if(k == 'Q') {
		*run = FALSE;
		return;
	}

	switch(k) {
		case 'h':
			H: ;
			dun->plyr->to.x = dun->plyr->p.x - 1;
			break;
		case '4':
			goto H;
			break;
		case 'l':
			L: ;
			dun->plyr->to.x = dun->plyr->p.x + 1;
			break;
		case '6':
			goto L;
			break;
		case 'k':
			K: ;
			dun->plyr->to.y = dun->plyr->p.y - 1;
			break;
		case '8':
			goto K;
			break;
		case 'j':
			J: ;
			dun->plyr->to.y = dun->plyr->p.y + 1;
			break;
		case '2':
			goto J;
			break;
		case 'y':
			Y: ;
			dun->plyr->to.x = dun->plyr->p.x - 1;
			dun->plyr->to.y = dun->plyr->p.y - 1;
			break;
		case '7':
			goto Y;
			break;
		case 'u':
			U: ;
			dun->plyr->to.x = dun->plyr->p.x - 1;
			dun->plyr->to.y = dun->plyr->p.y + 1;

			break;
		case '9':
			goto U;
			break;
		case 'n':
			N: ;
			dun->plyr->to.x = dun->plyr->p.x + 1;
			dun->plyr->to.y = dun->plyr->p.y + 1;
			break;
		case '3':
			goto N;
			break;
		case 'b':
			B: ;
			dun->plyr->to.x = dun->plyr->p.x + 1;
			dun->plyr->to.y = dun->plyr->p.y - 1;
			break;
		case '1':
			goto B;
			break;
		case '<':
			/* stair up */
			if(dun->plyr->p.x == getPosX(dun->su) && dun->plyr->p.y == getPosY(dun->su))
				*regen = TRUE;
			break;
		case '>':
			/* stair down */
			if(dun->plyr->p.x == getPosX(dun->sd) && dun->plyr->p.y == getPosY(dun->sd))
				*regen = TRUE;
			break;
		case '5':
			break;
		case ' ':
			break;
		case 'L':
		  x = getSpriteAPX(dun->ss, dun->pc);
	  	y = getSpriteAPY(dun->ss, dun->pc);
		  LGCH: ;
		  print_dun_teleport(dun, 0, 0, x, y);

		  gk = getch();
		  switch(gk) {
				case 27:
			  	print_dun(dun, 0, 0);
					break;
			  case 'h':
			  	LH: ;
			  	if (x > 1)
			  		x -= 1;
			  	goto LGCH;
		  	case '4':
			  	goto LH;
		  	case 'l':
			  	LL: ;
			  	if (x < 78)
				  	x += 1;
			  	goto LGCH;
		  	case '6':
			  	goto LL;
		  	case 'k':
			  	LK: ;
			  	if (y > 1)
				  	y -= 1;
			  	goto LGCH;
		  	case '8':
				  goto LK;
		  	case 'j':
			  	LJ: ;
		  		if (y < 19)
		  			y += 1;
		  		goto LGCH;
		  	case '2':
			  	goto LJ;
	  		case 'y':
	  			LY: ;
	  			if (x > 1 && y > 1) {
	  				x -= 1;
	  				y -= 1;
	  			}
	  			goto LGCH;
	  		case '7':
	  			goto LY;
	  		case 'u':
	  			LU: ;
	  			if (x < 78 && y > 1) {
	  				x += 1;
	  				y -= 1;
	  			}
	  			goto LGCH;
	  		case '9':
	  			goto LU;
	  		case 'n':
	  			LN: ;
	  			if (x < 78 && y < 19) {
	  				x += 1;
	  				y += 1;
	  			}
	  			goto LGCH;
	  		case '3':
	  			goto LN;
	  		case 'b':
	  			LB: ;
	  			if (x > 1 && y < 19) {
	  				x -= 1;
	  				y += 1;
	  			}
	   			goto LGCH;
        case '1':
	  			goto LB;
		  	case 't':
				  monster_inspect(dun, x, y);
					print_dun(dun, 0, 0);
					break;
	  		default:
	  			goto LGCH;
	    	}
		  goto GCH;
		case 'f':
			print_dun_full(dun, 0, 0);
			goto GCH;
		case 'g':
	  	x = getSpriteAPX(dun->ss, dun->pc);
	  	y = getSpriteAPY(dun->ss, dun->pc);
	  	GGCH: ;
		  print_dun_teleport(dun, 0, 0, x, y);

	  	gk = getch();
	  	switch(gk) {
		  	case 'h':
			  	GH: ;
			  	if (x > 1)
				  	x -= 1;
				  goto GGCH;
		  	case '4':
			  	goto GH;
	  		case 'l':
			  	GL: ;
			  	if (x < 78)
			  		x += 1;
			  	goto GGCH;
		  	case '6':
			  	goto GL;
	  		case 'k':
			  	GK: ;
			  	if (y > 1)
			  		y -= 1;
			  	goto GGCH;
		  	case '8':
			  	goto GK;
		  	case 'j':
			  	GJ: ;
			  	if (y < 19)
				  	y += 1;
			  	goto GGCH;
		  	case '2':
			  	goto GJ;
		  	case 'y':
			  	GY: ;
			  	if (x > 1 && y > 1) {
				  	x -= 1;
			  		y -= 1;
			  	}
			  	goto GGCH;
		  	case '7':
			  	goto GY;
	  		case 'u':
		 	  	GU: ;
			  	if (x < 78 && y > 1) {
				  	x += 1;
				  	y -= 1;
			  	}
		  		goto GGCH;
		  	case '9':
			  	goto GU;
		  	case 'n':
			  	GN: ;
			  	if (x < 78 && y < 19) {
				  	x += 1;
				  	y += 1;
			  	}
			  	goto GGCH;
	  		case '3':
			  	goto GN;
		  	case 'b':
			  	GB: ;
			  	if (x > 1 && y < 19) {
			  		x -= 1;
			  		y += 1;
			  	}
			  	goto GGCH;
		  	case '1':
			  	goto GB;
		  	case 'r':
			  	x = rand() % 77 + 1;
			  	y = rand() % 18 + 1;
			  	setSpriteAToX(dun->ss, dun->pc, x);
			  	setSpriteAToY(dun->ss, dun->pc, y);
			  	setSpriteAPX(dun->ss, dun->pc, x);
			  	setSpriteAPY(dun->ss, dun->pc, y);
					dun->plyr->to.x = x;
					dun->plyr->p.x = x;
					dun->plyr->to.y = y;
					dun->plyr->p.y = y;
			  	print_dun(dun, 0, 0);
			  	break;
		  	case 'g':
			  	setSpriteAToX(dun->ss, dun->pc, x);
		  		setSpriteAToY(dun->ss, dun->pc, y);
				  setSpriteAPX(dun->ss, dun->pc, x);
			  	setSpriteAPY(dun->ss, dun->pc, y);
					dun->plyr->to.x = x;
					dun->plyr->p.x = x;
					dun->plyr->to.y = y;
					dun->plyr->p.y = y;
			  	print_dun(dun, 0, 0);
		  		break;
		  	default:
		  		goto GGCH;
	  	}
		  goto GCH;
		case 'm':
			monster_list(dun);
			print_dun(dun, 0, 0);
			goto GCH;
		case 'i':
			inventory_list(dun, false);
			print_dun(dun, 0, 0);
			goto GCH;
		case 'e':
			inventory_list(dun, true);
			print_dun(dun, 0, 0);
			goto GCH;
		case 'a':
			/* auto attack (ranged) ;; only uses basic equipped weapon */
			if(dun->plyr->eqsp[RANGED]) {
				if(dun->plyr->hlt) {
					//clean up line of sight/hitting the enemy
					if(dun->ss[dun->plyr->lt].a && (dun->ss[dun->plyr->lt].p.x == dun->plyr->p.x || dun->ss[dun->plyr->lt].p.y == dun->plyr->p.y)) {

						int dam = 0;
						int i;
   					 	for(i = 0; i < 12; i++)
   					 	{
    						if(dun->plyr->eqsp[i])
    							dam += dun->plyr->eqs[i].hib;
    					}

						//apply damage
    					if(dun->ss[dun->plyr->lt].s.hp - dam <= 0)
    						dun->ss[dun->plyr->lt].a = false;
    					else
    						dun->ss[dun->plyr->lt].s.hp -= dam;
					}
				}
			}
			break;
		case 's':
			/* select target (for ranged attack) ;; parses further selection and distance/calculations */

			mvprintw(0, 0, "What direction [n, e, s, w] do you wish to fire?: ");

			dir = getch();

			mvprintw(1, 0, "How far away do you wish to fire?: ");

			dist = getch();
			distance = dist - 48;

			//see if we hit a target
			target = -1;
			for(l = 1; l < dun->ns; l++)
			{
				//lazy and goto's are hard
				int tx = dun->plyr->p.x;
				int ty = dun->plyr->p.y;
				if(dir == 'n')
					ty -= distance;
				if(dir == 's')
					ty += distance;
				if(dir == 'e')
					tx += distance;
				if(dir == 'w')
					tx -= distance;

				if((dun->ss[l].p.x == tx && dun->ss[l].p.y == ty) || (dun->ss[l].to.x == tx && dun->ss[l].to.y == ty))
					target = l;

				if(dun->ss[l].lp.x == tx && dun->ss[l].lp.y == ty)
					target = l;

				//mvprintw(3, 0, "%d %d", tx, ty);

				tx = dun->ss[0].p.x;
				ty = dun->ss[0].p.y;
				if(dir == 'n')
					ty -= distance;
				if(dir == 's')
					ty += distance;
				if(dir == 'e')
					tx += distance;
				if(dir == 'w')
					tx -= distance;

				if((dun->ss[l].p.x == tx && dun->ss[l].p.y == ty) || (dun->ss[l].to.x == tx && dun->ss[l].p.y == ty))
					target = l;
			}

			if(dun->plyr->eqsp[RANGED] == false) {
				mvprintw(0, 0, "You possess no ranged weapon                                     ");
				mvprintw(1, 0, "                                                                ");
				getch();
				break;
			}

			if(target > 0) {
				//clean up line of sight/hitting the enemy
				if(dun->ss[target].a && (dun->ss[target].p.x == dun->plyr->p.x || dun->ss[target].p.y == dun->plyr->p.y)) {

					int dam = 0;
					int i;
					for(i = 0; i < 12; i++)
					{
						if(dun->plyr->eqsp[i])
							dam += dun->plyr->eqs[i].hib;
					}

					//apply damage
					if(dun->ss[target].s.hp - dam <= 0)
						dun->ss[target].a = false;
					else
						dun->ss[target].s.hp -= dam;

					mvprintw(0, 0, "Your attack hits %d damage                                        ", dam);
					mvprintw(1, 0, "                                                                ");
				}
				dun->plyr->hlt = true;
				dun->plyr->lt = target;
			} else {
				mvprintw(0, 0, "Your attack misses                                         ");
				mvprintw(1, 0, "                                                                ");
			}

			getch();

			refresh();
			print_dun(dun, 0, 0);
			break;
		default:
			goto GCH;
	}

    int i;
    bool combat = false;
    int targ = -1;
    /* movement validity check */
	if(dun->d[dun->plyr->to.y][dun->plyr->to.x].h > 0) {
		dun->plyr->to.x = dun->plyr->p.x;
		dun->plyr->to.y = dun->plyr->p.y;
	} else {
		dun->plyr->p.x = dun->plyr->to.x;
		dun->plyr->p.y = dun->plyr->to.y;
	}
	for(i = 1; i < dun->ns; i++)
	{
		if(dun->plyr->to.x == dun->ss[i].p.x && dun->plyr->to.y == dun->ss[i].p.y) {
			dun->plyr->to.x = dun->plyr->p.x;
			dun->plyr->to.y = dun->plyr->p.y;
			combat = true;
			targ = i;
			break;
		}
	}

	int spbns = 0;
	for(i = 0; i < 12; i++)
	{
		if(dun->plyr->eqsp[i])
			spbns += dun->plyr->eqs[i].spb;
	}

	dun->plyr->t += (100 / (dun->plyr->s.s + spbns));

    /* combat sequence */
    if(combat) {
    	int dam = 0;
    	for(i = 0; i < 12; i++)
    	{
    		if(dun->plyr->eqsp[WEAPON])
    		{
    			if(dun->plyr->eqsp[i])
    				dam += dun->plyr->eqs[i].hib;
    		} else {
    			dam = dun->plyr->s.a->roll();
    			break;
    		}
    	}
    	//apply damage
    	if(dun->ss[targ].s.hp - dam <= 0)
    		dun->ss[targ].a = false;
    	else
    		dun->ss[targ].s.hp -= dam;
    }

    /* check for picking up an item */
    int j;
	int inv_loc = -1;
    for(j = 0; j < 10; j++)
    {
    	if(dun->plyr->invp[j] == false)
    		inv_loc = j;
    }

    for(i = 0; i < dun->nit; i++)
    {
    	if(inv_loc >= 0) {
    		if(dun->items[i].p.x == dun->plyr->p.x && dun->items[i].p.y == dun->plyr->p.y) {
    			//remove i from list ;; add to inventory at inv_loc
    			dun->plyr->inv[inv_loc] = dun->items[i];
    			dun->plyr->invp[inv_loc] = true;

    			//remove i from the dun
    			j = i;
    			for(; j < dun->nit - 1; j++)
    			{
    				dun->items[j] = dun->items[j+1];
    			}
    			dun->nit--;
    		}
    	}
    }
}

int rolldie(std::string s)
{
	int b, n, d;
	char* str = new char [s.length()+1];
	std::strcpy(str, s.c_str());
	sscanf(str, "%d%*c%d%*c%d", &b, &n, &d);
	Dice* di = new Dice(b, n, d);
	return di->roll();
}

Dice* getdie(std::string s)
{
	int b, n, d;
	char* str = new char [s.length()+1];
	std::strcpy(str, s.c_str());
	sscanf(str, "%d%*c%d%*c%d", &b, &n, &d);
	Dice* di = new Dice(b, n, d);
	return di;
}

/* parses the monsters file in ~/.rlg327 */
int parsemonsters(Dungeon * dun) {
	char * env_path = getenv("HOME");
	char * path = (char*)calloc(strlen(env_path) + 50, sizeof(char));
	strcpy(path, env_path);
	strcat(path, "/.rlg327/monster_desc.txt");

	int dm = 0;
	bool first = true;
	dun->mm = 100;
	vector <SpriteTemp> mons;


	string line;
	ifstream md(path);
	if(md.is_open()) {
		SpriteTemp b_mo;
		SpriteTemp mo;
		while(getline(md, line)) {
			string str = "RLG327 MONSTER DESCRIPTION 1";
			std::size_t found = line.find(str);
			if(first) {
				if(found==std::string::npos) {
					cout << "Invalid file head!" << endl;
					return -2;
				}
				first = false;
			} else {
				//standard file parsing

				size_t n = 0;

				if(line == "BEGIN MONSTER")
					mo = b_mo;
				else if((n = line.find("NAME")) != std::string::npos)
					mo.n = line.substr(5, 77);
				else if((n = line.find("SYMB")) != std::string::npos) {
					mo.pa = line.at(5);
					//mo.c = 'P';
					//cout << "SYMBOL READ" << endl;
					//printf("SIMBUL IN SYMB: %c\n", mo.c);
				} else if((n = line.find("ABIL")) != std::string::npos) {
					//line.find statements to match abils
					if((n = line.find("SMART")) != std::string::npos)
						mo.s.in = true;
					else
						mo.s.in = false;
					if((n = line.find("TELE")) != std::string::npos)
						mo.s.te = true;
					else
						mo.s.te = false;
					//printf("TELE STUFF: %d", (int)n);
					if((n = line.find("TUNNEL")) != std::string::npos)
						mo.s.tu = true;
					else
						mo.s.tu = false;
					if((n = line.find("ERRATIC")) != std::string::npos)
						mo.s.eb = true;
					else
						mo.s.eb = false;
					if((n = line.find("PASS")) != std::string::npos)
						mo.s.pa = true;
					else
						mo.s.pa = false;
					if((n = line.find("UNIQ")) != std::string::npos)
						mo.s.uni = true;
					else
						mo.s.uni = false;
					if((n = line.find("BOSS")) != std::string::npos)
						mo.s.boss = true;
					else
						mo.s.boss = false;


				} else if((n = line.find("COLOR")) != std::string::npos) {
					//line.find statements to match enums/ints
					if((n = line.find("RED")) != std::string::npos)
						mo.color = RED;
					else if((n = line.find("GREEN")) != std::string::npos)
						mo.color = GREEN;
					else if((n = line.find("BLUE")) != std::string::npos)
						mo.color = BLUE;
					else if((n = line.find("CYAN")) != std::string::npos)
						mo.color = CYAN;
					else if((n = line.find("YELLOW")) != std::string::npos)
						mo.color = YELLOW;
					else if((n = line.find("MAGENTA")) != std::string::npos)
						mo.color = MAGENTA;
					else if((n = line.find("WHITE")) != std::string::npos)
						mo.color = WHITE;
					else if((n = line.find("BLACK")) != std::string::npos)
						mo.color = BLACK;

				} else if((n = line.find("DAM")) != std::string::npos) {
					//save as a die
					mo.s.a = getdie(line.substr(4, line.size()));

				} else if((n = line.find("DESC")) != std::string::npos) {
					//parse description
					vector <std::string> desc;

					while(getline(md, line)) {
						if(line.find(".") == 0)
							break;

						desc.push_back(line.substr(0, 77));
					}

					mo.desc = new string[desc.size()];
					mo.dl = desc.size();

					int i = desc.size() -1;
					while(desc.size() > 0) {
						string s = desc.back();
						desc.pop_back();
						mo.desc[i] = s;
						i--;
					}

				} else if((n = line.find("SPEED")) != std::string::npos) {
					mo.s.s = getdie(line.substr(6, line.size()));

				} else if((n = line.find("HP")) != std::string::npos) {
					//health points
					mo.s.hp = getdie(line.substr(3, line.size()));

				} else if((n = line.find("RRTY")) != std::string::npos) {
					mo.rar = stoi(line.substr(5, line.size()));

				} else if((n = line.find("END")) != std::string::npos) {
					mons.push_back(mo);
					dm++;
				}
			}

		}
	}
	else
		return -1;

	dun->dm = dm;

	dun->md = new SpriteTemp[mons.size()];

	int i = 0;
	while(mons.size() > 0) {
		SpriteTemp tmp = mons.back();
		dun->md[i] = tmp;
		mons.pop_back();
		i++;
	}

	return 0;
}

/* parses the objects file in ~/.rlg327 */
int parseitems(Dungeon * dun) {
	char * env_path = getenv("HOME");
	char * path = (char*)calloc(strlen(env_path) + 50, sizeof(char));
	strcpy(path, env_path);
	strcat(path, "/.rlg327/object_desc.txt");

	int di = 0;
	bool first = true;
	dun->mi = 100;
	vector <ItemTemp> items;


	string line;
	ifstream od(path);
	if(od.is_open()) {
		ItemTemp b_it;
		ItemTemp it;
		while(getline(od, line)) {
			//cout << line << '\n';

			if(first) {
				string str = "RLG327 OBJECT DESCRIPTION 1";
			    std::size_t found = line.find(str);
				if(found==std::string::npos) {
					cout << "Invalid file head!" << endl;
					return -2;
				}
				first = false;
			} else {
				//standard file parsing
				size_t n = 0;

				if(line == "BEGIN OBJECT")
					it = b_it;
				else if((n = line.find("NAME")) != std::string::npos)
					it.n = line.substr(5, 77);
				else if((n = line.find("SYMB")) != std::string::npos)
					it.s = (char)line.at(5);
				else if((n = line.find("TYPE")) != std::string::npos) {
					//line.find statements to match enums
					if((n = line.find("WEAPON")) != std::string::npos)
						it.t = WEAPON;
					else if((n = line.find("OFFHAND")) != std::string::npos)
						it.t = OFFHAND;
					else if((n = line.find("RANGED")) != std::string::npos)
						it.t = RANGED;
					else if((n = line.find("ARMOR")) != std::string::npos)
						it.t = ARMOR;
					else if((n = line.find("HELMET")) != std::string::npos)
						it.t = HELMET;
					else if((n = line.find("CLOAK")) != std::string::npos)
						it.t = CLOAK;
					else if((n = line.find("GLOVES")) != std::string::npos)
						it.t = GLOVES;
					else if((n = line.find("BOOTS")) != std::string::npos)
						it.t = BOOTS;
					else if((n = line.find("RING")) != std::string::npos)
						it.t = RING;
					else if((n = line.find("AMULET")) != std::string::npos)
						it.t = AMULET;
					else if((n = line.find("LIGHT")) != std::string::npos)
						it.t = LIGHT;
					else if((n = line.find("SCROLL")) != std::string::npos)
						it.t = SCROLL;
					else if((n = line.find("BOOK")) != std::string::npos)
						it.t = BOOK;
					else if((n = line.find("FLASK")) != std::string::npos)
						it.t = FLASK;
					else if((n = line.find("GOLD")) != std::string::npos)
						it.t = GOLD;
					else if((n = line.find("AMMUNITION")) != std::string::npos)
						it.t = AMMUNITION;
					else if((n = line.find("FOOD")) != std::string::npos)
						it.t = FOOD;
					else if((n = line.find("WAND")) != std::string::npos)
						it.t = WAND;
					else if((n = line.find("CONTAINER")) != std::string::npos)
						it.t = CONTAINER;


				} else if((n = line.find("COLOR")) != std::string::npos) {
					//line.find statements to match enums/ints
					if((n = line.find("RED")) != std::string::npos)
						it.c = RED;
					else if((n = line.find("GREEN")) != std::string::npos)
						it.c = GREEN;
					else if((n = line.find("BLUE")) != std::string::npos)
						it.c = BLUE;
					else if((n = line.find("CYAN")) != std::string::npos)
						it.c = CYAN;
					else if((n = line.find("YELLOW")) != std::string::npos)
						it.c = YELLOW;
					else if((n = line.find("MAGENTA")) != std::string::npos)
						it.c = MAGENTA;
					else if((n = line.find("WHITE")) != std::string::npos)
						it.c = WHITE;
					else if((n = line.find("BLACK")) != std::string::npos)
						it.c = BLACK;

				} else if((n = line.find("WEIGHT")) != std::string::npos)
					it.w = getdie(line.substr(7, line.size()));
				else if((n = line.find("HIT")) != std::string::npos)
					it.hib = getdie(line.substr(4, line.size()));
				else if((n = line.find("DAM")) != std::string::npos) {
					//save as a die
					it.d = getdie(line.substr(4, line.size()));

				} else if((n = line.find("ATTR")) != std::string::npos)
					it.sa = getdie(line.substr(5, line.size()));
				else if((n = line.find("VAL")) != std::string::npos)
					it.v = getdie(line.substr(4, line.size()));
				else if((n = line.find("DODGE")) != std::string::npos)
					it.dob = getdie(line.substr(6, line.size()));
				else if((n = line.find("DEF")) != std::string::npos)
					it.deb = getdie(line.substr(4, line.size()));
				else if((n = line.find("SPEED")) != std::string::npos) {
					it.spb = getdie(line.substr(6, line.size()));
				} else if((n = line.find("DESC")) != std::string::npos) {
					//parse description
					vector <std::string> desc;

					while(getline(od, line)) {
						if(line.find(".") == 0)
							break;

						desc.push_back(line.substr(0, 77));
					}

					it.desc = new string[desc.size()];
					it.dl = desc.size();

					int i = desc.size() -1;
					while(desc.size() > 0) {
						string s = desc.back();
						desc.pop_back();
						it.desc[i] = s;
						i--;
					}

				} else if ((n = line.find("ART")) != std::string::npos) {
					if((n = line.find("TRUE")) != std::string::npos)
						it.art = 1;
					else if((n = line.find("FALSE")) != std::string::npos)
						it.art = 0;

		  	} else if((n = line.find("RRTY")) != std::string::npos) {
					it.rar = stoi(line.substr(5, line.size()));

				} else if((n = line.find("END")) != std::string::npos) {
					items.push_back(it);
					di++;
				}
			}
		}
	}
	else
		return -1;

	dun->di = di;

	dun->id = new ItemTemp[items.size()];

	int i = 0;
	while(items.size() > 0) {
		ItemTemp tmp = items.back();
		dun->id[i] = tmp;
		items.pop_back();
		i++;
	}

	return 0;
}


void printmds(Dungeon * dun)
{
	int i;
	for(i = 0; i < dun->dm; i++)
	{
		cout << "Name: " << dun->md[i].n << endl;

		printf("Symbol: %c\n", dun->md[i].pa);

		cout << "Description: " << endl;
		int j;
		for(j = 0; j < dun->md[i].dl; j++)
		{
			cout << dun->md[i].desc[j] << endl;
		}

		switch(dun->md[i].c)
		{
		case RED: cout << "Color: RED" << endl; break;
		case GREEN: cout << "Color: GREEN" << endl; break;
		case BLUE: cout << "Color: BLUE" << endl; break;
		case CYAN: cout << "Color: CYAN" << endl; break;
		case YELLOW: cout << "Color: YELLOW" << endl; break;
		case MAGENTA: cout << "Color: MAGENTA" << endl; break;
		case WHITE: cout << "Color: WHITE" << endl; break;
		case BLACK: cout << "Color: BLACK" << endl; break;
		}

		//printf("Speed: %d\n", dun->md[i].s.s);
		cout << "Speed: " << dun->md[i].s.s->string() << endl;

		cout << "Abilities: ";
		if(dun->md[i].s.in)
			cout << "SMART ";
		if(dun->md[i].s.te)
			cout << "TELE ";
		if(dun->md[i].s.tu)
			cout << "TUNNEL ";
		if(dun->md[i].s.eb)
			cout << "ERRATIC ";
		if(dun->md[i].s.pa)
			cout << "PASS ";
		cout << endl;

		//printf("HP: %d\n", dun->md[i].s.hp);
		cout << "HP: " << dun->md[i].s.hp->string() << endl;

		cout << "Damage: " << dun->md[i].s.a->string() << endl;

		cout << endl;
	}
}

/* Basic procedural dun generator */
int main(int argc, char * argv[]) {
	/*** process commandline arguments ***/
	int max_args = 8;
	int saving = FALSE;
	int loading = FALSE;
	int pathing = FALSE;
	int nnc = FALSE;
	int num_mon = 1;
	int custom_path = 0;
	if(argc > 2 && argc <= max_args) {
		/* both --save and --load */
		int i;
		for(i = 1; i < argc; i++) {
			test_args(argc, argv, i, &saving, &loading, &pathing, &custom_path, &num_mon, &nnc);
		}
	} else if(argc == 2) {
		/* one arg */
		test_args(argc, argv, 1, &saving, &loading, &pathing, &custom_path, &num_mon, &nnc);
	} else if(argc > max_args) {
		/* more than 2 commandline arguments, argv[0] is gratuitous */
		printf("Too many arguments!\n");
	} else {
		/* other; most likely 0 */
	}
	/*** end processing commandline arguments ***/


	/* init the dun with default dun size and a max of 12 rooms */
	srand(time(NULL));

	/* create 2 char pointers so as not to pollute the original HOME variable */
	char * env_path = getenv("HOME");
	/* char * path = calloc(strlen(env_path) + 17, sizeof(char)); */
	char * path = (char*)calloc(strlen(env_path) + 50, sizeof(char));
	strcpy(path, env_path);
	strcat(path, "/.rlg327");
	if(pathing == TRUE) {
		strcat(path, "/");
		strcat(path, argv[custom_path]);
	} else {
		strcat(path, "/dungeon");
	}


	/* persistent player character */
	Bool regen = FALSE;
	Sprite * p_pc = initSprite();
	PC * p_ppc = new PC;

	/*** dun generation starts here ***/
	DUNGEN: ;

	Dungeon dun = init_dun(21, 80, 12);

	parsemonsters(&dun);
	parseitems(&dun);
	dun.of = new ObjectFactory(dun.di, dun.id);
	dun.mf = new MonsterFactory(dun.dm, dun.md);
	//printmds(&dun);
	//getchar();

	if(loading == FALSE) {
		gen_dun(&dun);
		gen_corridors(&dun);
	} else {
		read_dun(&dun, path);
	}
	/*** dun is fully initiated ***/
	Sprite * pc = gen_sprite_fac(&dun, '@', -1, -1, 1);
	add_sprite(&dun, pc);

	int i;
	int j;

	for(i = 0; i < 200; i++) {
		dun.nmd[i] = " * ";
	}

	for(i = 0; i < num_mon; i++) {
		int swh = 0;
		Sprite * m = gen_sprite_fac(&dun,'m' , -1, -1, 1);
		while (swh == 0) {
		  swh = 1;
			// check if unique
			if(m->s.uni == 1) {
				for (j = 0; j < 199; j++) {
					if (m->n == dun.nmd[j]) {
						swh = 0;
          	m = gen_sprite_fac(&dun,'m' , -1, -1, 1);
					}
				}
			}
			// check rarity
			if (swh == 1) {
				int rarn = rand() % 99;
				if (rarn >= m->rar) {
					swh = 0;
					m = gen_sprite_fac(&dun,'m' , -1, -1, 1);
				}
			}
		}
		dun.nmd[i] = m->n;
		setSpriteSn(m, i);
		add_sprite(&dun, m);
	}

	std::string	nid[10] = {" ", " ", " ", " ", " ", " ", " ", " ", " ", " "};

	for(i = 0; i < 10; i++) {
		int swh = 0;
		Item it = dun.of->GetObj();
		while (swh == 0) {
			swh = 1;
		  for (j = 0; j < 10; j++) {
			  if (it.n == nid[j]) {
				  swh = 0;
					it = dun.of->GetObj();
			  }
		  }
			// check rarity
			if (swh == 1) {
				int rarn = rand() % 99;
				if (rarn >= it.rar) {
					swh = 0;
					it = dun.of->GetObj();
				}
			}
		}
	nid[i] = it.n;
	placeitem(&dun, it);
	}

	map_dun_nont(&dun);
	map_dun_t(&dun);
	/*** dun is fully generated ***/
	//getchar();

	/* main loop */

	if(regen == TRUE) {
		int px = getSpriteAPX(dun.ss, 0);
		int py = getSpriteAPY(dun.ss, 0);
		copyASprite(dun.ss, 0, p_pc);
		copyPC(dun.plyr, p_ppc);
		setSpriteAPX(dun.ss, 0, px);
		setSpriteAPY(dun.ss, 0, py);
		setSpriteAToX(dun.ss, 0, px);
		setSpriteAToY(dun.ss, 0, py);
	}


	for(i = 1; i < dun.ns; i++) {
		gen_move_sprite(&dun, i);
		//nexts[i] = next;
	}

	if(regen == TRUE)
		goto PNC;


	/* ncurses or not ;; this will likely amount to nothing */
	void (*printer)(Dungeon*, int, int);
	if(nnc == FALSE) {
		printer = &print_dun;
		initscr();
		raw();
		noecho();
		curs_set(0);
		set_escdelay(25);
		keypad(stdscr, TRUE);
		start_color();
	} else {
		printer = &print_dun_nnc;
	}

	PNC: ;
	regen = FALSE;


	print_dun(&dun, 0, 0);
	Bool first = TRUE;
	Bool run = TRUE;
	while(run == TRUE) {

		int l = 0;
		for(i = 0; i < dun.ns; i++) {
			if(getSpriteAT(dun.ss, i) < getSpriteAT(dun.ss, l)) {
				l = i;
			}
		}


		if(l == dun.pc || first == TRUE) {
			parse_pc(&dun, &run, &regen);
			copyASprite(dun.ss, 0, dun.plyr);

			if(regen == TRUE) {
				copySprite(p_pc, thisASprite(dun.ss, 0));
				copyPC(p_ppc, dun.plyr);
				goto DUNFREE;
			}

			//gen_move_sprite(&dun, l);
			map_dun_nont(&dun);
			map_dun_t(&dun);

			print_dun(&dun, 0, 0);
		} else {
			gen_move_sprite(&dun, l);
						parse_move(&dun, l);

		}


		//print_dun(&dun, 1, 0);  // prints non-tunneling dijkstra's
		//print_dun(&dun, 0, 1);  // prints tunneling dijkstra's


		// ----- check if game is over -----
		// if player dies, game is over and pc lose
		if(dun.go == TRUE || dun.ss[0].a == FALSE)
			break;

    // if the boss dies, game is over and pc win
		Bool any = check_boss_alive(&dun);
		if(any == FALSE) {
			goto END;
		}
		first = FALSE;
	}
	printer(&dun, 0, 0);

	/*** tear down sequence ***/
	END: ;
	delwin(stdscr);
	endwin();
	if (check_boss_alive(&dun) == TRUE) {
		cout << "*************************" << endl << endl <<
		        "You either died or quit, you lose!" <<
						endl << endl << "*************************" << endl;
	} else if (check_boss_alive(&dun) == FALSE){
		cout << "*************************" << endl << endl <<
		        "You win!" <<
						endl << endl << "*************************" << endl;
	}

	if(saving == TRUE) {
		write_dun(&dun, path);
	}

	DUNFREE: ;
	/* cpp stuff */
	delete[] dun.items;

	delete[] dun.md;
	delete[] dun.id;
	delete dun.plyr;
	delete dun.su;
	delete dun.sd;

	/* free our arrays */
	for(i = 0; i < dun.h; i++) {
		free(dun.d[i]);
	}
	free(dun.d);
	for(i = 0; i < dun.h; i++) {
		free(dun.p[i]);
	}
	free(dun.p);
	free(dun.r);
	free(dun.ss);
	for(i = 0; i < dun.h; i++) {
		free(dun.csnt[i]);
	}
	free(dun.csnt);
	for(i = 0; i < dun.h; i++) {
		free(dun.cst[i]);
	}
	free(dun.cst);

	if(regen == TRUE)
		goto DUNGEN;

	free(path);
	return 0;
}
