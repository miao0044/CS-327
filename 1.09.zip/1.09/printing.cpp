#include <stdio.h>
#include <ncurses.h>
#include "dungeon.h"

void print_dun_full(Dungeon * dun, int nt, int t) {
	clear();
	refresh();

	/* color definitions */
	init_pair(COLOR_BLACK, COLOR_WHITE, COLOR_BLACK);
	init_pair(COLOR_RED, COLOR_RED, COLOR_BLACK);
	init_pair(COLOR_GREEN, COLOR_GREEN, COLOR_BLACK);
	init_pair(COLOR_YELLOW, COLOR_YELLOW, COLOR_BLACK);
	init_pair(COLOR_BLUE, COLOR_BLUE, COLOR_BLACK);
	init_pair(COLOR_MAGENTA, COLOR_MAGENTA, COLOR_BLACK);
	init_pair(COLOR_CYAN, COLOR_CYAN, COLOR_BLACK);
	init_pair(COLOR_WHITE, COLOR_WHITE, COLOR_BLACK);



	int i;
	int j;
	int h;

	for(i = 0; i < dun->h; i++) {
		for(j = 0; j < dun->w; j++) {
			dun->p[i][j].c = ' ';
			dun->p[i][j].color = COLOR_BLACK;
		}
	}

	/* add corridors to the print buffer */
	for(i = 0; i < dun->h; i++) {
		for(j = 0; j < dun->w; j++) {
			if(dun->d[i][j].p == 1 || dun->d[i][j].c == '#' || dun->d[i][j].h == 0) {
				dun->p[i][j].c = '#';
			}
		}
	}

	/* add rooms to the print buffer */
	for(h = 0; h < dun->nr; h++) {
		for(i = getPosY(dun->r[h].tl); i < getPosY(dun->r[h].br)+1; i++) {
			for(j = getPosX(dun->r[h].tl); j < getPosX(dun->r[h].br)+1; j++) {
				dun->p[i][j].c = '.';
			}
		}
	}

	dun->p[getPosY(dun->su)][getPosX(dun->su)].c = '<';
	dun->p[getPosY(dun->sd)][getPosX(dun->sd)].c = '>';

	/* add items map to buffer */
	for(i = 0; i < dun->nit; i++) {
		char s = '*';

		switch(dun->items[i].t) {
		case WEAPON: s = '|'; break;
		case OFFHAND: s = ')'; break;
		case RANGED: s = '}'; break;
		case ARMOR: s = '['; break;
		case HELMET: s = ']'; break;
		case CLOAK: s = '('; break;
		case GLOVES: s = '{'; break;
		case BOOTS: s = '\\'; break;
		case RING: s = '='; break;
		case AMULET: s = '\"'; break;
		case LIGHT: s = '_'; break;
		case SCROLL: s = '~'; break;
		case BOOK: s = '\?'; break;
		case FLASK: s = '!'; break;
		case GOLD: s = '$'; break;
		case AMMUNITION: s = '/'; break;
		case FOOD: s = ','; break;
		case WAND: s = '-'; break;
		case CONTAINER: s = '%'; break;
		default: break;
		}

		/* item colors */
		int c = COLOR_WHITE;

		switch(dun->items[i].c) {
		case RED: c = COLOR_RED; break;
		case  GREEN: c = COLOR_GREEN; break;
		case  BLUE: c = COLOR_BLUE; break;
		case  CYAN: c = COLOR_CYAN; break;
		case  YELLOW: c = COLOR_YELLOW; break;
		case  MAGENTA: c = COLOR_MAGENTA; break;
		case  WHITE: c = COLOR_WHITE; break;
		case  BLACK: c = COLOR_BLACK; break;
		default: c = c; break;
		}

		dun->p[dun->items[i].p.y][dun->items[i].p.x].c = s;
		dun->p[dun->items[i].p.y][dun->items[i].p.x].color = c;
	}

	/* add sprites to the print buffer */
	for(i = 0; i < dun->ns; i++) {
		if(dun->ss[i].a == TRUE) {

			/* colors */
			int c = COLOR_WHITE;

			switch(dun->ss[i].color) {
			case RED: c = COLOR_RED; break;
			case  GREEN: c = COLOR_GREEN; break;
			case  BLUE: c = COLOR_BLUE; break;
			case  CYAN: c = COLOR_CYAN; break;
			case  YELLOW: c = COLOR_YELLOW; break;
			case  MAGENTA: c = COLOR_MAGENTA; break;
			case  WHITE: c = COLOR_WHITE; break;
			case  BLACK: c = COLOR_BLACK; break;
			default: c = COLOR_WHITE; break;
			}

			dun->p[dun->ss[i].p.y][dun->ss[i].p.x].color = c;

			dun->p[getSpriteAPY(dun->ss, i)][getSpriteAPX(dun->ss, i)].c = getSpriteAC(dun->ss, i);
		}
	}

	/* print non-tunnelling dijkstra's */
	if(nt > 0) {
		for(i = 0; i < dun->h; i++) {
			for(j = 0; j < dun->w; j++) {
				if(dun->d[i][j].h == 0) {
					int c = dun->csnt[i][j];
					if(c >= 0 && c < 10) {
						dun->p[i][j].c = '0' + c;
					} else if(c >= 10 && c < 36) {
						dun->p[i][j].c = 'a' + (c - 10);
					} else if(c >= 36 && c < 62) {
						dun->p[i][j].c = 'A' + (c - 36);
					}
				}
			}
		}
	}

	/* print tunnelling dijkstra's */
	if(t > 0) {
		for(i = 0; i < dun->h; i++) {
			for(j = 0; j < dun->w; j++) {
				int c = dun->cst[i][j];
				if(c >= 0 && c < 10) {
					dun->p[i][j].c = '0' + c;
				} else if(c >= 10 && c < 36) {
					dun->p[i][j].c = 'a' + (c - 10);
				} else if(c >= 36 && c < 62) {
					dun->p[i][j].c = 'A' + (c - 36);
				}
			}
		}
	}

	/* print the print buffer */
	for(i = 0; i < dun->h; i++) {
		int j;
		for(j = 0; j < dun->w; j++) {
			attron(COLOR_PAIR(dun->p[i][j].color));
			//attron(COLOR_PAIR(COLOR_RED));

			mvaddch(i+1, j, (dun->p[i][j]).c);
			refresh();

			attroff(COLOR_PAIR(dun->p[i][j].color));
		}
	}
}

void print_dun_teleport(Dungeon * dun, int nt, int t, int gx, int gy) {
	clear();
	refresh();

	/* color definitions */
	init_pair(COLOR_BLACK, COLOR_WHITE, COLOR_BLACK);
	init_pair(COLOR_RED, COLOR_RED, COLOR_BLACK);
	init_pair(COLOR_GREEN, COLOR_GREEN, COLOR_BLACK);
	init_pair(COLOR_YELLOW, COLOR_YELLOW, COLOR_BLACK);
	init_pair(COLOR_BLUE, COLOR_BLUE, COLOR_BLACK);
	init_pair(COLOR_MAGENTA, COLOR_MAGENTA, COLOR_BLACK);
	init_pair(COLOR_CYAN, COLOR_CYAN, COLOR_BLACK);
	init_pair(COLOR_WHITE, COLOR_WHITE, COLOR_BLACK);



	int i;
	int j;
	int h;

	for(i = 0; i < dun->h; i++) {
		for(j = 0; j < dun->w; j++) {
			dun->p[i][j].c = ' ';
			dun->p[i][j].color = COLOR_BLACK;
		}
	}

	/* add corridors to the print buffer */
	for(i = 0; i < dun->h; i++) {
		for(j = 0; j < dun->w; j++) {
			if(dun->d[i][j].p == 1 || dun->d[i][j].c == '#' || dun->d[i][j].h == 0) {
				dun->p[i][j].c = '#';
			}
		}
	}

	/* add rooms to the print buffer */
	for(h = 0; h < dun->nr; h++) {
		for(i = getPosY(dun->r[h].tl); i < getPosY(dun->r[h].br)+1; i++) {
			for(j = getPosX(dun->r[h].tl); j < getPosX(dun->r[h].br)+1; j++) {
				dun->p[i][j].c = '.';
			}
		}
	}

	dun->p[getPosY(dun->su)][getPosX(dun->su)].c = '<';
	dun->p[getPosY(dun->sd)][getPosX(dun->sd)].c = '>';

	/* add items map to buffer */
	for(i = 0; i < dun->nit; i++) {
		char s = '*';

		switch(dun->items[i].t) {
		case WEAPON: s = '|'; break;
		case OFFHAND: s = ')'; break;
		case RANGED: s = '}'; break;
		case ARMOR: s = '['; break;
		case HELMET: s = ']'; break;
		case CLOAK: s = '('; break;
		case GLOVES: s = '{'; break;
		case BOOTS: s = '\\'; break;
		case RING: s = '='; break;
		case AMULET: s = '\"'; break;
		case LIGHT: s = '_'; break;
		case SCROLL: s = '~'; break;
		case BOOK: s = '\?'; break;
		case FLASK: s = '!'; break;
		case GOLD: s = '$'; break;
		case AMMUNITION: s = '/'; break;
		case FOOD: s = ','; break;
		case WAND: s = '-'; break;
		case CONTAINER: s = '%'; break;
		default: break;
		}

		/* item colors */
		int c = COLOR_WHITE;

		switch(dun->items[i].c) {
		case RED: c = COLOR_RED; break;
		case  GREEN: c = COLOR_GREEN; break;
		case  BLUE: c = COLOR_BLUE; break;
		case  CYAN: c = COLOR_CYAN; break;
		case  YELLOW: c = COLOR_YELLOW; break;
		case  MAGENTA: c = COLOR_MAGENTA; break;
		case  WHITE: c = COLOR_WHITE; break;
		case  BLACK: c = COLOR_BLACK; break;
		default: c = c; break;
		}

		dun->p[dun->items[i].p.y][dun->items[i].p.x].c = s;
		dun->p[dun->items[i].p.y][dun->items[i].p.x].color = c;
	}

	/* add sprites to the print buffer */
	for(i = 0; i < dun->ns; i++) {
		if(dun->ss[i].a == TRUE) {

			/* colors */
			int c = COLOR_WHITE;

			switch(dun->ss[i].color) {
			case RED: c = COLOR_RED; break;
			case  GREEN: c = COLOR_GREEN; break;
			case  BLUE: c = COLOR_BLUE; break;
			case  CYAN: c = COLOR_CYAN; break;
			case  YELLOW: c = COLOR_YELLOW; break;
			case  MAGENTA: c = COLOR_MAGENTA; break;
			case  WHITE: c = COLOR_WHITE; break;
			case  BLACK: c = COLOR_BLACK; break;
			default: c = COLOR_WHITE; break;
			}

			dun->p[dun->ss[i].p.y][dun->ss[i].p.x].color = c;

			dun->p[getSpriteAPY(dun->ss, i)][getSpriteAPX(dun->ss, i)].c = getSpriteAC(dun->ss, i);
		}
	}

	dun->p[gy][gx].c = '*';

	/* print non-tunnelling dijkstra's */
	if(nt > 0) {
		for(i = 0; i < dun->h; i++) {
			for(j = 0; j < dun->w; j++) {
				if(dun->d[i][j].h == 0) {
					int c = dun->csnt[i][j];
					if(c >= 0 && c < 10) {
						dun->p[i][j].c = '0' + c;
					} else if(c >= 10 && c < 36) {
						dun->p[i][j].c = 'a' + (c - 10);
					} else if(c >= 36 && c < 62) {
						dun->p[i][j].c = 'A' + (c - 36);
					}
				}
			}
		}
	}

	/* print tunnelling dijkstra's */
	if(t > 0) {
		for(i = 0; i < dun->h; i++) {
			for(j = 0; j < dun->w; j++) {
				int c = dun->cst[i][j];
				if(c >= 0 && c < 10) {
					dun->p[i][j].c = '0' + c;
				} else if(c >= 10 && c < 36) {
					dun->p[i][j].c = 'a' + (c - 10);
				} else if(c >= 36 && c < 62) {
					dun->p[i][j].c = 'A' + (c - 36);
				}
			}
		}
	}

	/* print the print buffer */
	for(i = 0; i < dun->h; i++) {
		int j;
		for(j = 0; j < dun->w; j++) {
			attron(COLOR_PAIR(dun->p[i][j].color));
			//attron(COLOR_PAIR(COLOR_RED));

			mvaddch(i+1, j, (dun->p[i][j]).c);
			refresh();

			attroff(COLOR_PAIR(dun->p[i][j].color));
		}
	}
}


/* prints heatmap */
void print_t_heatmap(Dungeon * dun) {
	int i;
	int j;
	for(i = 0; i < dun->h; i++) {
		for(j = 0; j < dun->w; j++) {
			int c = dun->cst[i][j];
			if(c >= 0 && c < 10) {
				printf("%d", c);
			} else if(c >= 10 && c < 36) {
				printf("%c", 'a' + (c - 10));
			} else if(c >= 36 && c < 62) {
				printf("%c", 'A' + (c - 36));
			} else {
				printf("%c", dun->d[i][j].c);
			}
		}
		printf("\n");
	}

}

/* prints heatmap */
void print_nont_heatmap(Dungeon * dun) {
	int i;
	int j;
	for(i = 0; i < dun->h; i++) {
		for(j = 0; j < dun->w; j++) {
			int c = dun->csnt[i][j];
			if(c >= 0 && c < 10) {
				printf("%d", c);
			} else if(c >= 10 && c < 36) {
				printf("%c", 'a' + (c - 10));
			} else if(c >= 36 && c < 62) {
				printf("%c", 'A' + (c - 36));
			} else {
				printf("%c", dun->d[i][j].c);
			}
		}
		printf("\n");
	}

}

/* prints the dun */
void print_dun(Dungeon * dun, int nt, int t) {
	clear();
	refresh();

	/* color definitions */
	init_pair(COLOR_BLACK, COLOR_WHITE, COLOR_BLACK);
	init_pair(COLOR_RED, COLOR_RED, COLOR_BLACK);
	init_pair(COLOR_GREEN, COLOR_GREEN, COLOR_BLACK);
	init_pair(COLOR_YELLOW, COLOR_YELLOW, COLOR_BLACK);
	init_pair(COLOR_BLUE, COLOR_BLUE, COLOR_BLACK);
	init_pair(COLOR_MAGENTA, COLOR_MAGENTA, COLOR_BLACK);
	init_pair(COLOR_CYAN, COLOR_CYAN, COLOR_BLACK);
	init_pair(COLOR_WHITE, COLOR_WHITE, COLOR_BLACK);



	int i;
	int j;
	int h;

	for(i = 0; i < dun->h; i++) {
		for(j = 0; j < dun->w; j++) {
			dun->p[i][j].c = ' ';
			dun->p[i][j].color = COLOR_BLACK;
		}
	}

	/* add corridors to the print buffer */
	for(i = 0; i < dun->h; i++) {
		for(j = 0; j < dun->w; j++) {
			if(dun->d[i][j].p == 1 || dun->d[i][j].c == '#' || dun->d[i][j].h == 0) {
				dun->p[i][j].c = '#';
			}
		}
	}

	/* add rooms to the print buffer */
	for(h = 0; h < dun->nr; h++) {
		for(i = getPosY(dun->r[h].tl); i < getPosY(dun->r[h].br)+1; i++) {
			for(j = getPosX(dun->r[h].tl); j < getPosX(dun->r[h].br)+1; j++) {
				dun->p[i][j].c = '.';
			}
		}
	}

	dun->p[getPosY(dun->su)][getPosX(dun->su)].c = '<';
	dun->p[getPosY(dun->sd)][getPosX(dun->sd)].c = '>';

	/* add items map to buffer */
	for(i = 0; i < dun->nit; i++) {
		char s = '*';

		switch(dun->items[i].t) {
		case WEAPON: s = '|'; break;
		case OFFHAND: s = ')'; break;
		case RANGED: s = '}'; break;
		case ARMOR: s = '['; break;
		case HELMET: s = ']'; break;
		case CLOAK: s = '('; break;
		case GLOVES: s = '{'; break;
		case BOOTS: s = '\\'; break;
		case RING: s = '='; break;
		case AMULET: s = '\"'; break;
		case LIGHT: s = '_'; break;
		case SCROLL: s = '~'; break;
		case BOOK: s = '\?'; break;
		case FLASK: s = '!'; break;
		case GOLD: s = '$'; break;
		case AMMUNITION: s = '/'; break;
		case FOOD: s = ','; break;
		case WAND: s = '-'; break;
		case CONTAINER: s = '%'; break;
		default: break;
		}

		/* item colors */
		int c = COLOR_WHITE;

		switch(dun->items[i].c) {
		case RED: c = COLOR_RED; break;
		case  GREEN: c = COLOR_GREEN; break;
		case  BLUE: c = COLOR_BLUE; break;
		case  CYAN: c = COLOR_CYAN; break;
		case  YELLOW: c = COLOR_YELLOW; break;
		case  MAGENTA: c = COLOR_MAGENTA; break;
		case  WHITE: c = COLOR_WHITE; break;
		case  BLACK: c = COLOR_BLACK; break;
		default: c = c; break;
		}

		dun->p[dun->items[i].p.y][dun->items[i].p.x].c = s;
		dun->p[dun->items[i].p.y][dun->items[i].p.x].color = c;
	}

	/* add sprites to the print buffer */
	for(i = 1; i < dun->ns; i++) {
		if(dun->ss[i].a == TRUE) {

			/* colors */
			int c = COLOR_WHITE;

			switch(dun->ss[i].color) {
			case RED: c = COLOR_RED; break;
			case  GREEN: c = COLOR_GREEN; break;
			case  BLUE: c = COLOR_BLUE; break;
			case  CYAN: c = COLOR_CYAN; break;
			case  YELLOW: c = COLOR_YELLOW; break;
			case  MAGENTA: c = COLOR_MAGENTA; break;
			case  WHITE: c = COLOR_WHITE; break;
			case  BLACK: c = COLOR_BLACK; break;
			default: c = COLOR_WHITE; break;
			}

			dun->p[dun->ss[i].p.y][dun->ss[i].p.x].color = c;

			dun->p[getSpriteAPY(dun->ss, i)][getSpriteAPX(dun->ss, i)].c = getSpriteAC(dun->ss, i);
		}
	}
	dun->p[dun->ss[0].p.y][dun->ss[0].p.x].color = COLOR_WHITE;
	dun->p[getSpriteAPY(dun->ss, 0)][getSpriteAPX(dun->ss, 0)].c = getSpriteAC(dun->ss, 0);

	/* print non-tunnelling dijkstra's */
	if(nt > 0) {
		for(i = 0; i < dun->h; i++) {
			for(j = 0; j < dun->w; j++) {
				if(dun->d[i][j].h == 0) {
					int c = dun->csnt[i][j];
					if(c >= 0 && c < 10) {
						dun->p[i][j].c = '0' + c;
					} else if(c >= 10 && c < 36) {
						dun->p[i][j].c = 'a' + (c - 10);
					} else if(c >= 36 && c < 62) {
						dun->p[i][j].c = 'A' + (c - 36);
					}
				}
			}
		}
	}

	/* print tunnelling dijkstra's */
	if(t > 0) {
		for(i = 0; i < dun->h; i++) {
			for(j = 0; j < dun->w; j++) {
				int c = dun->cst[i][j];
				if(c >= 0 && c < 10) {
					dun->p[i][j].c = '0' + c;
				} else if(c >= 10 && c < 36) {
					dun->p[i][j].c = 'a' + (c - 10);
				} else if(c >= 36 && c < 62) {
					dun->p[i][j].c = 'A' + (c - 36);
				}
			}
		}
	}

	updateMemory(dun);

	/* print the print buffer */
	for(i = 0; i < dun->h; i++) {
		int j;
		for(j = 0; j < dun->w; j++) {
			attron(COLOR_PAIR(dun->p[i][j].color));

			mvaddch(i+1, j, getMem(dun, i, j));
			refresh();

			attroff(COLOR_PAIR(dun->p[i][j].color));
		}
	}
}

/* prints the dun */
void print_dun_nnc(Dungeon * dun, int nt, int t) {
	int i;
	int j;
	int h;

	for(i = 0; i < dun->h; i++) {
		for(j = 0; j < dun->w; j++) {
			dun->p[i][j].c = ' ';
		}
	}

	/* add corridors to the print buffer */
	for(i = 0; i < dun->h; i++) {
		for(j = 0; j < dun->w; j++) {
			if(dun->d[i][j].p == 1 || dun->d[i][j].c == '#' || dun->d[i][j].h == 0) {
				dun->p[i][j].c = '#';
			}
		}
	}

	/* add rooms to the print buffer */
	for(h = 0; h < dun->nr; h++) {
		for(i = getPosY(dun->r[h].tl); i < getPosY(dun->r[h].br)+1; i++) {
			for(j = getPosX(dun->r[h].tl); j < getPosX(dun->r[h].br)+1; j++) {
				dun->p[i][j].c = '.';
			}
		}
	}


	/* add sprites to the print buffer */
	for(i = 0; i < dun->ns; i++) {
		if(dun->ss[i].a == TRUE)
			//dun->p[dun->ss[i].p.y][dun->ss[i].p.x].c = dun->ss[i].c;

			/* item colors */
			/*

			*/
			dun->p[getSpriteAPY(dun->ss, i)][getSpriteAPX(dun->ss, i)].c = getSpriteAC(dun->ss, i);
	}

	/* print non-tunnelling dijkstra's */
	if(nt > 0) {
		for(i = 0; i < dun->h; i++) {
			for(j = 0; j < dun->w; j++) {
				if(dun->d[i][j].h == 0) {
					int c = dun->csnt[i][j];
					if(c >= 0 && c < 10) {
						dun->p[i][j].c = '0' + c;
					} else if(c >= 10 && c < 36) {
						dun->p[i][j].c = 'a' + (c - 10);
					} else if(c >= 36 && c < 62) {
						dun->p[i][j].c = 'A' + (c - 36);
					}
				}
			}
		}
	}

	/* print tunnelling dijkstra's */
	if(t > 0) {
		for(i = 0; i < dun->h; i++) {
			for(j = 0; j < dun->w; j++) {
				int c = dun->cst[i][j];
				if(c >= 0 && c < 10) {
					dun->p[i][j].c = '0' + c;
				} else if(c >= 10 && c < 36) {
					dun->p[i][j].c = 'a' + (c - 10);
				} else if(c >= 36 && c < 62) {
					dun->p[i][j].c = 'A' + (c - 36);
				}
			}
		}
	}

	/* print the print buffer */
	for(i = 0; i < dun->h; i++) {
		int j;
		for(j = 0; j < dun->w; j++) {
			printf("%c", (dun->p[i][j]).c);
		}
		printf("\n");
	}
}
