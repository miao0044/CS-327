By: Xiwen Zhang (xiwenz), Li Miao (miao0044)

In this project, a 80x21 dungeon map is generated. The dungeon is surrounded by edges with hardness of 255, and contains 6-10 rooms. Added Dijkstra's algorithm to calculate the distance between each tile to player. Prints 3 maps: original map, non-tunneling map, and tunneling map. type "./dungeon --save" to save, and "./dungeon --load" to load.
