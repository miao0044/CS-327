#include <stdlib.h>
#include <string.h>

#include "binaryheap.h"

#define BINHEAP_START_SIZE 128

struct binheapNode {
  void *datum;
  uint32_t index;
};

void initializeBinaryHeap(BinaryHeap *h,
                  int32_t (*compare)(const void *key, const void *with),
                  void (*bhDelete)(void *))
{
  h->size = 0;
  h->array_size = BINHEAP_START_SIZE;
  h->compare = compare;
  h->bhDelete = bhDelete;

  h->array = calloc(h->array_size, sizeof (*h->array));
}

static void percolate_down(BinaryHeap *h, uint32_t index)
{
  uint32_t child;
  void *tmp;

  for (child = (2 * index) + 1;
       child < h->size;
       index = child, child = (2 * index) + 1) {
    if (child + 1 < h->size &&
        h->compare(h->array[child]->datum, h->array[child + 1]->datum) > 0) {
      child++;
    }
    if (h->compare(h->array[index]->datum, h->array[child]->datum) > 0) {
      tmp = h->array[index];
      h->array[index] = h->array[child];
      h->array[child] = tmp;
      h->array[index]->index = index;
      h->array[child]->index = child;
    }
  }
}

static void percolate_up(BinaryHeap *h, uint32_t index)
{
  uint32_t parent;
  BinaryHeapNode *tmp;

  for (parent = (index - 1) / 2;
       index && h->compare(h->array[index]->datum, h->array[parent]->datum) < 0;
       index = parent, parent = (index - 1) / 2) {
    tmp = h->array[index];
    h->array[index] = h->array[parent];
    h->array[parent] = tmp;
    h->array[index]->index = index;
    h->array[parent]->index = parent;
  } 
}

static void heapify(BinaryHeap *h)
{
  uint32_t i;

  for (i = (h->size + 1) / 2; i; i--) {
    percolate_down(h, i);
  }
  percolate_down(h, 0);
}



void initializeBinaryHeapArr(BinaryHeap *h, void *array, uint32_t size,  uint32_t nmemb, int32_t (*compare)(const void *key, const void *with),  void (*bhDelete)(void *))
{
  uint32_t i;
  char *a;

  h->size = h->array_size = nmemb;
  h->compare = compare;
  h->bhDelete = bhDelete;

  h->array = calloc(h->array_size, sizeof (*h->array));

  for (i = 0, a = array; i < h->size; i++) {
    h->array[i] = malloc(sizeof (*h->array[i]));
    h->array[i]->index = i;
    h->array[i]->datum = a + (i * size);
  }

  heapify(h);
}

void *binaryHeapPeekMin(BinaryHeap *h)
{
  return h->size ? h->array[0]->datum : NULL;
}

void *binaryHeapRemoveMin(BinaryHeap *h)
{
  void *tmp;

  if (!h->size) {
    return NULL;
  }

  tmp = h->array[0]->datum;
  free(h->array[0]);
  h->size--;
  h->array[0] = h->array[h->size];
  percolate_down(h, 0);

  return tmp;
}

void deleteBinaryHeap(BinaryHeap *h)
{
  uint32_t i;

  for (i = 0; i < h->size; i++) {
    if (h->bhDelete) {
      h->bhDelete(h->array[i]->datum);
    }
    free(h->array[i]);
  }
  free(h->array);
  memset(h, 0, sizeof (*h));
}

BinaryHeapNode *deleteBinaryInsert(BinaryHeap *h, void *v)
{
  BinaryHeapNode **tmp;
  BinaryHeapNode *retval;

  if (h->size == h->array_size) {
    h->array_size *= 2;
    tmp = realloc(h->array, h->array_size * sizeof (*h->array));
    if (!tmp) {
      /* Error */
    } else {
      h->array = tmp;
    }
  }

  h->array[h->size] = retval = malloc(sizeof (*h->array[h->size]));
  h->array[h->size]->datum = v;
  h->array[h->size]->index = h->size;

  percolate_up(h, h->size);
  h->size++;

  return retval;
}



void binaryHeapDecrease(BinaryHeap *h, BinaryHeapNode *n)
{
  percolate_up(h, n->index);
}

uint32_t binaryHeapIsEmpty(BinaryHeap *h)
{
  return !h->size;
}

#ifdef TESTING

#include <stdio.h>

int32_t compare_int(const void *key, const void *with)
{
  return *(const int32_t *) key - *(const int32_t *) with;
}

int main(int argc, char *argv[])
{
  BinaryHeap h;
  int32_t a[1024];
  int32_t i, j, r;
  int32_t parent, child;
  BinaryHeapNode *nodes[1024];

  for (i = 0; i < 1024; i++) {
    a[i] = 1024 - i;
  }

  initializeBinaryHeap(&h, compare_int, NULL);
  for (i = 0; i < 1024; i++) {
    deleteBinaryInsert(&h, a + i);
  }

  for (i = 0; i < 1024; i++) {
    parent = (i - 1) / 2;
    child = (2 * i) + 1;
    if (!i) {
      if (*(int *) h.array[i]->datum > *(int *) h.array[child]->datum ||
          *(int *) h.array[i]->datum > *(int *) h.array[child + 1]->datum) {
        printf("Error follows:\n");
      }
      printf("%4d:      %4d %4d %4d\n",
             h.array[i]->index,
             *(int *) h.array[i]->datum,
             *(int *) h.array[child]->datum,
             *(int *) h.array[child + 1]->datum);
    } else if (i < (h.size - 1) / 2) {
      if (*(int *) h.array[i]->datum < *(int *) h.array[parent]->datum ||
          *(int *) h.array[i]->datum > *(int *) h.array[child]->datum ||
          *(int *) h.array[i]->datum > *(int *) h.array[child + 1]->datum) {
        printf("Error follows:\n");
      }
      printf("%4d: %4d %4d %4d %4d\n",
             h.array[i]->index,
             *(int *) h.array[parent]->datum,
             *(int *) h.array[i]->datum,
             *(int *) h.array[child]->datum,
             *(int *) h.array[child + 1]->datum);
    } else {
      if (*(int *) h.array[i]->datum < *(int *) h.array[parent]->datum) {
        printf("Error follows:\n");
      }
      printf("%4d: %4d %4d\n",
             h.array[i]->index,
             *(int *) h.array[parent]->datum,
             *(int *) h.array[i]->datum);
    }
  }

  deleteBinaryHeap(&h);

  initializeBinaryHeapArr(&h, a, sizeof (*a), 1024, compare_int, NULL);

  for (i = 0; i < 1024; i++) {
    parent = (i - 1) / 2;
    child = (2 * i) + 1;
    if (!i) {
      if (*(int *) h.array[i]->datum > *(int *) h.array[child]->datum ||
          *(int *) h.array[i]->datum > *(int *) h.array[child + 1]->datum) {
        printf("Error follows:\n");
      }
      printf("%4d:      %4d %4d %4d\n",
             h.array[i]->index,
             *(int *) h.array[i]->datum,
             *(int *) h.array[child]->datum,
             *(int *) h.array[child + 1]->datum);
    } else if (i < (h.size - 1) / 2) {
      if (*(int *) h.array[i]->datum < *(int *) h.array[parent]->datum ||
          *(int *) h.array[i]->datum > *(int *) h.array[child]->datum ||
          *(int *) h.array[i]->datum > *(int *) h.array[child + 1]->datum) {
        printf("Error follows:\n");
      }
      printf("%4d: %4d %4d %4d %4d\n",
             h.array[i]->index,
             *(int *) h.array[parent]->datum,
             *(int *) h.array[i]->datum,
             *(int *) h.array[child]->datum,
             *(int *) h.array[child + 1]->datum);
    } else {
      if (*(int *) h.array[i]->datum < *(int *) h.array[parent]->datum) {
        printf("Error follows:\n");
      }
      printf("%4d: %4d %4d\n",
             h.array[i]->index,
             *(int *) h.array[parent]->datum,
             *(int *) h.array[i]->datum);
    }
  }

  while (!binaryHeapIsEmpty(&h)) {
    binaryHeapRemoveMin(&h);

    for (i = 0; i < h.size; i++) {
      parent = (i - 1) / 2;
      child = (2 * i) + 1;
      if (h.size == 1) {
        printf("%4d:      %4d\n",
               h.array[i]->index,
               *(int *) h.array[i]->datum);
      } else if (!i) {
        if (*(int *) h.array[i]->datum > *(int *) h.array[child]->datum ||
            *(int *) h.array[i]->datum > *(int *) h.array[child + 1]->datum) {
          printf("Error follows:\n");
        }
        printf("%4d:      %4d %4d %4d\n",
               h.array[i]->index,
               *(int *) h.array[i]->datum,
               *(int *) h.array[child]->datum,
               *(int *) h.array[child + 1]->datum);
      } else if (i < (h.size - 1) / 2) {
        if (*(int *) h.array[i]->datum < *(int *) h.array[parent]->datum ||
            *(int *) h.array[i]->datum > *(int *) h.array[child]->datum ||
            *(int *) h.array[i]->datum > *(int *) h.array[child + 1]->datum) {
          printf("Error follows:\n");
        }
        printf("%4d: %4d %4d %4d %4d\n",
               h.array[i]->index,
               *(int *) h.array[parent]->datum,
               *(int *) h.array[i]->datum,
               *(int *) h.array[child]->datum,
               *(int *) h.array[child + 1]->datum);
      } else {
        if (*(int *) h.array[i]->datum < *(int *) h.array[parent]->datum) {
          printf("Error follows:\n");
        }
        printf("%4d: %4d %4d\n",
               h.array[i]->index,
               *(int *) h.array[parent]->datum,
               *(int *) h.array[i]->datum);
      }
    }
  }

  deleteBinaryHeap(&h);

  initializeBinaryHeap(&h, compare_int, NULL);
  for (i = 0; i < 1024; i++) {
    nodes[i] = deleteBinaryInsert(&h, a + i);
  }

  for (i = 0; i < 1024; i++) {
    printf("%d\n", *(int *) nodes[i]->datum);
  }

  for (j = 0; j < 1; j++) {
    r = 1020;
    a[r] = 0;
    binaryHeapDecrease(&h, nodes[r]);
    for (i = 0; i < h.size; i++) {
      parent = (i - 1) / 2;
      child = (2 * i) + 1;
      if (h.size == 1) {
        printf("%4d:      %4d\n",
               h.array[i]->index,
               *(int *) h.array[i]->datum);
      } else if (!i) {
        if (*(int *) h.array[i]->datum > *(int *) h.array[child]->datum ||
            *(int *) h.array[i]->datum > *(int *) h.array[child + 1]->datum) {
          printf("Error follows:\n");
        }
        printf("%4d:      %4d %4d %4d\n",
               h.array[i]->index,
               *(int *) h.array[i]->datum,
               *(int *) h.array[child]->datum,
               *(int *) h.array[child + 1]->datum);
      } else if (i < (h.size - 1) / 2) {
        if (*(int *) h.array[i]->datum < *(int *) h.array[parent]->datum ||
            *(int *) h.array[i]->datum > *(int *) h.array[child]->datum ||
            *(int *) h.array[i]->datum > *(int *) h.array[child + 1]->datum) {
          printf("Error follows:\n");
        }
        printf("%4d: %4d %4d %4d %4d\n",
               h.array[i]->index,
               *(int *) h.array[parent]->datum,
               *(int *) h.array[i]->datum,
               *(int *) h.array[child]->datum,
               *(int *) h.array[child + 1]->datum);
      } else {
        if (*(int *) h.array[i]->datum < *(int *) h.array[parent]->datum) {
          printf("Error follows:\n");
        }
        printf("%4d: %4d %4d\n",
               h.array[i]->index,
               *(int *) h.array[parent]->datum,
               *(int *) h.array[i]->datum);
      }
    }
  }

  deleteBinaryHeap(&h);

  return 0;
}

#endif
