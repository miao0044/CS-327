#include <stdio.h>
#include <stdlib.h>
#include "dungeon.h"
#include "binaryheap.h"

// check if we can move to a location (objectively) 
bool test_loc(dun *dun, int x, int y, Character *crr) {
  if(x > 0 && x < dun->w-1 && y > 0 && y < dun->h-1) {
    int hard = dun->t[y][x].h;
    if(dun->t[y][x].h < 255) {
      if(crr->s.tun == FALSE && hard > 0)
        return FALSE;
      return TRUE;
    }
  }
  return FALSE;
}

// checks if a given sprite shares a room with the PC 
void with_pc(dun *dun, Character *s, bool *in) {
  int pc_rid  = -1;
  int s_rid  = -1;
  Character *pc = &(dun->carr[dun->pc]);

  int i;
  for(i = 0; i < dun->roomNum; i++) {
    if(s->p.x <= dun->room[i].br.x && s->p.y <= dun->room[i].br.y && s->p.x >= dun->room[i].tl.x && s->p.y >= dun->room[i].tl.y) {
      s_rid = i;
    }
    if(pc->p.x <= dun->room[i].br.x && pc->p.y <= dun->room[i].br.y && pc->p.x >= dun->room[i].tl.x && pc->p.y >= dun->room[i].tl.y) {
      pc_rid = i;
    }
  }
  if(pc_rid > 0 && s_rid > 0 && pc_rid == s_rid)
    *in = TRUE;
}
void parse_move(dun * dun, int sn) {
  dun->carr[sn].p.x = dun->carr[sn].to.x;
  dun->carr[sn].p.y = dun->carr[sn].to.y;
}

void add_sprite(dun * dun, Character s) {
  if(dun->ns < dun->ms) {
    dun->ns++;
  } else {
    goto END;
  }

  if(s.c == '@') {
    dun->pc = dun->ns - 1;
    }

  dun->carr[dun->ns - 1] = s;

  END: ;
}

void gen_move_sprite(dun *dun, int sn) {
  //make ss[sn] when possible
  int sx = dun->carr[sn].p.x;
  int sy = dun->carr[sn].p.y;
  int xs[8] = {-1,0,1,1,1,0,-1,-1};
  int ys[8] = {-1,-1,-1,0,1,1,1,0};

  Character *s = &(dun->carr[sn]);

  // increment the turn 
  dun->carr[sn].t += (100 / s->s.s);

  Position new = {-1, -1};

  dun->t[s->p.y][s->p.x].h -= 85;
  if(dun->t[s->p.y][s->p.x].h < 0)
    dun->t[s->p.y][s->p.x].h = 0;

  // make sure we're alive
  if(s->a == TRUE) {
    int i;
    int j;
    int err = rand() % 2; // we have a 50% chance to behave erratically 
    for(i = 0; i < 8; i++) {
      int px = sx + xs[i];
      int py = sy + ys[i];

      if(px >= 0 && px < dun->w && py >= 0 && py < dun->h) {
        // drunken PC movement as per assignment 1.04 
        if(sn == dun->pc)
          goto PCEB;
        if(s->s.err == FALSE || (s->s.err == TRUE && err)) {
          //new.x = sx;
          //new.y = sy;
        if(s->s.tel == FALSE) {
        // see if you're in the same room 
          bool in_room = FALSE;
        with_pc(dun, s, &in_room);
        if(in_room == TRUE) {
        //cache PC location
        s->pc = dun->carr[dun->pc].p;

        IN: ;
        if(s->s.in == TRUE) {
                //we are intelligent and can see our mark (tele or otherwise) 
        int k;
        int lowest = 0;
        bool set = FALSE;
        if(s->s.tun) {
                  //tunneling
        for(k = 0; k < 8; k++) {
if(xs[k]+sx >= 0 && xs[k]+sx < dun->w && ys[k]+sy >= 0 && ys[k]+sy < dun->h) {
  if(dun->t[ys[k]+sy][xs[k]+sx].h < 255 && dun->cost[ys[k]+sy][xs[k]+sx] < dun->cost[ys[lowest]+sy][xs[lowest]+sx] && test_loc(dun, xs[k]+sx, ys[k]+sy, s) == TRUE && test_loc(dun, xs[lowest]+sx, ys[lowest]+sy, s) == TRUE) {
                        lowest = k;
                        set = TRUE;
                      }
                    }
                  }
  } else {
                  //non-tunneling
                  for(k = 0; k < 8; k++) {
                    px = xs[k]+sx;
                    py = ys[k]+sy;
                    if(px >= 0 && px < dun->w && py >= 0 && py < dun->h) {
                      if(dun->t[py][px].h == 0 && dun->csnt[py][px] <= dun->csnt[ys[lowest]+sy][xs[lowest]+sx]) {
                        lowest = k;
                        set = TRUE;
                      }
                    }
                  }
                }
                if(set == TRUE) {
                  new.x = xs[lowest] + sx;
                  new.y = ys[lowest] + sy;
                  break;
                } else {
                  new.x = sx;
                  new.y = sy;
                  break;
                }
              } else {
                //if not intelligent
                if(s->pc.x < sx)
                  px = sx - 1;
                if(s->pc.x > sx)
                  px = sx + 1;
                if(s->pc.y < sy)
                  py = sy - 1;
                if(s->pc.y > sy)
                  py = sy + 1;

                if(test_loc(dun, px, py, s) == TRUE) {
                  new.x = px;
                  new.y = py;
                  break;
                }
              }
            } else {
              //not in the same room and not telepathic
              //randomize
              goto PCEB;
            }
          } else {
            s->pc = dun->carr[dun->pc].p;
            goto IN;
          }

        } else {
          /* we are erratically behaving */
          PCEB: ;
          j = 0;
          EB: ;
          int c = rand() % 9;
          px = xs[c] + sx;
          py = ys[c] + sy;
          // try to find a place to go up to n times 
          if(test_loc(dun, px, py, s) == FALSE && j < 8) {
            j++;
            goto EB;
          }
          if(test_loc(dun, px, py, s) == TRUE) {
            // if the location is okay, commit it
            new.x = px;
            new.y = py;
          }

          break;
        }
      }
    }
  }

  //safety net
  if(new.x < 0)
    new.x = sx;
  if(new.y < 0)
    new.y = sy;

  dun->carr[sn].to.x = new.x;
  dun->carr[sn].to.y = new.y;

  if(new.x == dun->carr[dun->pc].p.x && new.y == dun->carr[dun->pc].p.y)
    dun->go = TRUE;

//check if we have to kill other characters
  int i;
  for(i = 0; i < dun->ns; i++) {
    if(i != sn) {
      if(dun->carr[i].p.x == dun->carr[sn].to.x && dun->carr[i].p.y == dun->carr[sn].to.y && dun->carr[sn].a == TRUE)
        dun->carr[i].a = FALSE;
    }
  }

  //return e;
}

//parse and apply movement




bool check_any_monsters(dun * dun) {
  int i;
  for(i = 0; i < dun->ns; i++) {
    if(dun->carr[i].a == TRUE && i != 0)
      return TRUE;
  }

  return FALSE;
}
Character gen_sprite(dun * dun, char c, int x, int y, int r) {
  Character s;

  s.c = c;
  s.a = TRUE;

    
    if(s.c == '@') {
        s.s.s = 10;
        s.s.tun = FALSE;
    s.s.err = FALSE;
    s.s.tel = FALSE;
    s.s.in = FALSE;
  } else {
        s.s.s = (rand() % 16) + 5;
        s.s.in = rand() % 2;
        s.s.tel = rand() % 2;
        s.s.tun = rand() % 2;
        s.s.err = rand() % 2;

        if(s.s.in == FALSE && s.s.tel == FALSE && s.s.tun == FALSE && s.s.err == FALSE)
            s.c = '0';
        else if(s.s.in == TRUE && s.s.tel == FALSE && s.s.tun == FALSE && s.s.err == FALSE)
            s.c = '1';
        else if(s.s.in == FALSE && s.s.tel == TRUE && s.s.tun == FALSE && s.s.err == FALSE)
            s.c = '2';
        else if(s.s.in == TRUE && s.s.tel == TRUE && s.s.tun == FALSE && s.s.err == FALSE)
            s.c = '3';
        else if(s.s.in == FALSE && s.s.tel == FALSE && s.s.tun == TRUE && s.s.err == FALSE)
            s.c = '4';
        else if(s.s.in == TRUE && s.s.tel == FALSE && s.s.tun == TRUE && s.s.err == FALSE)
            s.c = '5';
        else if(s.s.in == FALSE && s.s.tel == TRUE && s.s.tun == TRUE && s.s.err == FALSE)
            s.c = '6';
        else if(s.s.in == TRUE && s.s.tel == TRUE && s.s.tun == TRUE && s.s.err == FALSE)
            s.c = '7';
        else if(s.s.in == FALSE && s.s.tel == FALSE && s.s.tun == FALSE && s.s.err == TRUE)
            s.c = '8';
        else if(s.s.in == TRUE && s.s.tel == FALSE && s.s.tun == FALSE && s.s.err == TRUE)
            s.c = '9';
        else if(s.s.in == FALSE && s.s.tel == TRUE && s.s.tun == FALSE && s.s.err == TRUE)
            s.c = 'a';
        else if(s.s.in == TRUE && s.s.tel == TRUE && s.s.tun == FALSE && s.s.err == TRUE)
            s.c = 'b';
        else if(s.s.in == FALSE && s.s.tel == FALSE && s.s.tun == TRUE && s.s.err == TRUE)
            s.c = 'c';
        else if(s.s.in == TRUE && s.s.tel == FALSE && s.s.tun == TRUE && s.s.err == TRUE)
            s.c = 'd';
        else if(s.s.in == FALSE && s.s.tel == TRUE && s.s.tun == TRUE && s.s.err == TRUE)
            s.c = 'e';
        else if(s.s.in == TRUE && s.s.tel == TRUE && s.s.tun == TRUE && s.s.err == TRUE)
            s.c = 'f';
    }

    //Randomly add tunnelling monsters in dungeon
    if(s.s.tun == TRUE) {
    int t = 0;
    PRT: ;
        // randomize location anywhere in the dun 
        if(x < 0 || x > dun->w) {
            x = (rand() % (dun->w-2)) + 1;
        }
        if(y < 0 || y > dun->h) {
            y = (rand() % (dun->h-2)) + 1;
        }

    if(s.c != '@' && dun->roomNum > 1) {
      s.p.x = x;
        s.p.y = y;

      bool w_pc = FALSE;
      with_pc(dun, &s, &w_pc);
      if(w_pc == TRUE && t < 8) {
        t++;
        goto PRT;
      }
    }
    }
    if(r > 0 || s.s.tun == FALSE) {
    int t = 0;
    PRNT: ;
        int r_id = rand() % dun->roomNum ;
        x = (rand() % dun->room[r_id].w) + dun->room[r_id].tl.x;
        y = (rand() % dun->room[r_id].h) + dun->room[r_id].tl.y;

    if(s.c != '@' && dun->roomNum > 1) {
      s.p.x = x;
        s.p.y = y;

      bool w_pc = FALSE;
      with_pc(dun, &s, &w_pc);
      if(w_pc == TRUE && t < 8) {
        t++;
        goto PRNT;
      }
    }
    } else {

    }

    s.p.x = x;
    s.p.y = y;
  s.t = 0;

  return s;
}
