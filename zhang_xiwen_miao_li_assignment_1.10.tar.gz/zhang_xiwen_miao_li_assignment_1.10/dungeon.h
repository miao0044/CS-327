#ifndef dungeon_generator
#define dungeon_generator
	#include <vector>
	#include <string>


	typedef enum {BLACK, RED, GREEN, YELLOW, BLUE, MAGENTA, CYAN, WHITE} colour;

	typedef enum {WEAPON, OFFHAND, RANGED, ARMOR, HELMET, CLOAK, GLOVES, BOOTS, RING, AMULET, LIGHT, NONEQUIP, SCROLL, BOOK, FLASK, GOLD, AMMUNITION, FOOD, WAND, CONTAINER} itype;

	// classes
	class PC;
	
	class Position {
	public:
		int x; 
		int y; 
	};
	
	class Dice {
	public:
		int b;	
		int d;		
		int roll(void);
		Dice(int, int, int);
		Dice(void);
		int n;
		std::string string(void);
	};
	
	class Item {
	public:
		itype t;
		bool e;			
		colour c;			
		Dice* d;
		std::string n;
		std::string* desc;
		int dl;			
		int hib;
		int dob;
		int deb;
		int w;
		int spb;
		int sa;
		int v;
		int art;     
		int rar;
		char s;
		Position p;
	};
	
	class ItemTemp {
	public:
		std::string n;
		std::string* desc;
		itype t;
		bool e;
		colour c;
		Dice* d;
		Dice* hib;
		Dice* dob;
		Dice* deb;
		Dice* w;
		Dice* spb;
		Dice* sa;
		Dice* v;
		char s;
		Position p;
		int dl;
		int art;     
		int rar; 
	};
	
	class Memory {
	public:
		char c;
		bool v;
		int color;
	};

	class Stats {
	public:
		bool in;
		bool te;
		bool tu;
		bool eb;
		bool uni;
		bool boss;
		int  s;
		bool pa;
		Dice* a;
		int hp;
	};
	
	class StatsTemp {
	public:
		bool in;
		bool te;
		bool tu;
		bool eb;
		bool uni;
		bool boss;
		bool	pa;
		Dice*	s;
		Dice*	a;
		Dice*	hp;
	};

	class Creature {
	public:
		friend class PC;
		friend class Monster;
		Position p;
		char c;
		Stats s;
		int t;
		Position to;
		int sn;
		Position pc;
		bool a;
		Position lp;
		int rar;
		std::string n;
		colour color;
		std::string* desc;
		int dl;
		Creature * thisCreature(void);
		PC * thisPC(void);
	};
	
	class CreatureTemp {
	public:
		Position p;
		char c;
		StatsTemp s;
		int t;
		Position to;
		int sn;
		Position pc;
		bool a;
		int rar;
		std::string n;
		colour color;
		std::string* desc;
		int dl;
		char pa;
		Creature * thisCreature(void);
		PC * thisPC(void);
	};

	class Monster : public Creature {
	public:
		friend class Creature;

	};

	class PC : public Creature {
	public:
		friend class Creature;
		int view;
		Memory ** mem;
		Item eqs[12];
		Item inv[10];
		bool eqsp[12];
		bool invp[10];
		int lt;
		bool hlt;
	};
	
	class MonsterFactory {
	public:
		int dn;
		CreatureTemp * md;
		MonsterFactory(int, CreatureTemp *);
		MonsterFactory(void);
		Creature* GetMon();
	};
	
	class ObjectFactory {
	public:
		int dn;
		ItemTemp * id;
		ObjectFactory(int, ItemTemp *);
		ObjectFactory(void);
		Item GetObj();
	};

	#define	TRUE	1
	#define	FALSE	0
	typedef int Bool;

	typedef struct {
		int h;
		char c;
		int p;
		int color;
	} Tile;

	typedef struct {
		int prev;
		int next;
	} Path;

	typedef struct {
		Position* tl;
		Position* br;
		int w;
		int h;
		int id;
		int p;
		Position* ctr;
		int c;
	} Room;

	typedef struct {
		Tile ** d;
		Tile ** p;
		int h;
		int w;
		int nr;
		int mr;
		Room * r;
		int v;
		int s;
		Creature * ss;
		int ns;
		int ms;
		int ** csnt;
		int ** cst;
		int pc;
	   	int t;
		Bool go;
		Position * su;
		Position * sd;
		PC * plyr;
		int mi;
		int di;
		ItemTemp * id;
		int mm;
		int dm;
		CreatureTemp * md;
		std::string nmd[200];		
		MonsterFactory* mf;
		ObjectFactory* of;		
		int nit;
		Item * items;
	} Dungeon;

	typedef struct {
		int x;
		int y;
		int cost;
		int v;
	} Tile_Node;
	

	// functions
	Creature * gen_creature_fac(Dungeon * dungeon, char c, int x, int y, int r);
	void add_creature(Dungeon * dungeon, Creature * s);
	Creature * gen_creature(Dungeon * dungeon, char c, int x, int y, int r);
	void gen_move_creature(Dungeon * dungeon, int sn);
	void parse_move(Dungeon * dungeon, int sn);
	Bool check_boss_alive(Dungeon * dungeon);
	Bool test_loc(Dungeon * dungeon, int x, int y, Creature *s);
	void with_pc(Dungeon * dungeon, Creature * s, Bool *in);
	
	void print_dun_full(Dungeon * dungeon, int nt, int t);
	void print_dun_teleport(Dungeon * dungeon, int nt, int t, int gx, int gy);
	void print_t_heatmap(Dungeon * dungeon);
	void print_nont_heatmap(Dungeon * dungeon);
	void print_dun(Dungeon * dungeon, int nt, int t);
	void print_dun_nnc(Dungeon * dungeon, int nt, int t);

	void gen_corridors(Dungeon * dungeon);
	void gen_dun(Dungeon * dungeon);
	Dungeon init_dun(int h, int w, int mr);	

	void map_dun_t(Dungeon * dungeon);

	Creature * initCreature();
	Creature * initCreatures(int);
	void copyCreature(Creature *, Creature *);
	void copyACreature(Creature * to, int n, Creature * from);
	Creature * thisACreature(Creature * arr, int i);
	int getCreaturePX(Creature *);
	int getCreaturePY(Creature *);
	char getCreatureC(Creature *);
	bool getCreatureSIn(Creature *);
	bool getCreatureSTe(Creature *);
	bool getCreatureSTu(Creature *);
	bool getCreatureSEb(Creature *);
	int getCreatureSS(Creature *);
	int getCreatureT(Creature *);
	int getCreatureToX(Creature *);
	int getCreatureToY(Creature *);
	int getCreatureSn(Creature *);
	int getCreaturePcX(Creature *);
	int getCreaturePcY(Creature *);
	int getCreatureAPX(Creature *, int);
	int getCreatureAPY(Creature *, int);
	char getCreatureAC(Creature *, int);
	bool getCreatureASIn(Creature *, int);
	bool getCreatureASTe(Creature *, int);
	bool getCreatureASTu(Creature *, int);
	bool getCreatureASEb(Creature *, int);
	int getCreatureASS(Creature *, int);
	int getCreatureAT(Creature *, int);
	int getCreatureAToX(Creature *, int);
	int getCreatureAToY(Creature *, int);
	int getCreatureASn(Creature *, int);
	int getCreatureAPcX(Creature *, int);
	int getCreatureAPcY(Creature *, int);
	void setCreaturePX(Creature *, int);
	void setCreaturePY(Creature *, int);
	void setCreatureC(Creature *, char);
	void setCreatureSIn(Creature *, bool);
	void setCreatureSTe(Creature *, bool);
	void setCreatureSTu(Creature *, bool);
	void setCreatureSEb(Creature *, bool);
	void setCreatureSS(Creature *, int);
	void setCreatureT(Creature *, int);
	void setCreatureToX(Creature *, int);
	void setCreatureToY(Creature *, int);
	void setCreatureSn(Creature *, int);
	void setCreaturePcX(Creature *, int);
	void setCreaturePcY(Creature *, int);
	void setCreatureAPX(Creature *, int, int);
	void setCreatureAPY(Creature *, int, int);
	void setCreatureAC(Creature *, int, char c);
	void setCreatureASIn(Creature *, int, bool);
	void setCreatureASTe(Creature *, int, bool);
	void setCreatureASTu(Creature *, int, bool);
	void setCreatureASEb(Creature *, int, bool);
	void setCreatureASS(Creature *, int, int);
	void setCreatureAT(Creature *, int, int);
	void setCreatureAToX(Creature *, int, int);
	void setCreatureAToY(Creature *, int, int);
	void setCreatureASn(Creature *, int, int);
	void setCreatureAPcX(Creature *, int, int);
	void setCreatureAPcY(Creature *, int, int);

	PC * initPC(Dungeon *);

	int getPositionX(Position * p);
	int getPositionY(Position * p);
	void setPositionX(Position * p, int n);
	void setPositionY(Position * p, int n);
	Position * initPosition(void);
	void updateMemory(Dungeon *);
	char getMem(Dungeon *, int, int);
	PC * getPC(Creature * arr);
	PC * thisAPC(Creature * arr, int i);
	void copyPC(PC * to, PC * from);
  	void placeitem(Dungeon *, Item);
#endif
