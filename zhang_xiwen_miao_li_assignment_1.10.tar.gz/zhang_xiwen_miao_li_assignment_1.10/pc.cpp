#include "dungeon.h"
#include <cstdlib>
#include <ncurses.h>

PC * getPC(Creature * arr) {
	return (PC *) &(arr[0]);
}

PC * thisAPC(Creature * arr, int i) {
	return arr[i].thisPC();
}

void updateMemory(Dungeon * dun) {
	int i;
	int j;
	for(i = 1; i < dun->h-1; i++) {
		for(j = 1; j < dun->w-1; j++) {
			if(abs(i - ((PC *) &dun->ss[0])->p.y) <= 3 && abs(j - ((PC *) &dun->ss[0])->p.x) <= 3 && dun->d[i][j].h == 0) {
				dun->plyr->mem[i][j].c = dun->p[i][j].c;
				dun->plyr->mem[i][j].v = true;
				dun->plyr->mem[i][j].color = dun->p[i][j].color;
			}
		}
	}
}

PC * Creature::thisPC() {
  return (PC *) this;
}

char getMem(Dungeon * dun, int y, int x) {
	return dun->plyr->mem[y][x].c;
}


PC * initPC(Dungeon * dun) {
	PC * pc = new PC;

	pc->hlt = false;
	pc->c = '@';
	pc->sn = 0;
	pc->a = TRUE;
	pc->s.hp = 100;
	pc->s.a = new Dice(0, 1, 4);
	pc->s.s = 10;
	pc->s.tu = FALSE;
	pc->s.eb = FALSE;
	pc->s.te = FALSE;
	pc->s.in = FALSE;

	int r_id = rand() % dun->nr;
	int x = (rand() % dun->r[r_id].w) + getPositionX(dun->r[r_id].tl);
	int y = (rand() % dun->r[r_id].h) + getPositionY(dun->r[r_id].tl);

	pc->p.x = pc->to.x = x;
	pc->p.y = pc->to.y = y;
	pc->t = 0;
	dun->plyr = pc;

	pc->mem = (Memory **) malloc(dun->h * sizeof(Memory *));
	int i;
	for(i = 0; i < dun->h; i++) {
		pc->mem[i] = (Memory *) malloc(dun->w * sizeof(Memory));
	}

	int j;
	for(i = 0; i < dun->h; i++) {
		for(j = 0; j < dun->w; j++) {
			pc->mem[i][j].c = ' ';
			pc->mem[i][j].v = false;
		}
	}
	return pc;
}
