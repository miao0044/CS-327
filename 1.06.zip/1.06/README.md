By: Xiwen Zhang (xiwenz), Li Miao (miao0044)

In this project, a 80x21 dungeon map is generated. The dungeon is surrounded by edges with hardness of 255, and contains 6-10 rooms. 
Users starts with a 3x3 visible space and can choose to sacrifice one step to view the position of the enemy. 
Customized number of monsters by "./dungeon --nummon xxx" either moves by Dijkstra algorithm or randomly according to monsters category. 
Users can control the character movements through assigned keys in assignment description. 
Users can teleport to random or customized spot on dungeon map. 
Press 'Q' to quit the game. If user meets a monster, the game automatically end with losing messages. 

