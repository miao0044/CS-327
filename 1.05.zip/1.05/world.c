#include <stdlib.h>
#include <math.h>
#include "dungeon.h"

int hash (int a, int b) {
  // generate a random int between a and b
  return (a + rand() % (b - a));
}

int place_room(dun * dun) {
	int x = (rand() % (dun->w-1)) +1;
	int y = (rand() % (dun->h-1)) +1;
	Room new_room;
	/*
	set top right to rng number; might be worth making a more detailed placer with a lower
		fail rate
	*/
	new_room.tl.x = x;
	new_room.tl.y = y;
	/* for RNG, maybe do a rando room width/height and re-set .br */

	HW: ;

	int we = (rand() % 4) + 4; /* width, expanded, up to 4 more */
	int he = (rand() % 4) + 3; /* height, expanded, up to 4 more */

	if(we == he) {
		/* if we have a square, re-generate */
		goto HW;
	}

	new_room.h = he;
	new_room.w = we;

	new_room.br.x = x + new_room.w-1;
	new_room.br.y = y + new_room.h-1;

	/* check for rooms loaded into the dun buffer already */
	int i;
	int j;
	int placed = -1;
	int passed = 0;
	for(i = y; i < dun->h-1 && i < y+he; i++) {
		for(j = x; j < dun->w-1 && j < x+we; j++) {
			if(dun->p[i][j].c != '.') {
				passed++;
			}
		}
	}

	/* return a failure if not all cells within the "Room" passed */
	if(passed < we*he) {
		return placed; /* should be -1 */
	}

	/* return a failure if part of the room is out of bounds */
	if(new_room.br.x >= dun->w || new_room.br.y >= dun->h) {
		return placed;
	}


	/* check for surrounding rooms */

	/* top row */
	for(i = new_room.tl.x-1; i < new_room.br.x+2 && new_room.tl.x-1 >= 0 && new_room.br.x+1 < dun->w && new_room.tl.y-1 >= 0; i++) {
		if((dun->p[new_room.tl.y-1][i]).c == '.') {
			return placed;
		}
	}

	/* bottom row */
	for(i = new_room.tl.x-1; i < new_room.br.x+2 && new_room.tl.x-1 >= 0 && new_room.br.x+1 < dun->w && new_room.br.y+1 < dun->h; i++) {
		if((dun->p[new_room.br.y+1][i]).c == '.') {
			return placed;
		}
	}

	/* left side */
	for(i = new_room.tl.y; i < new_room.br.y+1 && new_room.br.y+1 < dun->h && new_room.tl.x-1 >= 0; i++) {
		if((dun->p[i][new_room.tl.x-1]).c == '.') {
			return placed;
		}
	}

	/* right side */
	for(i = new_room.tl.y; i < new_room.br.y+1 && new_room.br.y+1 < dun->h && new_room.br.x+1 < dun->w; i++) {
		if((dun->p[i][new_room.br.x+1]).c == '.') {
			return placed;
		}
	}


	/* successful placement */
	placed = 0;

	/* fill the room into the dun buffer and add to room array */
	for(i = y; i < y+he; i++) {
		for(j = x; j < x+we; j++) {
			dun->p[i][j].c = '.';
			dun->t[i][j].h = 0;
		}
	}


	if(dun->roomNum < dun->mr) {
		dun->roomNum++;
		new_room.id = dun->roomNum-1; /* reflects position in the array */
		new_room.center.x = (new_room.w)/2 + new_room.tl.x;
		new_room.center.y = (new_room.h)/2 + new_room.tl.y;
		/* printf("%d: (%d, %d)\n", new_room.id, new_room.center.x, new_room.center.y); */
		dun->room[dun->roomNum-1] = new_room;
	} else {
		return -1;
	}


	return placed;
}

int all_connected(int * cnxns, dun * dun) {
	int i;

	for(i = 0; i < dun->roomNum; i++) {
		if(cnxns[i] != 1 || dun->room[i].c != 1) {
			return 0;
		}
	}

	return 1;
}

void spawnCorridors(dun * dun) {
  int i;
	int connected[dun->roomNum];
  for(i = 0; i < dun->roomNum; i++) {
		connected[i] = 0;
	}
	double dists[dun->roomNum];
  for(i = 0; i < dun->roomNum; i++) {
		dists[i] = 0;
	}
	int max_paths = dun->roomNum * 3;
	Path paths[max_paths]; /* max paths is 3 * number of rooms */
	int path_cnt = 0;
	int	room_pos = 0; /* current room in use */

	for(i = 0; i < dun->roomNum; i++) {
		dists[i] = -1; /* infinite at -1 */
	}
	dists[0] = 0;

	/* ensure all rooms are disconnected */
	for(i = 0; i < dun->roomNum; i++) {
		dun->room[i].c = 0;
	}

	/* primary loop, goal is to connect all rooms; 0 means 1 */
	while(all_connected(connected, dun) == 0 && path_cnt < max_paths) {
		int i;
		double d;
		Path new_path;

		/* populate dists from the current position */
		for(i = 0; i < dun->roomNum; i++) {
			/* calculate distance */
			d =  sqrt(pow(dun->room[i].center.x - dun->room[room_pos].center.x, 2) + pow(dun->room[i].center.y - dun->room[room_pos].center.y, 2));
			dists[i] = d;
		}

		/* find the room to path to ;; if not connected already and the distance is shorter and isn't our current position */

		int next = -1;
		for(i = 0; i < dun->roomNum; i++) {
			if(connected[i] != 1 && next == -1 && room_pos != i) {
				next = i;
			} else if(connected[i] != 1 && dists[i] < dists[next] && room_pos != i) {
				next = i;
			}
		}

		/** this would - in the future - be the point of adding extraneous paths **/
		if(next != -1) {
			dun->room[room_pos].c = 1;
			dun->room[next].c = 1;
			connected[room_pos] = 1;
			new_path.prev = room_pos;
			new_path.next = next;
			paths[path_cnt] = new_path;
			room_pos = next;
			path_cnt++;
		} else {
			break;
		}

	}

	/* populate the dun grid (draw the paths using x/y chasing/pathing) */

	/* draw dun paths in the dun grid; start at room 0 as per above */

	for(i = 0; i < path_cnt; i++) {
		int x = dun->room[paths[i].prev].center.x;
		int y = dun->room[paths[i].prev].center.y;

		/*printf("%d: (%d, %d)\n", i, x, y);*/

		while(x != dun->room[paths[i].next].center.x || y != dun->room[paths[i].next].center.y) {
			int dirx = 0; /* -1 for left, 1 for right */
			int diry = 0; /* -1 for down, 1 for up */

			if(x < dun->room[paths[i].next].center.x) {
				dirx = 1;
			} else if(x > dun->room[paths[i].next].center.x) {
				dirx = -1;
			}

			if(y < dun->room[paths[i].next].center.y) {
				diry = 1;
			} else if(y > dun->room[paths[i].next].center.y) {
				diry = -1;
			}

			dun->t[y][x].p = 1;
			/* don't place corridors in rooms */
			if(dun->t[y][x].c != '.') {
				dun->t[y][x].c = '#';
				dun->t[y][x].h = 0;
			}

			if(dirx == -1) {
				x--;
			} else if(dirx == 1) {
				x++;
			} else if(diry == -1) {
				y--;
			} else if(diry == 1) {
				y++;
			}
		}

	}

}

void spawnDun(dun * dun) {
	/*** top 3 (0, 1, 2) are reserved for the pseudo-HUD ***/
	int i, j;

	/* set all slots to spaces originally */
	for(i = 0; i < dun->h; i++) {
		for(j = 0; j < dun->w; j++) {
			(dun->t[i][j]).c = ' ';	/* all basic rooms are spaces */
			int h = (rand() % 254) + 1;
			(dun->t[i][j]).h = h;
		}
	}

	/* immut-ify the outside rim */
	for(i = 0; i < dun->w; i++) {
		(dun->t[0][i]).h = 255;
	}
	for(i = 0; i < dun->w; i++) {
		(dun->t[dun->h-1][i]).h = 255;
	}
	for(i = 0; i < dun->h; i++) {
		(dun->t[i][0]).h = 255;
	}
	for(i = 0; i < dun->h; i++) {
		(dun->t[i][dun->w-1]).h = 255;
	}

	/* make p equal to d */
	for(i = 0; i < dun->h; i++) {
		for(j = 0; j < dun->w; j++) {
			dun->p[i][j] = dun->t[i][j];
		}
	}

	/* populate the rooms */
	int cnt = 0;
	int tst = 0;
	for(i = 0; dun->roomNum < dun->mr && cnt < 2000; i++) {
		tst = place_room(dun);
		if(tst < 0) {
			cnt++;
		}
	}
}

void spawnStair(dun *dun){
  int up = hash(1, 5);
  dun->un = up;
  int down = hash(1, 5);
  dun->dn = down;
  int count = 0;
  int x, y;
  while(count < up){
    y = hash(0, 21);
    x = hash(0, 80);
    if(!dun->t[y][x].h){
      if(((dun->t[y][x].c == '#')&& (dun->t[y-1][x].c == '#'))||((dun->t[y][x].c != '#') && (dun->t[y-1][x].c == '.'))) {
        dun->t[y][x].c = '<';
        dun->upStair[count].p.x = y;
        dun->upStair[count].p.y = x;
        dun->upStair[count].ud = 1;
        count++;
      }
    }
  }
  count = 0;
  while(count < down){
    y = hash(1, 20);
    x = hash(1, 79);
    if((!dun->t[y][x].h) && (dun->t[y][x].c != '<')){
      if(((dun->t[y][x].c == '#')&& (dun->t[y+1][x].c == '#'))||((dun->t[y][x].c != '#') && (dun->t[y+1][x].c == '.'))) {
        dun->t[y][x].c = '>';
        dun->downStair[count].p.x = y;
        dun->downStair[count].p.y = x;
        dun->upStair[count].ud = 0;
        count++;
      }
    }
  }
}

dun initDun(int h, int w, int mr) {
	dun new_dun;
	new_dun.h	= h;
	new_dun.w	= w;
	new_dun.mr	= mr;
	new_dun.roomNum	= 0;
	new_dun.ns	= 0;
	new_dun.ms	= w*h;
	new_dun.tn = 0;
	new_dun.go = FALSE;

	new_dun.t = calloc(new_dun.h, sizeof(Tile *));

	int i;
	for(i = 0; i < new_dun.h; i++) {
		new_dun.t[i] = calloc(new_dun.w, sizeof(Tile));
	}

	/* dun visual buffer allocation+0'ing */
	new_dun.p = calloc(new_dun.h, sizeof(Tile *));

	for(i = 0; i < new_dun.h; i++) {
		new_dun.p[i] = calloc(new_dun.w, sizeof(Tile));
	}

	/* rooms allocation+0'ing */
	new_dun.room = calloc(new_dun.mr, sizeof(Room));

    new_dun.upStair = calloc(5 , sizeof(Stair));
    new_dun.downStair = calloc(5 , sizeof(Stair));
	/* characters allocation */
	new_dun.carr = calloc(new_dun.ms, sizeof(Character));

	/* djikstra-based cost map allocation */
	new_dun.cost = calloc(w*h, sizeof(int *));
	for(i = 0; i < new_dun.h; i++) {
		new_dun.cost[i] = calloc(new_dun.w, sizeof(int));
	}

	/* djikstra-based cost map allocation */
	new_dun.csnt = calloc(w*h, sizeof(int *));
	for(i = 0; i < new_dun.h; i++) {
		new_dun.csnt[i] = calloc(new_dun.w, sizeof(int));
	}

	return new_dun;
}
