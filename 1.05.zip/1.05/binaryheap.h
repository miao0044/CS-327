#ifndef BINHEAP_H
# define BINHEAP_H

# ifdef __cplusplus
extern "C" {
# endif

# include <stdint.h>

struct binheapNode;
typedef struct binheapNode BinaryHeapNode;

typedef struct binheap {

  int32_t (*compare)(const void *key, const void *with);

  uint32_t size;

  uint32_t array_size;

  BinaryHeapNode **array;

  void (*bhDelete)(void *);

} BinaryHeap;

void initializeBinaryHeap(BinaryHeap *h, int32_t (*compare)(const void *key, const void *with),  void (*bhDelete)(void *));

void initializeBinaryHeapArr(BinaryHeap *h, void *array, uint32_t size, uint32_t nmemb, int32_t (*compare)(const void *key, const void *with), void (*bhDelete)(void *));

void deleteBinaryHeap(BinaryHeap *h);

BinaryHeapNode *deleteBinaryInsert(BinaryHeap *h, void *v);

void *binaryHeapPeekMin(BinaryHeap *h);

void *binaryHeapRemoveMin(BinaryHeap *h);

void binaryHeapDecrease(BinaryHeap *h, BinaryHeapNode *n);

uint32_t binaryHeapIsEmpty(BinaryHeap *h);

# ifdef __cplusplus
}
# endif

#endif
