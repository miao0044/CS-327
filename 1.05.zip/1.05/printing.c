#include <stdio.h>
#include <ncurses.h>
#include "dungeon.h"



void printDun(dun * dun, int nt, int t) {
	clear();
	int i;
	int j;
	int h;

	for(i = 0; i < dun->h; i++) {
		for(j = 0; j < dun->w; j++) {
			dun->p[i][j].c = ' ';
		}
	}

	/* add corridors to the print buffer */
	for(i = 0; i < dun->h; i++) {
		for(j = 0; j < dun->w; j++) {
			if(dun->t[i][j].p == 1 || dun->t[i][j].c == '#'|| dun->t[i][j].h == 0) {
				dun->p[i][j].c = '#';
			}
		}
	}
	/* add rooms to the print buffer */
	for(h = 0; h < dun->roomNum; h++) {
		for(i = dun->room[h].tl.y; i < dun->room[h].br.y+1; i++) {
			for(j = dun->room[h].tl.x; j < dun->room[h].br.x+1; j++) {
				dun->p[i][j].c = '.';
			}
		}
	}
	// setting up upstairs
    for(i = 0; i < dun->h; i++) {
   for(j = 0; j < dun->w; j++) {
     if(dun->t[i][j].c == '>') {
       dun->p[i][j].c = '>';
     }
	 else if(dun->t[i][j].c == '<'){
         dun->p[i][j].c = '<';
       }
     }
   }

	/* add characters to the print buffer */
	for(i = 0; i < dun->ns; i++) {
		if(dun->carr[i].a == TRUE)
		  dun->p[dun->carr[i].p.y][dun->carr[i].p.x].c = dun->carr[i].c;
	}

	/* print non-tunnelling dijkstra's */
	if(nt > 0) {
		for(i = 0; i < dun->h; i++) {
			for(j = 0; j < dun->w; j++) {
				if(dun->t[i][j].h == 0) {
					int c = dun->csnt[i][j];
					if(c == 0) {
						dun->p[i][j].c = '@';
					} else {
						dun->p[i][j].c = '0' + c % 10;
					}
				}
			}
		}
	}

	/* print tunnelling dijkstra's */
	if(t > 0) {
		for(i = 0; i < dun->h; i++) {
			for(j = 0; j < dun->w; j++) {
				int c = dun->cost[i][j];
				if(c == 0) {
					dun->p[i][j].c = '@';
				} else {
					dun->p[i][j].c = '0' + c % 10;
				}
			}
		}
	}

	/* print the print buffer */
	for(i = 0; i < dun->h; i++) {
		int j;
		for(j = 0; j < dun->w; j++) {
			mvaddch(i+1, j, (dun->p[i][j]).c);
		}
	}
	refresh();
}

void printDun_nnc(dun * dun, int nt, int t) {
	int i;
	int j;
	int h;

	for(i = 0; i < dun->h; i++) {
		for(j = 0; j < dun->w; j++) {
			dun->p[i][j].c = ' ';
		}
	}

	/* add corridors to the print buffer */
	for(i = 0; i < dun->h; i++) {
		for(j = 0; j < dun->w; j++) {
			if(dun->t[i][j].p == 1 || dun->t[i][j].c == '#' || dun->t[i][j].h == 0) {
				dun->p[i][j].c = '#';
			}
		}
	}

	/* add rooms to the print buffer */
	for(h = 0; h < dun->roomNum; h++) {
		for(i = dun->room[h].tl.y; i < dun->room[h].br.y+1; i++) {
			for(j = dun->room[h].tl.x; j < dun->room[h].br.x+1; j++) {
				dun->p[i][j].c = '.';
			}
		}
	}

  // setting up upstairs
    for(i = 0; i < dun->h; i++) {
   for(j = 0; j < dun->w; j++) {
     if(dun->t[i][j].c == '>') {
       dun->p[i][j].c = '>';
     }
   else if(dun->t[i][j].c == '<'){
         dun->p[i][j].c = '<';
       }
     }
   }

	/* add sprites to the print buffer */
	for(i = 0; i < dun->roomNum; i++) {
		if(dun->carr[i].a == TRUE)
			dun->p[dun->carr[i].p.y][dun->carr[i].p.x].c = dun->carr[i].c;
	}

  /* print non-tunnelling dijkstra's */
  if(nt > 0) {
    for(i = 0; i < dun->h; i++) {
      for(j = 0; j < dun->w; j++) {
        if(dun->t[i][j].h == 0) {
          int c = dun->csnt[i][j];
          if(c == 0) {
            dun->p[i][j].c = '@';
          } else {
            dun->p[i][j].c = '0' + c % 10;
          }
        }
      }
    }
  }

  /* print tunnelling dijkstra's */
  if(t > 0) {
    for(i = 0; i < dun->h; i++) {
      for(j = 0; j < dun->w; j++) {
        int c = dun->cost[i][j];
        if(c == 0) {
          dun->p[i][j].c = '@';
        } else {
          dun->p[i][j].c = '0' + c % 10;
        }
      }
    }
  }

	/* print the print buffer */
	for(i = 0; i < dun->h; i++) {
		int j;
		for(j = 0; j < dun->w; j++) {
			printf("%c", (dun->p[i][j]).c);
		}
		printf("\n");
	}
}
